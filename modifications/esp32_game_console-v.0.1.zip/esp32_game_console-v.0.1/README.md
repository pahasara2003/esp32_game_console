# esp32_game_console


https://downloads.arduino.cc/arduino-ide/arduino-ide_2.3.6_Windows_64bit.exe



esp32 by Espressif Systems version 3.X.


![alt text](image.png)