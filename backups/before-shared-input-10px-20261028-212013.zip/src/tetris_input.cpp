#include <Arduino.h>
#include <Adafruit_ADS1X15.h>
#include "config.h"
#include "tetris_input.h"

extern Adafruit_ADS1115 ads;
extern bool adsConnected;

namespace tetrisInput {
bool active = false, settling = true, blocked = true;
uint16_t previousRate;
uint8_t channel = 0, high[4] = {}, low[4] = {}, mask = 0, reported = 0;
bool shootRaw = false, shootStable = false;
unsigned long shootChanged = 0, checked = 0;
const uint16_t mux[] = {ADS1X15_REG_CONFIG_MUX_SINGLE_0, ADS1X15_REG_CONFIG_MUX_SINGLE_1,
                       ADS1X15_REG_CONFIG_MUX_SINGLE_2, ADS1X15_REG_CONFIG_MUX_SINGLE_3};
const uint8_t direction[] = {1, 2, 3, 0};
}

void tetrisInputEnd() {
  if (tetrisInput::active && adsConnected) ads.setDataRate(tetrisInput::previousRate);
  tetrisInput::active = false;
}

void tetrisInputRequireRelease() {
  using namespace tetrisInput;
  blocked = true;
  reported = 0;
  for (int i = 0; i < 4; ++i) low[i] = 0;
}

void tetrisInputBegin() {
  using namespace tetrisInput;
  tetrisInputEnd();
  mask = reported = channel = 0;
  for (int i = 0; i < 4; ++i) high[i] = low[i] = 0;
  shootRaw = shootStable = digitalRead(SHOOT) != LOW;
  shootChanged = checked = millis();
  settling = blocked = active = true;
  if (adsConnected) {
    previousRate = ads.getDataRate();
    ads.setDataRate(RATE_ADS1115_860SPS);
    ads.startADCReading(mux[channel], false);
  }
}

uint8_t tetrisInputHeld() {
  return tetrisInput::active && !tetrisInput::blocked ? tetrisInput::reported : 0;
}

uint8_t tetrisInputPoll() {
  using namespace tetrisInput;
  if (!active) return 0;
  unsigned long now = millis();
  bool raw = digitalRead(SHOOT) != LOW;
  if (raw != shootRaw) { shootRaw = raw; shootChanged = now; }
  if (now - shootChanged >= 10) shootStable = raw;

  if (adsConnected && now - checked >= 1) {
    checked = now;
    if (ads.conversionComplete()) {
      int16_t sample = ads.getLastConversionResults();
      if (settling) settling = false;
      else {
        uint8_t bit = 1 << direction[channel];
        if (sample > 18000) {
          low[channel] = 0;
          if (high[channel] < 2) ++high[channel];
          if (high[channel] == 2) mask |= bit;
        } else {
          high[channel] = 0;
          if (sample < 15000) {
            if (low[channel] < 2) ++low[channel];
            if (low[channel] == 2) mask &= ~bit;
          } else low[channel] = 0;
        }
        channel = (channel + 1) % 4;
        settling = true;
      }
      ads.startADCReading(mux[channel], false);
    }
  }
  uint8_t held = mask | (shootStable ? 16 : 0);
  if (blocked) {
    if (held || shootRaw) return 0;
    if (adsConnected)
      for (int i = 0; i < 4; ++i) if (low[i] < 2) return 0;
    blocked = false;
    reported = 0;
    return 0;
  }
  uint8_t pressed = held & ~reported;
  reported = held;
  return pressed;
}
