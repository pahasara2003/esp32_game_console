#include <Arduino.h>
#include <math.h>
#include <Adafruit_ADS1X15.h>
#include "game.h"

extern Adafruit_ADS1115 ads;
extern bool adsConnected;

namespace mandelApp {
// The plot is square-pixel: both complex axes use the same scale.
constexpr int X = 8, Y = 64, W = 224, H = 208;
constexpr int MAX_ZOOM = 20;
constexpr int OPTIONS = 5;
static_assert(X + W <= 240 && Y + H <= 280, "Plot must clear the footer");
static double centerRe = -0.5, centerIm = 0.0;
static int zoom = 0, option = 0;
static bool menu = false, rendering = false;
static bool shootHeld = false, holdSent = false;
static unsigned long pressedAt = 0, lastStatus = 0;
static int rawButton = -2;
static unsigned long rawChangedAt = 0;
static bool inputArmed = false;
static bool navigationPending = false;
static uint8_t scanChannel = 0, validChannels = 0;
static int16_t readings[4] = {};
static int block = 8, column = 0, row = 0, limit = 96;
static uint16_t strip[W * 8];
static uint16_t palette[256];
struct PixelJob {
  bool active = false;
  double cr, ci, zr, zi, rr, ii;
  int iteration;
};
static PixelJob pixel;
constexpr unsigned long WORK_US = 2000;

static double pixelScale() { return ldexp(3.5 / W, -zoom); }

static uint16_t rgb(int r, int g, int b) {
  return ((r & 248) << 8) | ((g & 252) << 3) | (b >> 3);
}

static void makePalette() {
  // Vivid indigo, violet, magenta, orange and gold around a black set.
  const uint8_t stops[][3] = {{8, 8, 48}, {35, 35, 205}, {116, 28, 240},
    {235, 35, 143}, {255, 113, 32}, {255, 226, 95}, {40, 166, 245}, {8, 8, 48}};
  for (int i = 0; i < 256; ++i) {
    int pos = i * 7, a = pos / 256, f = pos % 256;
    int r = (stops[a][0] * (256-f) + stops[a+1][0] * f) / 256;
    int g = (stops[a][1] * (256-f) + stops[a+1][1] * f) / 256;
    int b = (stops[a][2] * (256-f) + stops[a+1][2] * f) / 256;
    palette[i] = rgb(r,g,b);
  }
}

static bool sample(double cr, double ci, uint16_t &color, unsigned long started) {
  // Analytic cardioid / period-2 bulb checks avoid iterating the solid interior.
  if (!pixel.active) {
    double shifted = cr - 0.25, q = shifted * shifted + ci * ci;
    if (q * (q + shifted) <= 0.25 * ci * ci ||
        (cr + 1.0) * (cr + 1.0) + ci * ci <= 0.0625) {
      color = 0; return true;
    }
    pixel.active = true;
    pixel.cr = cr; pixel.ci = ci;
    pixel.zr = pixel.zi = pixel.rr = pixel.ii = 0;
    pixel.iteration = 0;
  }
  // Even one expensive boundary pixel can yield to the controls. The preview
  // uses fewer iterations; later passes compute the full detail limit.
  int iterations = block == 8 ? min(limit, 48) : limit;
  while (pixel.rr + pixel.ii <= 4.0 && pixel.iteration < iterations) {
    if ((pixel.iteration & 7) == 0 && (unsigned long)(micros() - started) >= WORK_US)
      return false;
    pixel.zi = 2.0 * pixel.zr * pixel.zi + pixel.ci;
    pixel.zr = pixel.rr - pixel.ii + pixel.cr;
    pixel.rr = pixel.zr * pixel.zr;
    pixel.ii = pixel.zi * pixel.zi;
    ++pixel.iteration;
  }
  pixel.active = false;
  if (pixel.iteration == iterations) { color = 0; return true; }
  // Smooth escape coloring reduces hard iteration bands without using a
  // frame buffer. Only escaped samples need the logarithms.
  double smooth = pixel.iteration + 1.0 - log2(log2(pixel.rr + pixel.ii) * 0.5);
  color = palette[((int)(smooth * 7.0)) & 255];
  return true;
}

static void drawHeader() {
  tft.fillRoundRect(8, 8, 224, 46, 9, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("MANDELBROT", 18, 13);
  char text[48];
  snprintf(text, sizeof(text), "%lux", (unsigned long)(1UL << zoom));
  tft.setTextDatum(TR_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.drawString(text, 222, 18);
  // Enough coordinate precision for the maximum zoom, within a 204px line.
  snprintf(text, sizeof(text), "C %.8f %+.8fi", centerRe, centerIm);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString(text, 18, 37);
}

static void drawStatus() {
  tft.fillRect(16, 298, 208, 10, UI_PANEL);
  tft.setTextFont(1);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(rendering ? UI_CYAN : UI_MUTED, UI_PANEL);
  const char *state = rendering ? (block == 8 ? "PREVIEW" : block > 1 ? "REFINING" : "DETAIL") : "READY";
  tft.drawString(state, 16, 299);
  char text[20];
  snprintf(text, sizeof(text), "%d ITER", limit);
  tft.setTextDatum(TR_DATUM);
  tft.drawString(text, 224, 299);
  tft.fillRect(8, 58, 224, 2, UI_SURFACE);
  int pass = block == 8 ? 0 : block == 4 ? 1 : block == 2 ? 2 : 3;
  int progress = rendering ? (pass * H + row) * W / (H * 4) : W;
  if (progress) tft.fillRect(8, 58, progress, 2, UI_CYAN);
  lastStatus = millis();
}

static void drawFooter() {
  tft.fillRoundRect(8, 280, 224, 32, 8, UI_PANEL);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("D-PAD PAN  SHOOT OPTIONS", 120, 289);
  drawStatus();
}

static void beginRender() {
  // Cancel all old refinement, including a pixel interrupted mid-iteration.
  pixel.active = false;
  navigationPending = false;
  rendering = true; block = 8; column = row = 0;
  limit = 96 + zoom * 20;
  drawHeader();
  drawFooter();
}

static void crosshair() {
  int cx = X + W / 2, cy = Y + H / 2;
  tft.drawFastHLine(cx - 7, cy, 5, TFT_WHITE);
  tft.drawFastHLine(cx + 3, cy, 5, TFT_WHITE);
  tft.drawFastVLine(cx, cy - 7, 5, TFT_WHITE);
  tft.drawFastVLine(cx, cy + 3, 5, TFT_WHITE);
}

static void renderSlice() {
  if (!rendering || menu || navigationPending) return;
  unsigned long started = micros();
  double scale = pixelScale();
  // Keep partial scanline state across loops. A difficult boundary pixel
  // cannot force the rest of the image to finish before controls are polled.
  do {
    int bw = min(block, W - column), bh = min(block, H - row);
    uint16_t color;
    if (!sample(centerRe + (column + bw * 0.5 - W * 0.5) * scale,
                centerIm + (H * 0.5 - row - bh * 0.5) * scale, color, started)) return;
    for (int dy = 0; dy < bh; ++dy)
      for (int dx = 0; dx < bw; ++dx) strip[dy * W + column + dx] = color;
    column += bw;
    if (column == W) {
      tft.setSwapBytes(true);
      tft.pushImage(X, Y + row, W, bh, strip);
      row += bh; column = 0;
      if (row == H) {
        if (block == 1) {
          rendering = false;
          crosshair(); drawStatus();
          return;
        }
        block /= 2; row = 0;
        drawStatus();
      }
      // Limit each loop to a single display transfer as well as the CPU budget.
      return;
    }
  } while ((unsigned long)(micros() - started) < WORK_US);
  if (millis() - lastStatus >= 200) drawStatus();
}

static void requireRelease() {
  inputArmed = false;
  shootHeld = holdSent = false;
  rawButton = -2;
  navigationPending = false;
  scanChannel = validChannels = 0;
  rawChangedAt = millis();
}

static int input() {
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'w' || c == 'W') return 0;
    if (c == 'd' || c == 'D') return 1;
    if (c == 's' || c == 'S') return 2;
    if (c == 'a' || c == 'A') return 3;
    if (c == 'e' || c == 'E' || c == ' ') return 4;
    if (c == 'q' || c == 'Q') return 5;
  }
  // Read just one completed conversion per loop, instead of waiting for all
  // four before returning to the renderer. Cached readings retain the same
  // stable-press filter; partial scans never arm input after a screen change.
  int button = -1, count = 0;
  bool uncertain = false;
  if (digitalRead(SHOOT)) button = 4;
  else if (adsConnected) {
    readings[scanChannel] = ads.readADC_SingleEnded(scanChannel);
    validChannels |= 1 << scanChannel;
    scanChannel = (scanChannel + 1) % 4;
    if (validChannels != 15) return -1;
    const int portrait[] = {1, 2, 3, 0};
    for (int i = 0; i < 4; ++i) {
      int16_t value = readings[i];
      if (value > 18000) { button = portrait[i]; ++count; }
      else if (value >= 15000) uncertain = true;
    }
    // Ambiguous readings cannot select a direction or count as a release.
    if (count > 1 || uncertain) button = 6;
  }
  unsigned long now = millis();
  // Stop old-frame work immediately while a possible press is debounced.
  // Only a confirmed press changes the view; noise can never move it.
  navigationPending = inputArmed && button >= 0 && button <= 4;
  if (button != rawButton) { rawButton = button; rawChangedAt = now; }
  if (now - rawChangedAt < 30) return -1;
  if (!inputArmed) {
    if (button == -1) { inputArmed = true; shootHeld = holdSent = false; }
    return -1;
  }
  if (button == 6) return -1;
  if (button == 4) {
    if (!shootHeld) { shootHeld = true; holdSent = false; pressedAt = now; }
    if (!holdSent && now - pressedAt >= 850) {
      holdSent = true; inputArmed = false;
      return 5;
    }
  } else if (button == -1 && shootHeld) {
    shootHeld = holdSent = false;
    inputArmed = false;
    return 4;
  } else if (button >= 0 && button <= 3 && !shootHeld) {
    inputArmed = false;
    navigationPending = false;
    return button;
  }
  return -1;
}

static void drawOption(int i) {
  const char *labels[] = {"ZOOM IN  2x", "ZOOM OUT  2x", "RESET VIEW", "BACK TO VIEW", "MAIN MENU"};
  int y = 110 + i * 25;
  tft.fillRoundRect(28, y, 184, 22, 4, UI_ICON_BG);
  if (i == option) {
    tft.drawRoundRect(28, y, 184, 22, 4, TFT_MAGENTA);
    tft.drawRoundRect(29, y + 1, 182, 20, 3, TFT_MAGENTA);
  }
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(i == option ? UI_TEXT : UI_MUTED, UI_ICON_BG);
  const char *label = i == 0 && zoom == MAX_ZOOM ? "ZOOM IN  (MAX)" :
                      i == 1 && zoom == 0 ? "ZOOM OUT  (MIN)" : labels[i];
  tft.drawString(label, 120, y + 11);
}

static void openMenu() {
  menu = true; option = 0;
  requireRelease();
  tft.fillRoundRect(18, 76, 204, 180, 10, UI_PANEL);
  tft.drawRoundRect(18, 76, 204, 180, 10, UI_SURFACE);
  tft.setTextFont(2);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("VIEW OPTIONS", 120, 92);
  for (int i = 0; i < OPTIONS; ++i) drawOption(i);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("LEFT / RIGHT  QUICK ZOOM", 120, 246);
  tft.fillRoundRect(8, 280, 224, 32, 8, UI_PANEL);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("UP/DN CHOOSE  SHOOT SELECT", 120, 289);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("HOLD SHOOT  BACK TO VIEW", 120, 303);
}

static void changeZoom(int direction) {
  zoom = constrain(zoom + direction, 0, MAX_ZOOM);
  menu = false;
  requireRelease();
  beginRender();
}
} // namespace mandelApp

void mandelbrotSetup() {
  using namespace mandelApp;
  tft.setRotation(2);
  centerRe = -0.5; centerIm = 0; zoom = 0;
  menu = false;
  requireRelease();
  makePalette();
  tft.fillScreen(UI_BG);
  beginRender();
}

void mandelbrotLoop() {
  using namespace mandelApp;
  int cmd = input();
  if (menu) {
    if (cmd == 0 || cmd == 2) {
      int previous = option;
      option = (option + (cmd == 2 ? 1 : OPTIONS - 1)) % OPTIONS;
      drawOption(previous); drawOption(option);
    } else if (cmd == 1 || cmd == 3) changeZoom(cmd == 1 ? 1 : -1);
    else if (cmd == 5) { menu = false; requireRelease(); beginRender(); }
    else if (cmd == 4) {
      if (option == 4) { switchGame(0); return; }
      if (option <= 1) changeZoom(option == 0 ? 1 : -1);
      else {
        if (option == 2) { centerRe = -0.5; centerIm = 0; zoom = 0; }
        menu = false; requireRelease(); beginRender();
      }
    }
    return;
  }
  if (cmd == 4 || cmd == 5) { openMenu(); return; }
  if (cmd >= 0 && cmd <= 3) {
    double shift = pixelScale() * 32;
    // Up moves the center toward positive imaginary values.
    if (cmd == 0) centerIm += shift;
    if (cmd == 2) centerIm -= shift;
    if (cmd == 1) centerRe += shift;
    if (cmd == 3) centerRe -= shift;
    // Keep navigation in a useful neighborhood and labels inside the header.
    centerRe = fmax(-4.0, fmin(4.0, centerRe));
    centerIm = fmax(-4.0, fmin(4.0, centerIm));
    beginRender();
  }
  renderSlice();
}
