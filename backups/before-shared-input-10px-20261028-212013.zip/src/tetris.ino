
#include <string.h>
#include <Preferences.h>
#include "config.h"
#include "game.h"
#include "tetris_input.h"

#define SIZE 12
#define SPACE_WIDTH 17
#define SPACE_HEIGHT 17

constexpr int TETRIS_BOARD_X = 18, TETRIS_BOARD_Y = 50;
constexpr int TETRIS_HUD_Y = 266;
constexpr int TETRIS_HUD_H = 46;
constexpr unsigned long TETRIS_SOFT_DROP_MS = 35;
uint16_t TETRIS_GRID_DARK = 0x0802;
uint16_t TETRIS_GRID_LIGHT = 0x1044;
constexpr uint16_t TETRIS_HIGHLIGHT = 0xFFFF;
static_assert(2 * TETRIS_BOARD_X + SPACE_WIDTH * SIZE == 240, "Board must be horizontally centered");
static_assert(TETRIS_BOARD_Y + SPACE_HEIGHT * SIZE + 12 == TETRIS_HUD_Y, "Board and HUD need a clear gap");
static_assert(TETRIS_HUD_Y + TETRIS_HUD_H <= 312, "HUD must leave a bottom margin");

static uint16_t tetrisMix(uint16_t a, uint16_t b, int amount) {
  int r = (((a >> 11) & 31) * (255 - amount) + ((b >> 11) & 31) * amount) / 255;
  int g = (((a >> 5) & 63) * (255 - amount) + ((b >> 5) & 63) * amount) / 255;
  int blue = ((a & 31) * (255 - amount) + (b & 31) * amount) / 255;
  return (r << 11) | (g << 5) | blue;
}

void drawTetrisHeader() {
  TFT_eSprite header(&tft);
  header.setColorDepth(16);
  if (!header.createSprite(224, 26)) return;
  header.fillSprite(UI_BG);
  for (int x = 0; x < 224; ++x) {
    int inset = x < 7 ? 7 - x : x > 216 ? x - 216 : 0;
    header.drawFastVLine(x, inset, 26 - inset * 2,
                         tetrisMix(uiHeaderStart, uiHeaderEnd, x * 255 / 223));
  }
  header.setTextColor(0x18C5);
  header.setTextDatum(ML_DATUM);
  header.setTextFont(2);
  header.drawString("TETRIS", 10, 13);
  header.setTextDatum(MR_DATUM);
  header.setTextFont(1);
  header.drawString("SHOOT : PAUSE", 214, 13);
  header.pushSprite(8, 8);
}

void drawTetrisPlayfieldFrame() {
  // Also clear the area occupied by pause/game-over dialogs outside the board.
  tft.fillRect(8, 40, 224, 224, UI_BG);
  tft.fillRoundRect(TETRIS_BOARD_X - 4, TETRIS_BOARD_Y - 4,
                    SPACE_WIDTH * SIZE + 8, SPACE_HEIGHT * SIZE + 8, 7, UI_PANEL);
  tft.drawRoundRect(TETRIS_BOARD_X - 4, TETRIS_BOARD_Y - 4,
                    SPACE_WIDTH * SIZE + 8, SPACE_HEIGHT * SIZE + 8, 7,
                    tetrisMix(UI_CYAN, UI_BG, 165));
}

unsigned long drop_interval = 600;
unsigned long lastDrop = 0;
unsigned long lastTick = 0;
unsigned long elapsedPlayMs = 0;
unsigned long lastShownSecond = 0;
unsigned long lastSoftDrop = 0;
bool tetrisDownWasHeld = false;
int tetrisPauseSelection = 0;
uint8_t tetrisPressed = 0;
int tetrisSideHeld = 0;
unsigned long tetrisSideAt = 0;
bool tetrisSideRepeating = false;


uint32_t current_color;
int current_shape;

int current_pos[2] = { 0, 0 };
int prev_pos[2] = { 0, 0 };
bool current_body[4][4];
bool prev_body[4][4];
uint32_t colors[] = { 0xFFE8, 0x4DDF, 0xB7EC, 0xD3BE,
                      0xFD8B, 0xA3DF, 0xFB75, 0x5D9F };
uint32_t space[SPACE_WIDTH * SPACE_HEIGHT];
uint32_t next_color = colors[random(8)];
int next_shape = random(7);

void updatePauseMenu(int dx);
void tetrisSetup();

bool bodies[7][4][4] = {
  { { 0, 0, 0, 0 }, { 1, 1, 1, 1 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 0, 1, 1, 0 }, { 0, 1, 1, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 1, 1, 1, 0 }, { 0, 1, 0, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 1, 1, 1, 0 }, { 1, 0, 0, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 1, 1, 1, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 0, 1, 1, 0 }, { 1, 1, 0, 0 }, { 0, 0, 0, 0 } },
  { { 0, 0, 0, 0 }, { 1, 1, 0, 0 }, { 0, 1, 1, 0 }, { 0, 0, 0, 0 } }
};

int bodySize() {
  return current_shape == 0 ? 4 : 3;
}

int getEncode(int x, int y) {
  return x + y * SPACE_WIDTH;
}

void drawRect(int x, int y, uint32_t color) {
  int px = TETRIS_BOARD_X + x * SIZE, py = TETRIS_BOARD_Y + y * SIZE;
  tft.fillRect(px, py, SIZE, SIZE, (x + y) % 2 ? TETRIS_GRID_LIGHT : TETRIS_GRID_DARK);
  tft.fillRect(px + 1, py + 1, SIZE - 2, SIZE - 2, color);
}

void drawRect(int x, int y) {
  int px = TETRIS_BOARD_X + x * SIZE;
  int py = TETRIS_BOARD_Y + y * SIZE;
  tft.fillRect(px, py, SIZE, SIZE, (x + y) % 2 ? TETRIS_GRID_LIGHT : TETRIS_GRID_DARK);
}

void redrawChangedCells() {
  tft.startWrite();
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4; j++) {
      int px_old = prev_pos[0] + i - 1;
      int py_old = prev_pos[1] + j - 1;
      int px_new = current_pos[0] + i - 1;
      int py_new = current_pos[1] + j - 1;

      if (prev_body[i][j]) {
        bool still_covered = false;
        int di = px_old - (current_pos[0] - 1);
        int dj = py_old - (current_pos[1] - 1);
        if (di >= 0 && di < 4 && dj >= 0 && dj < 4 && current_body[di][dj])
          still_covered = true;

        if (!still_covered && px_old >= 0 && px_old < SPACE_WIDTH
            && py_old >= 0 && py_old < SPACE_HEIGHT) {
          uint32_t dead = space[getEncode(px_old, py_old)];
          if (dead != TFT_BLACK) drawRect(px_old, py_old, dead);
          else drawRect(px_old, py_old);
        }
      }

      if (current_body[i][j] && px_new >= 0 && px_new < SPACE_WIDTH
          && py_new >= 0 && py_new < SPACE_HEIGHT) {
        drawRect(px_new, py_new, current_color);
      }
    }
  }
  tft.endWrite();
}

void drawBody() {
  tft.startWrite();
  int x = current_pos[0];
  int y = current_pos[1];
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      if (current_body[i][j]) {
        int px = i + x - 1;
        int py = j + y - 1;
        if (px >= 0 && px < SPACE_WIDTH && py >= 0 && py < SPACE_HEIGHT)
          drawRect(px, py, current_color);
      }
  tft.endWrite();
}

void drawNext() {
  TFT_eSprite preview(&tft);
  preview.setColorDepth(16);
  if (!preview.createSprite(56, 26)) return;
  preview.fillSprite(UI_PANEL);
  int minX = 4, minY = 4, maxX = 0, maxY = 0;
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      if (bodies[next_shape][i][j]) {
        minX = min(minX, i); maxX = max(maxX, i);
        minY = min(minY, j); maxY = max(maxY, j);
      }
  int left = (56 - (maxX - minX + 1) * 6) / 2;
  int top = (26 - (maxY - minY + 1) * 6) / 2;
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++) {
      if (!bodies[next_shape][i][j]) continue;
      int x = left + (i - minX) * 6, y = top + (j - minY) * 6;
      preview.fillRect(x, y, 5, 5, next_color);
    }
  preview.pushSprite(92, TETRIS_HUD_Y + 17);
}

void redrawRowsAbove(int cleared_row) {
  tft.startWrite();
  for (int y = 0; y <= cleared_row; y++) {
    for (int x = 0; x < SPACE_WIDTH; x++) {
      uint32_t c = space[getEncode(x, y)];
      if (c != TFT_BLACK) drawRect(x, y, c);
      else drawRect(x, y);
    }
  }
  tft.endWrite();
}

void drawMenu(void) {
  const int cardX[] = {8, 84, 160};
  for (int i = 0; i < 3; i++) {
    tft.fillRoundRect(cardX[i], TETRIS_HUD_Y, 72, TETRIS_HUD_H, 7, UI_PANEL);
    tft.drawRoundRect(cardX[i], TETRIS_HUD_Y, 72, TETRIS_HUD_H, 7, UI_SURFACE);
  }
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.drawString("SCORE", 16, TETRIS_HUD_Y + 7);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.drawString("NEXT", 92, TETRIS_HUD_Y + 7);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.drawString("TIME", 168, TETRIS_HUD_Y + 7);
}

void drawTetrisScore() {
  char buf[16];
  snprintf(buf, sizeof(buf), "%d", score);
  TFT_eSprite value(&tft);
  value.setColorDepth(16);
  if (!value.createSprite(56, 24)) return;
  value.fillSprite(UI_PANEL);
  value.setTextDatum(TL_DATUM);
  value.setTextFont(2);
  if (value.textWidth(buf) > 56) value.setTextFont(1);
  value.setTextColor(UI_TEXT);
  value.drawString(buf, 0, 2);
  value.pushSprite(16, TETRIS_HUD_Y + 20);
}

void updateScore() {
  score += 10;
  drawTetrisScore();
}

void updateTime() {
  unsigned long totalSeconds = elapsedPlayMs / 1000;
  char buffer[16];
  snprintf(buffer, sizeof(buffer), "%02lu:%02lu", totalSeconds / 60, totalSeconds % 60);
  TFT_eSprite value(&tft);
  value.setColorDepth(16);
  if (!value.createSprite(56, 24)) return;
  value.fillSprite(UI_PANEL);
  value.setTextDatum(TL_DATUM);
  value.setTextFont(2);
  if (value.textWidth(buffer) > 56) value.setTextFont(1);
  value.setTextColor(UI_TEXT);
  value.drawString(buffer, 0, 2);
  value.pushSprite(168, TETRIS_HUD_Y + 20);
}

void addToDead() {
  int x = current_pos[0];
  int y = current_pos[1];
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++) {
      int px = x + i - 1;
      int py = y + j - 1;
      if (px >= 0 && px < SPACE_WIDTH && py >= 0 && py < SPACE_HEIGHT)
        if (current_body[i][j])
          space[getEncode(px, py)] = current_color;
    }
}

bool checkCollision(int dx, int dy) {
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      if (current_body[i][j]) {
        int px = current_pos[0] + i - 1 + dx;
        int py = current_pos[1] + j - 1 + dy;
        if (px < 0 || px >= SPACE_WIDTH || py >= SPACE_HEIGHT) return true;
        if (py >= 0 && space[getEncode(px, py)] != TFT_BLACK) return true;
      }
  return false;
}

bool newTetro() {
  current_color = next_color;
  current_shape = next_shape;
  next_color = colors[random(8)];
  next_shape = random(7);
  current_pos[0] = (SPACE_WIDTH - 4) / 2 + 1;
  current_pos[1] = 1;
  drawNext();

  for (int j = 0; j < SPACE_HEIGHT; j++) {
    int fill = 0;
    for (int i = 0; i < SPACE_WIDTH; i++)
      if (space[getEncode(i, j)] != TFT_BLACK) fill++;

    if (fill == SPACE_WIDTH) {
      for (int y = j; y > 0; y--)
        for (int x = 0; x < SPACE_WIDTH; x++)
          space[getEncode(x, y)] = space[getEncode(x, y - 1)];

      for (int x = 0; x < SPACE_WIDTH; x++)
        space[getEncode(x, 0)] = TFT_BLACK;

      redrawRowsAbove(j);
      updateScore();
      j--;
    }
  }

  memcpy(current_body, bodies[current_shape], sizeof(current_body));
  memcpy(prev_pos, current_pos, sizeof(current_pos));
  memcpy(prev_body, current_body, sizeof(current_body));
  return !checkCollision(0, 0);
}

void tryRotate() {
  if (current_shape == 1) return; // Rotating the square should not move it.
  bool temp[4][4] = {};
  int size = bodySize();
  for (int i = 0; i < size; i++)
    for (int j = 0; j < size; j++)
      temp[i][j] = current_body[size - 1 - j][i];

  for (int i = 0; i < size; i++)
    for (int j = 0; j < size; j++)
      if (temp[i][j]) {
        int px = current_pos[0] + i - 1;
        int py = current_pos[1] + j - 1;
        if (px < 0 || px >= SPACE_WIDTH || py >= SPACE_HEIGHT) return;
        if (py >= 0 && space[getEncode(px, py)] != TFT_BLACK) return;
      }

  memcpy(prev_pos, current_pos, sizeof(current_pos));
  memcpy(prev_body, current_body, sizeof(current_body));
  memcpy(current_body, temp, sizeof(temp));
  redrawChangedCells();
}

void updatePosition(int dx = 0, int dy = 1) {
  if (!checkCollision(dx, dy)) {
    memcpy(prev_pos, current_pos, sizeof(current_pos));
    memcpy(prev_body, current_body, sizeof(current_body));
    current_pos[0] += dx;
    current_pos[1] += dy;
    redrawChangedCells();
  } else if (dy == 1) {
    addToDead();
    playTetrisDropSound();
    if (!newTetro()) {
      gameState = 2;
      menu_drawn = false;
      tetrisInputRequireRelease();
    } else drawBody();
  }
}




void getCommand() {
  if (tetrisPressed & 16) {
    gameState = 1;
    menu_drawn = false;
    tetrisPauseSelection = 0;
    tetrisInputRequireRelease();
    tetrisSideHeld = 0;
    return;
  }
  if (tetrisPressed & 1) tryRotate();
  uint8_t held = tetrisInputHeld();
  int side = ((held & 2) != 0) - ((held & 8) != 0);
  unsigned long now = millis();
  if (side != tetrisSideHeld) {
    tetrisSideHeld = side;
    tetrisSideAt = now;
    tetrisSideRepeating = false;
    if (side) updatePosition(side, 0);
  } else if (side && now - tetrisSideAt >= (tetrisSideRepeating ? 65UL : 180UL)) {
    updatePosition(side, 0);
    tetrisSideAt = now;
    tetrisSideRepeating = true;
  }
}


void restoreAfterPauseTetris() {
  drawTetrisPlayfieldFrame();
  tft.startWrite();
  for (int y = 0; y < SPACE_HEIGHT; y++)
    for (int x = 0; x < SPACE_WIDTH; x++) {
      uint32_t c = space[getEncode(x, y)];
      if (c != TFT_BLACK) drawRect(x, y, c);
      else drawRect(x, y);
    }
  tft.endWrite();
  drawBody();
  lastDrop = millis();
  lastTick = lastDrop;
  lastSoftDrop = lastDrop;
  tetrisDownWasHeld = false;
  gameState = 0;
  menu_drawn = false;
  tetrisSideHeld = 0;
  tetrisInputRequireRelease();
}

void drawTetrisPauseOption(int item) {
  const char* labels[] = {"RESUME", "RESTART", "MAIN MENU"};
  int y = 130 + item * 34;
  bool selected = item == tetrisPauseSelection;
  uint16_t fill = selected ? uiHeaderStart : UI_ICON_BG;
  tft.fillRoundRect(40, y, 160, 30, 6, fill);
  if (selected) {
    tft.drawRoundRect(40, y, 160, 30, 6, UI_CYAN);
    tft.drawRoundRect(41, y + 1, 158, 28, 5, UI_CYAN);
  }
  tft.setTextDatum(ML_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(selected ? 0x18C5 : UI_TEXT, fill);
  tft.drawString(labels[item], 52, y + 15);
  if (selected) {
    tft.setTextDatum(MR_DATUM);
    tft.drawString(">", 188, y + 15);
  }
}

void drawTetrisPauseMenu() {
  tft.fillRoundRect(26, 61, 188, 177, 12, UI_PANEL);
  tft.drawRoundRect(26, 61, 188, 177, 12, UI_SURFACE);
  tft.fillRoundRect(40, 75, 160, 31, 6, uiHeaderStart);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(0x18C5, uiHeaderStart);
  tft.drawString("TAKE A BREAK", 50, 82);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("UP / DOWN TO CHOOSE", 40, 116);
  for (int item = 0; item < 3; item++) drawTetrisPauseOption(item);
}

void handleTetrisPause() {
  int pressed = (tetrisPressed & 16) ? 4 : (tetrisPressed & 1) ? 0 : (tetrisPressed & 4) ? 2 : -1;
  if (pressed == 0 || pressed == 2) {
    int oldSelection = tetrisPauseSelection;
    tetrisPauseSelection = (tetrisPauseSelection + (pressed == 0 ? 2 : 1)) % 3;
    drawTetrisPauseOption(oldSelection);
    drawTetrisPauseOption(tetrisPauseSelection);
    playNavClick();
  } else if (pressed == 4) {
    playSelectTone();
    if (tetrisPauseSelection == 0) restoreAfterPauseTetris();
    else if (tetrisPauseSelection == 1) tetrisSetup();
    else switchGame(0);
  }
}

void drawTetrisGameOver() {
  currentGame.recordScore(score);
  tft.fillRoundRect(26, 63, 188, 174, 12, UI_PANEL);
  tft.drawRoundRect(26, 63, 188, 174, 12, UI_SURFACE);
  tft.fillRoundRect(40, 77, 160, 22, 5, uiHeaderStart);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(0x18C5, uiHeaderStart);
  tft.drawString("TETRIS / FINISHED", 50, 84);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("GAME OVER", 40, 105);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("SCORE", 40, 143);
  tft.drawString("BEST", 133, 143);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(String(score), 40, 155);
  tft.drawString(String(currentGame.highScores[0]), 133, 155);
  tft.drawFastHLine(40, 184, 160, UI_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("SHOOT  RETRY", 40, 197);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("UP  MAIN MENU", 40, 216);
}

void handleTetrisGameOver() {
  int pressed = (tetrisPressed & 16) ? 4 : (tetrisPressed & 1) ? 0 : -1;
  if (pressed == 4) tetrisSetup();
  else if (pressed == 0) switchGame(0);
}



void tetrisSetup() {
  tetrisInputBegin();
  tetrisSideHeld = 0;
  TETRIS_GRID_DARK = tetrisMix(UI_BG, UI_PURPLE, 14);
  TETRIS_GRID_LIGHT = tetrisMix(UI_BG, UI_PURPLE, 26);
  score = 0;
  gameState = 0;
  menu_drawn = false;
  drop_interval = 600;
  elapsedPlayMs = 0;
  lastShownSecond = 0;
  tetrisPauseSelection = 0;
  lastDrop = millis();
  lastTick = lastDrop;
  lastSoftDrop = lastDrop;
  tetrisDownWasHeld = false;
  next_color = colors[random(8)];
  next_shape = random(7);
  for (int i = 0; i < SPACE_WIDTH * SPACE_HEIGHT; i++)
    space[i] = TFT_BLACK;

  tft.setRotation(2);
  tft.fillScreen(UI_BG);
  drawTetrisHeader();
  drawTetrisPlayfieldFrame();

  tft.startWrite();
  for (int i = 0; i < SPACE_WIDTH; i++)
    for (int j = 0; j < SPACE_HEIGHT; j++)
      drawRect(i, j);
  tft.endWrite();

  drawMenu();
  drawTetrisScore();
  updateTime();
  newTetro();
  drawBody();
  lastDrop = millis();
  lastTick = lastDrop;
}

void tetrisLoop() {
  tetrisPressed = tetrisInputPoll();
  if (gameState == 0) {
    unsigned long currentTime = millis();
    elapsedPlayMs += currentTime - lastTick;
    lastTick = currentTime;
    getCommand();
    if (gameState != 0) return;
    currentTime = millis();

    bool downHeld = (tetrisInputHeld() & 4) != 0;
    if (downHeld && (!tetrisDownWasHeld ||
                     currentTime - lastSoftDrop >= TETRIS_SOFT_DROP_MS)) {
      updatePosition(0, 1);
      if (gameState != 0) return;
      lastSoftDrop = millis();
      lastDrop = lastSoftDrop;
      currentTime = lastSoftDrop;
    }
    tetrisDownWasHeld = downHeld;

    unsigned long shownSecond = elapsedPlayMs / 1000;
    if (shownSecond != lastShownSecond) {
      lastShownSecond = shownSecond;
      updateTime();
    }

    if (currentTime - lastDrop >= drop_interval) {
      lastDrop = currentTime;
      updatePosition();
    }
  } else if (gameState == 1) {
    if (!menu_drawn) {
      drawTetrisPauseMenu();
      menu_drawn = true;
    }
    handleTetrisPause();
  } else if (gameState == 2) {
    if (!menu_drawn) {
      drawTetrisGameOver();
      menu_drawn = true;
    }
    handleTetrisGameOver();
  }
}
