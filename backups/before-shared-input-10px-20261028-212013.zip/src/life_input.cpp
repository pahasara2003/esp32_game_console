#include <Arduino.h>
#include <Adafruit_ADS1X15.h>
#include "game.h"

extern Adafruit_ADS1115 ads;
extern bool adsConnected;

namespace lifeInput {
static bool active = false;
static uint16_t previousRate;
static uint8_t channel = 0, highSamples[4] = {}, lowSamples[4] = {};
static bool settling = true, requireRelease = true;
static bool down[4] = {};
static int held = -1;
static unsigned long lastCheck = 0, lastRepeat = 0;
static constexpr uint16_t MUX[] = {
  ADS1X15_REG_CONFIG_MUX_SINGLE_0, ADS1X15_REG_CONFIG_MUX_SINGLE_1,
  ADS1X15_REG_CONFIG_MUX_SINGLE_2, ADS1X15_REG_CONFIG_MUX_SINGLE_3
};
}

void lifeInputRequireRelease() {
  lifeInput::requireRelease = true;
  memset(lifeInput::lowSamples, 0, sizeof(lifeInput::lowSamples));
}

void lifeInputEnd() {
  if (lifeInput::active && adsConnected) ads.setDataRate(lifeInput::previousRate);
  lifeInput::active = false;
}

void lifeInputBegin() {
  using namespace lifeInput;
  lifeInputEnd();
  if (!adsConnected) return;
  previousRate = ads.getDataRate();
  ads.setDataRate(RATE_ADS1115_860SPS);
  channel = 0;
  held = -1;
  memset(down, 0, sizeof(down));
  memset(highSamples, 0, sizeof(highSamples));
  memset(lowSamples, 0, sizeof(lowSamples));
  settling = requireRelease = true;
  lastCheck = lastRepeat = millis();
  active = true;
  ads.startADCReading(MUX[channel], false);
}

int lifeInputPoll(bool repeat) {
  using namespace lifeInput;
  if (!active || !adsConnected) return -1;
  unsigned long now = millis();
  // Start a conversion and return immediately. Simulation never waits for ADC.
  if (now - lastCheck >= 1) {
    lastCheck = now;
    if (ads.conversionComplete()) {
      int16_t sample = ads.getLastConversionResults();
      // Discard the first conversion after switching inputs. This lets the
      // ADC input settle instead of treating the previous button as this one.
      if (settling) {
        settling = false;
        ads.startADCReading(MUX[channel], false);
        return -1;
      }
      if (sample > 18000) {
        lowSamples[channel] = 0;
        if (highSamples[channel] < 2) ++highSamples[channel];
        if (highSamples[channel] == 2) down[channel] = true;
      } else {
        // Debounce requires consecutive high readings, not accumulated noise.
        highSamples[channel] = 0;
        if (sample < 15000) {
          if (lowSamples[channel] < 2) ++lowSamples[channel];
          if (lowSamples[channel] == 2) down[channel] = false;
        } else lowSamples[channel] = 0;
      }
      channel = (channel + 1) % 4;
      settling = true;
      ads.startADCReading(MUX[channel], false);
    }
  }
  if (requireRelease) {
    for (int i = 0; i < 4; ++i)
      if (down[i] || lowSamples[i] < 2) return -1;
    requireRelease = false;
    held = -1;
    return -1;
  }
  const int portraitMap[] = {1, 2, 3, 0};
  int current = -1;
  for (int i = 0; i < 4; ++i) if (down[i]) { current = portraitMap[i]; break; }
  if (current != held) {
    held = current;
    lastRepeat = now;
    if (!repeat && current >= 0) lifeInputRequireRelease();
    return current;
  }
  if (repeat && held >= 0 && now - lastRepeat >= 140) {
    lastRepeat = now;
    return held;
  }
  return -1;
}
