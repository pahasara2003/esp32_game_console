#include <cstdint>
#ifndef CONFIG_H
#define CONFIG_H


// Neutral dark palette: black canvas and charcoal surfaces.
#define UI_BG        0x0000
#define UI_PANEL     0x1082
#define UI_SURFACE   0x2104

#define UI_CYAN      0x2EDC
#define UI_GREEN     0xA7E9
#define UI_PURPLE    0xB37F
#define UI_YELLOW    0xFE4A
#define UI_RED       0xFA8D

#define UI_TEXT      0xEF7D
#define UI_MUTED     0x8C51
#define UI_ICON_BG   0x18C3

#define MARGIN_X 10
#define MARGIN_Y 10
#define BG1 UI_BG
#define BG2 UI_PANEL
#define SCREEN_H 240
#define SCREEN_W 320

#define TILE_COLOR   UI_SURFACE
#define TEXT_COLOR   UI_CYAN
#define TITLE_COLOR  UI_YELLOW
#define BG_COLOR     UI_BG

#define SHOOT 5
#define BUZZER_PIN 10

// Neutral shades used by the boot background.
static const uint16_t bgs[] = {
  UI_BG,
  0x0841,
  UI_PANEL,
  UI_ICON_BG,
  UI_SURFACE
};

inline uint16_t bg() {
  return bgs[random(0, sizeof(bgs) / sizeof(bgs[0]))];
}
extern int score;
extern int gameState;
extern int menu_drawn;

#endif
