#include "game.h"


Game currentGame;

void setup() {
  init_interface();
  currentGame = Game(0);
  currentGame.gameSetup();
}

void loop() {
  currentGame.gameLoop();
}
