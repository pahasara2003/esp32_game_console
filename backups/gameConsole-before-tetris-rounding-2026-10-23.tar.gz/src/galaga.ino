#include "game.h"
#include <Arduino.h>

// =================================================================
// MODERN VERTICAL SPACE SHOOTER / GALAGA (240x320 PORTRAIT)
// =================================================================

// Portrait dimensions: 240 width x 320 height (Rotation 2)
// Header Card: y = 5..43 (h = 38)
// Playfield Area: y = 48..290 (w = 240, h = 242)
// Player ship base: y = 268
// Bottom Dynamic Pill Bar: y = 295..316 (h = 21)

constexpr int GALA_W = 240;
constexpr int GALA_H = 320;
constexpr int GALA_PLAYFIELD_TOP = 48;
constexpr int GALA_PLAYFIELD_BOTTOM = 290;

constexpr int SHIP_W = 18;
constexpr int SHIP_H = 16;
constexpr int SHIP_Y = 268;
constexpr int SHIP_SPEED = 7;

constexpr int MAX_PLAYER_BULLETS = 4;
constexpr int MAX_ALIEN_BULLETS = 6;
constexpr int ALIEN_ROWS = 3;
constexpr int ALIEN_COLS = 5;
constexpr int TOTAL_ALIENS = ALIEN_ROWS * ALIEN_COLS; // 15 aliens per fleet

// Modern Colors (OLED Dark UI)
constexpr uint16_t GALA_BG      = UI_BG;
constexpr uint16_t GALA_CARD    = UI_PANEL;
constexpr uint16_t GALA_SURFACE = UI_SURFACE;
constexpr uint16_t GALA_WHITE   = UI_TEXT;
constexpr uint16_t GALA_MUTED   = UI_MUTED;
constexpr uint16_t GALA_CYAN    = UI_CYAN;
constexpr uint16_t GALA_GREEN   = 0x3666;
constexpr uint16_t GALA_AMBER   = 0xFE04;
constexpr uint16_t GALA_RED     = 0xFA48;
constexpr uint16_t GALA_PURPLE  = 0xB37F;

// -----------------------------------------------------------------
// GAME STRUCTURES & STATE
// -----------------------------------------------------------------
struct GalaBullet {
  float x, y;
  float vy;
  bool active;
};

struct GalaAlien {
  float x, y;
  float formX, formY;
  int type; // 0 = drone, 1 = fighter, 2 = commander
  bool active;
  bool diving;
  float diveAngle;
  float diveSpeed;
};

static GalaBullet pBullets[MAX_PLAYER_BULLETS];
static GalaBullet aBullets[MAX_ALIEN_BULLETS];
static GalaAlien aliens[TOTAL_ALIENS];

static int shipX = (GALA_W - SHIP_W) / 2;
static int prevShipX = shipX;
static int galaLives = 3;
static int galaWave = 1;
static unsigned long lastPlayerShot = 0;
static unsigned long lastAlienShot = 0;

static float fleetOffsetX = 0;
static float fleetDir = 1.0f;
static unsigned long lastFleetMove = 0;

static int galaPauseSelection = 0;
static bool galaPauseReady = false;
static bool galaShootReady = false;

// Starfield background
struct GalaStar {
  float x, y;
  float speed;
  uint16_t color;
};
static GalaStar stars[25];

// -----------------------------------------------------------------
// SOUND EFFECTS
// -----------------------------------------------------------------
static void soundPlayerLaser() {
  ledcWriteTone(BUZZER_LEDC_CH, 1568); // G6
  delay(15);
  ledcWriteTone(BUZZER_LEDC_CH, 2093); // C7
  delay(20);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

static void soundAlienHit() {
  ledcWriteTone(BUZZER_LEDC_CH, 988);
  delay(20);
  ledcWriteTone(BUZZER_LEDC_CH, 659);
  delay(30);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

static void soundPlayerExplode() {
  ledcWriteTone(BUZZER_LEDC_CH, 330);
  delay(50);
  ledcWriteTone(BUZZER_LEDC_CH, 220);
  delay(70);
  ledcWriteTone(BUZZER_LEDC_CH, 147);
  delay(100);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

// -----------------------------------------------------------------
// STARFIELD RENDERING
// -----------------------------------------------------------------
static void initStarfield() {
  for (int i = 0; i < 25; i++) {
    stars[i].x = random(0, GALA_W);
    stars[i].y = random(GALA_PLAYFIELD_TOP + 5, GALA_PLAYFIELD_BOTTOM - 5);
    stars[i].speed = random(10, 30) / 10.0f;
    int b = random(0, 3);
    stars[i].color = (b == 0) ? UI_MUTED : (b == 1 ? UI_SURFACE : 0xFFFF);
  }
}

static void updateStarfield() {
  for (int i = 0; i < 25; i++) {
    tft.drawPixel((int)stars[i].x, (int)stars[i].y, GALA_BG);
    stars[i].y += stars[i].speed;
    if (stars[i].y > GALA_PLAYFIELD_BOTTOM) {
      stars[i].y = GALA_PLAYFIELD_TOP + 2;
      stars[i].x = random(0, GALA_W);
    }
    tft.drawPixel((int)stars[i].x, (int)stars[i].y, stars[i].color);
  }
}

// -----------------------------------------------------------------
// MODERN IPHONE HEADER & HUD
// -----------------------------------------------------------------
static void drawGalagaHeader() {
  // Island Card Header: x=8, y=5, w=224, h=38
  tft.fillRoundRect(8, 5, 224, 38, 10, GALA_CARD);
  tft.drawRoundRect(8, 5, 224, 38, 10, GALA_SURFACE);

  // Left Tag: Pill Tag
  tft.fillRoundRect(16, 12, 50, 24, 6, GALA_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(GALA_PURPLE, GALA_SURFACE);
  tft.drawString("GALAGA", 41, 24);

  // Center: Score Pill
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("SCORE", 76, 11);
  tft.setTextFont(2);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 76, 21);

  // Right: Lives & Sector
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("SHIPS", 218, 11);

  // Ship markers
  tft.fillRect(174, 23, 46, 10, GALA_CARD);
  for (int i = 0; i < 3; i++) {
    uint16_t shipCol = (i < galaLives) ? GALA_CYAN : GALA_SURFACE;
    tft.fillTriangle(178 + i * 14, 31, 182 + i * 14, 23, 186 + i * 14, 31, shipCol);
  }
}

static void updateGalagaScoreHUD() {
  tft.fillRect(76, 21, 55, 18, GALA_CARD);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 76, 21);

  // Lives refresh
  tft.fillRect(174, 23, 46, 10, GALA_CARD);
  for (int i = 0; i < 3; i++) {
    uint16_t shipCol = (i < galaLives) ? GALA_CYAN : GALA_SURFACE;
    tft.fillTriangle(178 + i * 14, 31, 182 + i * 14, 23, 186 + i * 14, 31, shipCol);
  }
}

static void drawGalagaBottomBar() {
  tft.fillRoundRect(8, 295, 224, 21, 6, GALA_CARD);
  tft.setTextFont(1);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("D-PAD: MOVE  |  SHOOT: FIRE LASER", 120, 305);
}

// -----------------------------------------------------------------
// SHIP & ALIEN RENDERING
// -----------------------------------------------------------------
static void drawShip(int px, int py) {
  // Sleek neo-retro starfighter
  tft.fillTriangle(px + 8, py, px + 2, py + 14, px + 14, py + 14, GALA_CYAN);
  tft.fillRoundRect(px + 6, py + 4, 5, 8, 2, 0xFFFF); // Cockpit
  tft.fillRect(px, py + 10, 3, 5, GALA_RED);          // Left wingtip
  tft.fillRect(px + 15, py + 10, 3, 5, GALA_RED);     // Right wingtip
  tft.fillRect(px + 7, py + 14, 3, 2, GALA_AMBER);    // Engine thruster
}

static void eraseShip(int px, int py) {
  tft.fillRect(px - 1, py - 1, SHIP_W + 2, SHIP_H + 2, GALA_BG);
}

static void drawAlienSprite(int x, int y, int type) {
  if (type == 2) { // Boss Commander (Neon Purple & Gold)
    tft.fillRoundRect(x, y + 2, 16, 8, 3, GALA_PURPLE);
    tft.fillCircle(x + 5, y + 5, 2, GALA_AMBER);
    tft.fillCircle(x + 11, y + 5, 2, GALA_AMBER);
    tft.drawFastHLine(x + 3, y + 10, 10, 0xFFFF);
  } else if (type == 1) { // Fighter (Emerald Green)
    tft.fillTriangle(x + 8, y + 9, x + 2, y + 2, x + 14, y + 2, GALA_GREEN);
    tft.fillCircle(x + 8, y + 5, 3, GALA_CYAN);
  } else { // Drone (Crimson Red)
    tft.fillRoundRect(x + 2, y + 2, 12, 7, 2, GALA_RED);
    tft.fillCircle(x + 5, y + 4, 1, 0xFFFF);
    tft.fillCircle(x + 10, y + 4, 1, 0xFFFF);
    tft.drawFastVLine(x + 3, y + 9, 3, GALA_RED);
    tft.drawFastVLine(x + 12, y + 9, 3, GALA_RED);
  }
}

static void eraseAlienSprite(int x, int y) {
  tft.fillRect(x - 2, y - 2, 20, 15, GALA_BG);
}

// -----------------------------------------------------------------
// BULLETS & COMBAT PHYSICS
// -----------------------------------------------------------------
static void firePlayerLaser() {
  if (millis() - lastPlayerShot < 220) return; // Cooldown
  for (int i = 0; i < MAX_PLAYER_BULLETS; i++) {
    if (!pBullets[i].active) {
      pBullets[i].x = shipX + SHIP_W / 2.0f;
      pBullets[i].y = SHIP_Y - 4;
      pBullets[i].vy = -8.5f;
      pBullets[i].active = true;
      lastPlayerShot = millis();
      soundPlayerLaser();
      break;
    }
  }
}

static void alienShoot(int ax, int ay) {
  if (millis() - lastAlienShot < 700) return;
  for (int i = 0; i < MAX_ALIEN_BULLETS; i++) {
    if (!aBullets[i].active) {
      aBullets[i].x = ax + 8;
      aBullets[i].y = ay + 12;
      aBullets[i].vy = 4.5f;
      aBullets[i].active = true;
      lastAlienShot = millis();
      break;
    }
  }
}

static void updateBullets() {
  // Update Player Lasers
  for (int i = 0; i < MAX_PLAYER_BULLETS; i++) {
    if (pBullets[i].active) {
      tft.drawFastVLine((int)pBullets[i].x, (int)pBullets[i].y, 6, GALA_BG);
      pBullets[i].y += pBullets[i].vy;

      if (pBullets[i].y < GALA_PLAYFIELD_TOP + 2) {
        pBullets[i].active = false;
        continue;
      }

      // Check hit with Aliens
      bool hit = false;
      for (int a = 0; a < TOTAL_ALIENS; a++) {
        if (aliens[a].active) {
          int ax = (int)aliens[a].x;
          int ay = (int)aliens[a].y;
          if (pBullets[i].x >= ax && pBullets[i].x <= ax + 16 &&
              pBullets[i].y >= ay && pBullets[i].y <= ay + 12) {
            aliens[a].active = false;
            eraseAlienSprite(ax, ay);
            pBullets[i].active = false;
            hit = true;
            soundAlienHit();

            score += (aliens[a].type == 2) ? 150 : (aliens[a].type == 1 ? 80 : 40);
            updateGalagaScoreHUD();
            break;
          }
        }
      }

      if (!hit && pBullets[i].active) {
        tft.drawFastVLine((int)pBullets[i].x, (int)pBullets[i].y, 6, GALA_CYAN);
      }
    }
  }

  // Update Alien Plasma Bullets
  for (int i = 0; i < MAX_ALIEN_BULLETS; i++) {
    if (aBullets[i].active) {
      tft.fillCircle((int)aBullets[i].x, (int)aBullets[i].y, 2, GALA_BG);
      aBullets[i].y += aBullets[i].vy;

      if (aBullets[i].y > GALA_PLAYFIELD_BOTTOM - 2) {
        aBullets[i].active = false;
        continue;
      }

      // Check hit with Player Ship
      if (aBullets[i].x >= shipX + 2 && aBullets[i].x <= shipX + SHIP_W - 2 &&
          aBullets[i].y >= SHIP_Y && aBullets[i].y <= SHIP_Y + SHIP_H) {
        aBullets[i].active = false;
        soundPlayerExplode();
        galaLives--;
        updateGalagaScoreHUD();

        if (galaLives <= 0) {
          gameState = 2; // Game Over
          menu_drawn = false;
          return;
        } else {
          eraseShip(shipX, SHIP_Y);
          shipX = (GALA_W - SHIP_W) / 2;
          drawShip(shipX, SHIP_Y);
        }
      } else {
        tft.fillCircle((int)aBullets[i].x, (int)aBullets[i].y, 2, GALA_RED);
      }
    }
  }
}

// -----------------------------------------------------------------
// FLEET MOVEMENT & DIVING AI
// -----------------------------------------------------------------
static void initGalagaWave(int wave) {
  galaWave = wave;
  fleetOffsetX = 0;
  fleetDir = 1.0f;
  lastFleetMove = millis();

  int startX = 26;
  int startY = 64;
  int colW = 38;
  int rowH = 22;

  for (int r = 0; r < ALIEN_ROWS; r++) {
    for (int c = 0; c < ALIEN_COLS; c++) {
      int idx = r * ALIEN_COLS + c;
      aliens[idx].formX = startX + c * colW;
      aliens[idx].formY = startY + r * rowH;
      aliens[idx].x = aliens[idx].formX;
      aliens[idx].y = aliens[idx].formY;
      aliens[idx].type = (r == 0) ? 2 : (r == 1 ? 1 : 0);
      aliens[idx].active = true;
      aliens[idx].diving = false;
    }
  }

  for (int i = 0; i < MAX_PLAYER_BULLETS; i++) pBullets[i].active = false;
  for (int i = 0; i < MAX_ALIEN_BULLETS; i++) aBullets[i].active = false;

  tft.fillScreen(GALA_BG);
  tft.drawFastHLine(0, GALA_PLAYFIELD_TOP - 1, GALA_W, GALA_SURFACE);
  tft.drawFastHLine(0, GALA_PLAYFIELD_BOTTOM + 1, GALA_W, GALA_SURFACE);

  drawGalagaHeader();
  drawGalagaBottomBar();
  initStarfield();

  drawShip(shipX, SHIP_Y);
  for (int i = 0; i < TOTAL_ALIENS; i++) {
    drawAlienSprite((int)aliens[i].x, (int)aliens[i].y, aliens[i].type);
  }
}

static void updateAliens() {
  // Sway formation left and right
  if (millis() - lastFleetMove > 60) {
    lastFleetMove = millis();
    fleetOffsetX += fleetDir * 1.6f;
    if (fleetOffsetX > 24) fleetDir = -1.0f;
    else if (fleetOffsetX < -24) fleetDir = 1.0f;
  }

  int activeCount = 0;

  for (int i = 0; i < TOTAL_ALIENS; i++) {
    if (!aliens[i].active) continue;
    activeCount++;

    int prevAX = (int)aliens[i].x;
    int prevAY = (int)aliens[i].y;

    if (!aliens[i].diving) {
      // Formation swaying
      float targetX = aliens[i].formX + fleetOffsetX;
      if (abs(aliens[i].x - targetX) > 0.5f || abs(aliens[i].y - aliens[i].formY) > 0.5f) {
        eraseAlienSprite(prevAX, prevAY);
        aliens[i].x = targetX;
        aliens[i].y = aliens[i].formY;
        drawAlienSprite((int)aliens[i].x, (int)aliens[i].y, aliens[i].type);
      }

      // Random dive launch
      if (random(200) < 2) {
        aliens[i].diving = true;
        aliens[i].diveAngle = 0;
        aliens[i].diveSpeed = random(35, 55) / 10.0f;
      }
    } else {
      // Diving trajectory (swooping curve towards player)
      eraseAlienSprite(prevAX, prevAY);
      aliens[i].y += aliens[i].diveSpeed;
      aliens[i].x += sin(aliens[i].diveAngle) * 3.2f;
      aliens[i].diveAngle += 0.12f;

      // Alien fires bullet during dive
      if (random(25) == 0) {
        alienShoot((int)aliens[i].x, (int)aliens[i].y);
      }

      // Loop around back to top formation
      if (aliens[i].y > GALA_PLAYFIELD_BOTTOM) {
        aliens[i].y = GALA_PLAYFIELD_TOP + 10;
        aliens[i].diving = false;
      }

      drawAlienSprite((int)aliens[i].x, (int)aliens[i].y, aliens[i].type);

      // Collision with player ship
      if (aliens[i].x < shipX + SHIP_W && aliens[i].x + 16 > shipX &&
          aliens[i].y < SHIP_Y + SHIP_H && aliens[i].y + 12 > SHIP_Y) {
        aliens[i].active = false;
        eraseAlienSprite((int)aliens[i].x, (int)aliens[i].y);
        soundPlayerExplode();
        galaLives--;
        updateGalagaScoreHUD();

        if (galaLives <= 0) {
          gameState = 2; // Game Over
          menu_drawn = false;
          return;
        }
      }
    }
  }

  // Wave Clear
  if (activeCount == 0) {
    gameState = 3; // Stage Complete
    menu_drawn = false;
  }
}

// -----------------------------------------------------------------
// INPUT & MODAL SCREENS
// -----------------------------------------------------------------
static void handleGalagaInput() {
  if (digitalRead(SHOOT) == LOW) galaShootReady = true;

  // Shoot Laser on button press
  if (digitalRead(SHOOT) == HIGH && galaShootReady) {
    galaShootReady = false;
    firePlayerLaser();
  }

  // Smooth unblocked horizontal gliding
  int dir = getDirectHorizontalInput();
  if (dir == -1) { // LEFT
    shipX -= SHIP_SPEED;
    if (shipX < 4) shipX = 4;
  } else if (dir == 1) { // RIGHT
    shipX += SHIP_SPEED;
    if (shipX > GALA_W - SHIP_W - 4) {
      shipX = GALA_W - SHIP_W - 4;
    }
  }

  if (shipX != prevShipX) {
    eraseShip(prevShipX, SHIP_Y);
    drawShip(shipX, SHIP_Y);
    prevShipX = shipX;
  }
}

static void showGalagaStartScreen() {
  gameState = -1;
  tft.setRotation(2);
  tft.fillScreen(GALA_BG);

  // Starfield backdrop
  for (int i = 0; i < 20; i++) {
    tft.drawPixel(random(10, 230), random(10, 80), 0xFFFF);
  }

  // Main Card
  tft.fillRoundRect(16, 50, 208, 250, 12, GALA_CARD);
  tft.drawRoundRect(16, 50, 208, 250, 12, GALA_SURFACE);

  // Pill Header
  tft.fillRoundRect(28, 66, 68, 24, 6, GALA_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(GALA_PURPLE, GALA_SURFACE);
  tft.drawString("SHOOTER", 62, 78);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  tft.drawString("SPACE", 28, 98);
  tft.drawString("GALAGA", 28, 124);

  // Instructions
  tft.setTextFont(1);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("CONTROLS", 28, 160);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  tft.drawString("D-PAD LEFT/RIGHT: Steer", 28, 176);
  tft.drawString("SHOOT: Fire laser cannon", 28, 192);

  // Best Record Banner
  tft.fillRoundRect(28, 218, 184, 28, 6, GALA_SURFACE);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(GALA_AMBER, GALA_SURFACE);
  tft.drawString("RECORD: " + String(currentGame.highScores[0]) + " PTS", 38, 232);

  // Start Prompt
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(GALA_GREEN, GALA_CARD);
  tft.drawString("PRESS SHOOT TO ENGAGE", 120, 275);
}

static void drawGalagaGameOver() {
  currentGame.recordScore(score);

  tft.fillRoundRect(24, 65, 192, 190, 12, GALA_CARD);
  tft.drawRoundRect(24, 65, 192, 190, 12, GALA_SURFACE);

  tft.fillRect(38, 81, 24, 3, GALA_RED);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("GALAGA / CASUALTIES", 38, 93);

  tft.setTextFont(4);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  tft.drawString("GAME OVER", 38, 107);

  // Score stats
  tft.setTextFont(1);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("SCORE", 38, 145);
  tft.drawString("BEST", 136, 145);

  tft.setTextFont(2);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  tft.drawString(String(score), 38, 158);
  tft.setTextColor(GALA_AMBER, GALA_CARD);
  tft.drawString(String(currentGame.highScores[0]), 136, 158);

  tft.drawFastHLine(38, 186, 164, GALA_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(GALA_CYAN, GALA_CARD);
  tft.drawString("SHOOT  RETRY MISSION", 38, 198);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("UP  MAIN MENU", 38, 218);
}

static void handleGalagaGameOver() {
  int cmd = findCommand();
  if (cmd == 4) {
    playSelectTone();
    score = 0;
    galaLives = 3;
    initGalagaWave(1);
    gameState = 0;
    menu_drawn = false;
  } else if (cmd == 0) {
    playSelectTone();
    switchGame(0);
  }
}

static void drawGalagaWaveClear() {
  tft.fillRoundRect(24, 75, 192, 175, 12, GALA_CARD);
  tft.drawRoundRect(24, 75, 192, 175, 12, GALA_SURFACE);

  tft.fillRect(38, 91, 24, 3, GALA_GREEN);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(GALA_WHITE, GALA_CARD);
  tft.drawString("WAVE CLEAR!", 38, 99);

  tft.setTextFont(1);
  tft.setTextColor(GALA_MUTED, GALA_CARD);
  tft.drawString("SECTOR SECURED", 38, 138);

  tft.setTextFont(2);
  tft.setTextColor(GALA_AMBER, GALA_CARD);
  tft.drawString("SCORE: " + String(score), 38, 158);

  tft.drawFastHLine(38, 186, 164, GALA_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(GALA_CYAN, GALA_CARD);
  tft.drawString("SHOOT  NEXT WAVE", 38, 202);
}

static void handleGalagaWaveClear() {
  int cmd = findCommand();
  if (cmd == 4) {
    playSelectTone();
    score += galaLives * 300;
    initGalagaWave(galaWave + 1);
    gameState = 0;
    menu_drawn = false;
  }
}

// -----------------------------------------------------------------
// LIFECYCLE (galagaSetup & galagaLoop)
// -----------------------------------------------------------------
void galagaSetup() {
  tft.setRotation(2); // Strict Vertical / Portrait Orientation
  score = 0;
  galaLives = 3;
  showGalagaStartScreen();
}

void galagaLoop() {
  if (gameState == 0) {
    handleGalagaInput();
    updateBullets();
    updateAliens();
    updateStarfield();

    delay(12); // ~60 FPS smooth motion
    return;
  } else if (gameState == 2) { // Game Over
    if (!menu_drawn) {
      drawGalagaGameOver();
      menu_drawn = true;
    }
    handleGalagaGameOver();
  } else if (gameState == 3) { // Wave Clear
    if (!menu_drawn) {
      drawGalagaWaveClear();
      menu_drawn = true;
    }
    handleGalagaWaveClear();
  } else if (gameState == -1) { // Title Screen
    int cmd = findCommand();
    if (cmd == 4) {
      playSelectTone();
      score = 0;
      galaLives = 3;
      initGalagaWave(1);
      gameState = 0;
    }
  }
}
