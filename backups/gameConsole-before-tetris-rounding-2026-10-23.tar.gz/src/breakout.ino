extern TFT_eSPI tft;
extern const int BUZZER_LEDC_CH;
#include "game.h"
#include <Arduino.h>

// =================================================================
// MODERN VERTICAL BREAKOUT / ARKANOID (240x320 PORTRAIT ORIENTATION)
// =================================================================

// Portrait dimensions: 240 width x 320 height (Rotation 2)
// Header Card: y = 5..43 (h = 38)
// Top Wall / Ceiling: y = 47
// Playfield Area: y = 48..290 (w = 240, h = 242)
// Paddle zone: y = 278, thickness = 8
// Bottom Dynamic Pill Bar: y = 295..316 (h = 21)

constexpr int BO_WIDTH  = 240;
constexpr int BO_HEIGHT = 320;
constexpr int BO_PLAYFIELD_TOP = 48;
constexpr int BO_PLAYFIELD_BOTTOM = 290;

// Grid of Bricks
// 6 columns across 240px:
// Left margin = 6px. Each brick = 36px wide, gap = 2px.
// 6 * 36 + 5 * 2 = 216 + 10 = 226px + 7px left/right margins = 240px!
constexpr int BRICK_ROWS = 6;
constexpr int BRICK_COLS = 6;
constexpr int BRICK_WIDTH = 36;
constexpr int BRICK_HEIGHT = 11;
constexpr int BRICK_GAP_X = 2;
constexpr int BRICK_GAP_Y = 3;
constexpr int BRICK_START_X = 7;
constexpr int BRICK_START_Y = 56;

// Paddle & Ball
constexpr int BASE_PADDLE_WIDTH = 46;
constexpr int PADDLE_HEIGHT = 8;
constexpr int PADDLE_Y = 276;
constexpr int PADDLE_SPEED = 7;
constexpr int BALL_SIZE = 6;
constexpr float BALL_SPEED_INIT = 3.6f;

// Colors (Consistent with Game Console OLED Modern Theme)
constexpr uint16_t BO_BG      = UI_BG;
constexpr uint16_t BO_CARD    = UI_PANEL;
constexpr uint16_t BO_SURFACE = UI_SURFACE;
constexpr uint16_t BO_WHITE   = UI_TEXT;
constexpr uint16_t BO_MUTED   = UI_MUTED;
constexpr uint16_t BO_CYAN    = UI_CYAN;
constexpr uint16_t BO_GREEN   = 0x3666;
constexpr uint16_t BO_AMBER   = 0xFE04;
constexpr uint16_t BO_RED     = 0xFA48;
constexpr uint16_t BO_PADDLE  = 0xFFFF;
constexpr uint16_t BO_BALL    = 0xFFE0; // Neon Yellow Ball

// Brick Colors by Row (Lush vibrant spectrum)
static const uint16_t ROW_BRICK_COLORS[BRICK_ROWS] = {
  0xF800, // Crimson Red (Row 0 - Top)
  0xFD20, // Vibrant Orange (Row 1)
  0xFFE0, // Bright Gold (Row 2)
  0x07E0, // Vibrant Emerald Green (Row 3)
  0x07FF, // Electric Cyan (Row 4)
  0x91BF  // Neon Violet (Row 5 - Bottom)
};

static const int ROW_POINTS[BRICK_ROWS] = { 70, 60, 50, 40, 30, 20 };

// -----------------------------------------------------------------
// GAME STATE
// -----------------------------------------------------------------
static uint8_t bricks[BRICK_ROWS][BRICK_COLS]; // 0 = empty, 1 = normal, 2 = silver (2 hits)
static uint8_t brickHits[BRICK_ROWS][BRICK_COLS];

static int paddleX = (BO_WIDTH - BASE_PADDLE_WIDTH) / 2;
static int prevPaddleX = paddleX;
static int paddleWidth = BASE_PADDLE_WIDTH;

static float ballX = BO_WIDTH / 2.0f;
static float ballY = PADDLE_Y - BALL_SIZE - 2;
static float prevBallX = ballX;
static float prevBallY = ballY;
static float ballVelX = BALL_SPEED_INIT;
static float ballVelY = -BALL_SPEED_INIT;

static bool ballLaunched = false;
static int lives = 3;
static int breakoutLevel = 1;
static int pauseSelection = 0;
static bool pauseReady = false;
static bool shootButtonReady = false;

// Power-ups
struct BreakoutPowerup {
  float x, y;
  int type; // 1 = Expand Paddle, 2 = Slow Ball, 3 = Extra Life
  bool active;
};
static BreakoutPowerup powerup;

// Particles
struct BreakoutParticle {
  float x, y;
  float vx, vy;
  uint16_t color;
  int life;
};
static BreakoutParticle boParticles[16];
static int boParticleCount = 0;

// -----------------------------------------------------------------
// SOUND EFFECTS
// -----------------------------------------------------------------
static void soundPaddleHit() {
  ledcWriteTone(BUZZER_LEDC_CH, 880); // A5
  delay(18);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

static void soundBrickHit(uint16_t freq = 1319) {
  ledcWriteTone(BUZZER_LEDC_CH, freq);
  delay(22);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

static void soundLostBall() {
  ledcWriteTone(BUZZER_LEDC_CH, 392);
  delay(60);
  ledcWriteTone(BUZZER_LEDC_CH, 294);
  delay(80);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

static void soundPowerup() {
  ledcWriteTone(BUZZER_LEDC_CH, 1046);
  delay(30);
  ledcWriteTone(BUZZER_LEDC_CH, 1568);
  delay(50);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

// -----------------------------------------------------------------
// PARTICLES
// -----------------------------------------------------------------
static void spawnParticles(int cx, int cy, uint16_t color) {
  boParticleCount = 0;
  for (int i = 0; i < 12; i++) {
    boParticles[i].x = cx;
    boParticles[i].y = cy;
    float angle = (i / 12.0f) * 6.283f;
    float speed = random(10, 26) / 10.0f;
    boParticles[i].vx = cos(angle) * speed;
    boParticles[i].vy = sin(angle) * speed;
    boParticles[i].color = color;
    boParticles[i].life = random(6, 12);
    boParticleCount++;
  }
}

static void updateAndDrawParticles() {
  for (int i = 0; i < boParticleCount; i++) {
    if (boParticles[i].life > 0) {
      tft.drawPixel((int)boParticles[i].x, (int)boParticles[i].y, BO_BG);
      boParticles[i].x += boParticles[i].vx;
      boParticles[i].y += boParticles[i].vy;
      boParticles[i].vy += 0.2f; // subtle gravity
      boParticles[i].life--;

      int nx = (int)boParticles[i].x;
      int ny = (int)boParticles[i].y;
      if (boParticles[i].life > 0 && nx >= 0 && nx < BO_WIDTH && ny >= BO_PLAYFIELD_TOP && ny <= BO_PLAYFIELD_BOTTOM) {
        tft.drawPixel(nx, ny, boParticles[i].color);
      }
    }
  }
}

// -----------------------------------------------------------------
// BRICKS RENDERING
// -----------------------------------------------------------------
static void getBrickRect(int r, int c, int &bx, int &by) {
  bx = BRICK_START_X + c * (BRICK_WIDTH + BRICK_GAP_X);
  by = BRICK_START_Y + r * (BRICK_HEIGHT + BRICK_GAP_Y);
}

static void drawBrick(int r, int c) {
  if (bricks[r][c] == 0) return;
  int bx, by;
  getBrickRect(r, c, bx, by);

  uint16_t col;
  if (bricks[r][c] == 2) { // Silver brick (2-hit)
    col = (brickHits[r][c] == 0) ? 0xCE79 : 0x8410;
  } else {
    col = ROW_BRICK_COLORS[r];
  }

  // Rounded glossy brick with top highlight
  tft.fillRoundRect(bx, by, BRICK_WIDTH, BRICK_HEIGHT, 2, col);
  tft.drawFastHLine(bx + 1, by, BRICK_WIDTH - 2, 0xFFFF);
}

static void eraseBrick(int r, int c) {
  int bx, by;
  getBrickRect(r, c, bx, by);
  tft.fillRect(bx, by, BRICK_WIDTH, BRICK_HEIGHT, BO_BG);
}

static void renderAllBricks() {
  tft.startWrite();
  for (int r = 0; r < BRICK_ROWS; r++) {
    for (int c = 0; c < BRICK_COLS; c++) {
      drawBrick(r, c);
    }
  }
  tft.endWrite();
}

// -----------------------------------------------------------------
// MODERN IPHONE HEADER & HUD
// -----------------------------------------------------------------
static void drawBreakoutHeader() {
  // Island Card Header: x=8, y=5, w=224, h=38
  tft.fillRoundRect(8, 5, 224, 38, 10, BO_CARD);
  tft.drawRoundRect(8, 5, 224, 38, 10, BO_SURFACE);

  // Left Tag: Pill Tag
  tft.fillRoundRect(16, 12, 54, 24, 6, BO_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(BO_CYAN, BO_SURFACE);
  tft.drawString("BREAKOUT", 43, 24);

  // Center: Score Pill
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("SCORE", 78, 11);
  tft.setTextFont(2);
  tft.setTextColor(BO_WHITE, BO_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 78, 21);

  // Right: Lives & Level
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("LIVES", 218, 11);

  // Heart / Life dots
  tft.fillRect(174, 23, 46, 10, BO_CARD);
  for (int i = 0; i < 3; i++) {
    uint16_t heartCol = (i < lives) ? BO_RED : BO_SURFACE;
    tft.fillCircle(182 + i * 14, 28, 4, heartCol);
  }
}

static void updateScoreAndLivesHUD() {
  // Score refresh
  tft.fillRect(78, 21, 55, 18, BO_CARD);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(BO_WHITE, BO_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 78, 21);

  // Lives refresh
  tft.fillRect(174, 23, 46, 10, BO_CARD);
  for (int i = 0; i < 3; i++) {
    uint16_t heartCol = (i < lives) ? BO_RED : BO_SURFACE;
    tft.fillCircle(182 + i * 14, 28, 4, heartCol);
  }
}

static void drawBreakoutBottomBar() {
  // Bottom dynamic pill bar: x=8, y=295, w=224, h=21
  tft.fillRoundRect(8, 295, 224, 21, 6, BO_CARD);
  tft.setTextFont(1);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString(ballLaunched ? "D-PAD: MOVE  |  SHOOT: PAUSE" : "D-PAD: AIM  |  SHOOT: LAUNCH", 120, 305);
}

// -----------------------------------------------------------------
// PADDLE, BALL & POWERUPS
// -----------------------------------------------------------------
static void drawPaddle(int x, uint16_t color) {
  tft.fillRoundRect(x, PADDLE_Y, paddleWidth, PADDLE_HEIGHT, 3, color);
  // Glossy highlight on paddle
  if (color == BO_PADDLE) {
    tft.drawFastHLine(x + 2, PADDLE_Y, paddleWidth - 4, 0xCE79);
  }
}

static void erasePaddle(int x) {
  tft.fillRect(x, PADDLE_Y, paddleWidth, PADDLE_HEIGHT, BO_BG);
}

static void drawBall(float x, float y) {
  tft.fillCircle((int)x, (int)y, BALL_SIZE / 2, BO_BALL);
}

static void eraseBall(float x, float y) {
  int ix = (int)x;
  int iy = (int)y;
  int rad = BALL_SIZE / 2 + 1;
  tft.fillCircle(ix, iy, rad, BO_BG);

  // If the erase circle overlapped the top or bottom boundary line, repair the line immediately!
  if (iy - rad <= BO_PLAYFIELD_TOP) {
    tft.drawFastHLine(0, BO_PLAYFIELD_TOP - 1, BO_WIDTH, BO_SURFACE);
  }
  if (iy + rad >= BO_PLAYFIELD_BOTTOM) {
    tft.drawFastHLine(0, BO_PLAYFIELD_BOTTOM + 1, BO_WIDTH, BO_SURFACE);
  }
  // If the erase circle overlapped the paddle area, restore the paddle
  if (iy + rad >= PADDLE_Y && iy - rad <= PADDLE_Y + PADDLE_HEIGHT &&
      ix + rad >= paddleX && ix - rad <= paddleX + paddleWidth) {
    drawPaddle(paddleX, BO_PADDLE);
  }

  // Also repair any neighboring bricks that might have been nicked by the ball erase
  int startCol = (ix - rad - BRICK_START_X) / (BRICK_WIDTH + BRICK_GAP_X);
  int endCol   = (ix + rad - BRICK_START_X) / (BRICK_WIDTH + BRICK_GAP_X);
  int startRow = (iy - rad - BRICK_START_Y) / (BRICK_HEIGHT + BRICK_GAP_Y);
  int endRow   = (iy + rad - BRICK_START_Y) / (BRICK_HEIGHT + BRICK_GAP_Y);

  startCol = constrain(startCol, 0, BRICK_COLS - 1);
  endCol   = constrain(endCol, 0, BRICK_COLS - 1);
  startRow = constrain(startRow, 0, BRICK_ROWS - 1);
  endRow   = constrain(endRow, 0, BRICK_ROWS - 1);

  for (int r = startRow; r <= endRow; r++) {
    for (int c = startCol; c <= endCol; c++) {
      if (bricks[r][c] > 0) {
        int bx, by;
        getBrickRect(r, c, bx, by);
        // Check if erase circle actually touched this brick
        if (ix + rad >= bx && ix - rad <= bx + BRICK_WIDTH &&
            iy + rad >= by && iy - rad <= by + BRICK_HEIGHT) {
          drawBrick(r, c);
        }
      }
    }
  }
}

static void spawnPowerup(int x, int y) {
  if (powerup.active) return;
  powerup.x = x + BRICK_WIDTH / 2.0f;
  powerup.y = y;
  powerup.type = random(1, 4); // 1 = expand, 2 = slow, 3 = extra life
  powerup.active = true;
}

static void updatePowerup() {
  if (!powerup.active) return;
  // Erase old
  tft.fillCircle((int)powerup.x, (int)powerup.y, 6, BO_BG);

  powerup.y += 1.8f; // Slow floating descent

  // Catch with paddle
  if (powerup.y >= PADDLE_Y - 4 && powerup.y <= PADDLE_Y + PADDLE_HEIGHT &&
      powerup.x >= paddleX - 4 && powerup.x <= paddleX + paddleWidth + 4) {
    powerup.active = false;
    soundPowerup();
    if (powerup.type == 1) { // Expand paddle
      erasePaddle(paddleX);
      paddleWidth = 62;
      drawPaddle(paddleX, BO_PADDLE);
      score += 50;
    } else if (powerup.type == 2) { // Slow ball
      ballVelX *= 0.75f;
      ballVelY *= 0.75f;
      score += 40;
    } else if (powerup.type == 3) { // Extra life
      if (lives < 3) lives++;
      score += 100;
    }
    updateScoreAndLivesHUD();
    return;
  }

  // Dropped out of bounds
  if (powerup.y > BO_PLAYFIELD_BOTTOM) {
    powerup.active = false;
    return;
  }

  // Draw power-up capsule
  uint16_t pCol = (powerup.type == 1) ? BO_CYAN : (powerup.type == 2 ? BO_AMBER : BO_GREEN);
  tft.fillCircle((int)powerup.x, (int)powerup.y, 5, pCol);
  tft.drawCircle((int)powerup.x, (int)powerup.y, 5, 0xFFFF);
}

static void resetBallOnPaddle() {
  ballX = paddleX + paddleWidth / 2.0f;
  ballY = PADDLE_Y - BALL_SIZE / 2.0f - 2;
  prevBallX = ballX;
  prevBallY = ballY;
  float dirX = (random(2) == 0 ? 1.0f : -1.0f);
  ballVelX = BALL_SPEED_INIT * dirX;
  ballVelY = -BALL_SPEED_INIT;
  ballLaunched = false;
  drawBreakoutBottomBar();
}

// -----------------------------------------------------------------
// LEVEL INITIALIZATION
// -----------------------------------------------------------------
static void initBreakoutLevel(int lvl) {
  breakoutLevel = lvl;
  paddleWidth = BASE_PADDLE_WIDTH;
  paddleX = (BO_WIDTH - paddleWidth) / 2;
  prevPaddleX = paddleX;
  powerup.active = false;

  // Initialize Bricks
  for (int r = 0; r < BRICK_ROWS; r++) {
    for (int c = 0; c < BRICK_COLS; c++) {
      if (lvl == 1) {
        bricks[r][c] = 1; // Standard colorful rows
      } else if (lvl == 2) {
        // Silver 2-hit bricks on top row
        bricks[r][c] = (r == 0) ? 2 : 1;
      } else {
        // Alternating strong bricks
        bricks[r][c] = ((r + c) % 3 == 0) ? 2 : 1;
      }
      brickHits[r][c] = 0;
    }
  }

  tft.fillScreen(BO_BG);

  // Playfield separator lines
  tft.drawFastHLine(0, BO_PLAYFIELD_TOP - 1, BO_WIDTH, BO_SURFACE);
  tft.drawFastHLine(0, BO_PLAYFIELD_BOTTOM + 1, BO_WIDTH, BO_SURFACE);

  drawBreakoutHeader();
  renderAllBricks();
  drawBreakoutBottomBar();
  drawPaddle(paddleX, BO_PADDLE);
  resetBallOnPaddle();
  drawBall(ballX, ballY);
}

// -----------------------------------------------------------------
// GAME LOGIC & COLLISIONS
// -----------------------------------------------------------------
static void checkBrickCollisions() {
  int remaining = 0;

  for (int r = 0; r < BRICK_ROWS; r++) {
    for (int c = 0; c < BRICK_COLS; c++) {
      if (bricks[r][c] == 0) continue;
      remaining++;

      int bx, by;
      getBrickRect(r, c, bx, by);

      // AABB overlap check between ball and brick
      if (ballX + BALL_SIZE / 2.0f >= bx &&
          ballX - BALL_SIZE / 2.0f <= bx + BRICK_WIDTH &&
          ballY + BALL_SIZE / 2.0f >= by &&
          ballY - BALL_SIZE / 2.0f <= by + BRICK_HEIGHT) {

        // Determine horizontal or vertical bounce
        float ballCenterX = ballX;
        float ballCenterY = ballY;
        float brickCenterX = bx + BRICK_WIDTH / 2.0f;
        float brickCenterY = by + BRICK_HEIGHT / 2.0f;

        float diffX = ballCenterX - brickCenterX;
        float diffY = ballCenterY - brickCenterY;

        if (abs(diffX) / BRICK_WIDTH > abs(diffY) / BRICK_HEIGHT) {
          ballVelX = (diffX > 0) ? abs(ballVelX) : -abs(ballVelX);
        } else {
          ballVelY = (diffY > 0) ? abs(ballVelY) : -abs(ballVelY);
        }

        // Brick damage / break
        if (bricks[r][c] == 2) { // Silver brick
          brickHits[r][c]++;
          if (brickHits[r][c] >= 2) {
            bricks[r][c] = 0;
            score += 50;
            eraseBrick(r, c);
            // explosion effect removed
            soundBrickHit(1568);
            if (random(10) > 6) spawnPowerup(bx, by);
          } else {
            drawBrick(r, c);
            soundBrickHit(880);
          }
        } else {
          bricks[r][c] = 0;
          score += ROW_POINTS[r];
          eraseBrick(r, c);
          // explosion effect removed
          soundBrickHit(1175 + r * 60);
          if (random(10) > 7) spawnPowerup(bx, by);
        }

        updateScoreAndLivesHUD();
        return; // Handle one collision per frame for stability
      }
    }
  }

  // Level Clear check
  if (remaining == 0) {
    gameState = 3; // Level clear state
    menu_drawn = false;
  }
}

static void updateBallAndPhysics() {
  eraseBall(prevBallX, prevBallY);

  ballX += ballVelX;
  ballY += ballVelY;

  // Left & Right Wall bounce
  if (ballX - BALL_SIZE / 2.0f <= 1) {
    ballX = 1 + BALL_SIZE / 2.0f;
    ballVelX = abs(ballVelX);
    soundPaddleHit();
  } else if (ballX + BALL_SIZE / 2.0f >= BO_WIDTH - 2) {
    ballX = BO_WIDTH - 2 - BALL_SIZE / 2.0f;
    ballVelX = -abs(ballVelX);
    soundPaddleHit();
  }

  // Top Wall bounce
  if (ballY - BALL_SIZE / 2.0f <= BO_PLAYFIELD_TOP) {
    ballY = BO_PLAYFIELD_TOP + BALL_SIZE / 2.0f;
    ballVelY = abs(ballVelY);
    soundPaddleHit();
  }

  // Paddle Collision
  if (ballVelY > 0 &&
      ballY + BALL_SIZE / 2.0f >= PADDLE_Y &&
      ballY - BALL_SIZE / 2.0f <= PADDLE_Y + PADDLE_HEIGHT &&
      ballX + BALL_SIZE / 2.0f >= paddleX - 1 &&
      ballX - BALL_SIZE / 2.0f <= paddleX + paddleWidth + 1) {

    ballY = PADDLE_Y - BALL_SIZE / 2.0f - 1;
    ballVelY = -abs(ballVelY);

    // Angle of deflection based on impact offset from paddle center
    float offset = (ballX - (paddleX + paddleWidth / 2.0f)) / (paddleWidth / 2.0f);
    ballVelX = offset * (BALL_SPEED_INIT * 1.3f);
    if (abs(ballVelX) < 0.6f) ballVelX = (ballVelX >= 0) ? 0.8f : -0.8f;

    // Crisp immediate redraw of the bat upon ball strike
    drawPaddle(paddleX, BO_PADDLE);
    soundPaddleHit();
  }

  // Bottom Void (Lost Life)
  if (ballY > BO_PLAYFIELD_BOTTOM) {
    soundLostBall();
    lives--;
    updateScoreAndLivesHUD();

    if (lives <= 0) {
      gameState = 2; // Game Over
      menu_drawn = false;
      return;
    } else {
      erasePaddle(paddleX);
      paddleWidth = BASE_PADDLE_WIDTH;
      drawPaddle(paddleX, BO_PADDLE);
      resetBallOnPaddle();
    }
  }

  // Check Bricks
  checkBrickCollisions();

  drawBall(ballX, ballY);
  prevBallX = ballX;
  prevBallY = ballY;
}

static void handleBreakoutInput() {
  // Check SHOOT button for Launch / Pause
  if (digitalRead(SHOOT) == LOW) shootButtonReady = true;
  else if (digitalRead(SHOOT) == HIGH && shootButtonReady) {
    shootButtonReady = false;
    if (!ballLaunched) {
      ballLaunched = true;
      playSelectTone();
      drawBreakoutBottomBar();
    } else {
      gameState = 1; // Pause
      menu_drawn = false;
      pauseSelection = 0;
      pauseReady = false;
      return;
    }
  }

  // Real-time unblocked paddle movement: reads ADC live every frame!
  int dir = getDirectHorizontalInput();
  if (dir == -1) { // LEFT (Hold to glide smoothly back and forth)
    paddleX -= PADDLE_SPEED;
    if (paddleX < 4) paddleX = 4;
  } else if (dir == 1) { // RIGHT
    paddleX += PADDLE_SPEED;
    if (paddleX > BO_WIDTH - paddleWidth - 4) {
      paddleX = BO_WIDTH - paddleWidth - 4;
    }
  }

  // If paddle moved, redraw immediately
  if (paddleX != prevPaddleX) {
    erasePaddle(prevPaddleX);
    drawPaddle(paddleX, BO_PADDLE);
    prevPaddleX = paddleX;

    // Ball stays glued to paddle before launch
    if (!ballLaunched) {
      eraseBall(prevBallX, prevBallY);
      ballX = paddleX + paddleWidth / 2.0f;
      ballY = PADDLE_Y - BALL_SIZE / 2.0f - 2;
      drawBall(ballX, ballY);
      prevBallX = ballX;
      prevBallY = ballY;
    }
  }
}

// -----------------------------------------------------------------
// MODAL SCREENS (START / PAUSE / GAME OVER / LEVEL CLEAR)
// -----------------------------------------------------------------
static void showBreakoutStartScreen() {
  gameState = -1;
  tft.setRotation(2);
  tft.fillScreen(BO_BG);

  // Decorative top bricks
  for (int c = 0; c < 6; c++) {
    tft.fillRoundRect(BRICK_START_X + c * 38, 12, 36, 12, 2, ROW_BRICK_COLORS[c]);
  }

  // Main Card
  tft.fillRoundRect(16, 45, 208, 255, 12, BO_CARD);
  tft.drawRoundRect(16, 45, 208, 255, 12, BO_SURFACE);

  // Pill Header
  tft.fillRoundRect(28, 60, 68, 24, 6, BO_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(BO_CYAN, BO_SURFACE);
  tft.drawString("ARKANOID", 62, 72);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString("BREAKOUT", 28, 92);

  // Instructions
  tft.setTextFont(1);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("CONTROLS", 28, 128);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString("D-PAD LEFT / RIGHT: Paddle", 28, 144);
  tft.drawString("SHOOT: Launch ball / Pause", 28, 160);
  tft.drawString("Power-ups: Expand, Slow, Life", 28, 176);

  // High score banner
  tft.fillRoundRect(28, 202, 184, 28, 6, BO_SURFACE);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(BO_AMBER, BO_SURFACE);
  tft.drawString("BEST RECORD: " + String(currentGame.highScores[0]) + " PTS", 38, 216);

  // Start Prompt
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(BO_GREEN, BO_CARD);
  tft.drawString("PRESS SHOOT TO START", 120, 268);
}

static void drawBreakoutPauseOption(int item) {
  const char* labels[] = { "RESUME", "RESTART", "MAIN MENU" };
  int y = 140 + item * 34;
  bool selected = (item == pauseSelection);
  uint16_t fill = selected ? BO_SURFACE : UI_ICON_BG;

  tft.fillRoundRect(36, y, 168, 28, 6, fill);
  if (selected) tft.drawRoundRect(36, y, 168, 28, 6, BO_CYAN);

  tft.setTextDatum(ML_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(selected ? BO_CYAN : BO_MUTED, fill);
  tft.drawString(labels[item], 48, y + 14);

  if (selected) {
    tft.setTextDatum(MR_DATUM);
    tft.drawString(">", 192, y + 14);
  }
}

static void drawBreakoutPauseMenu() {
  tft.fillRoundRect(24, 75, 192, 175, 12, BO_CARD);
  tft.drawRoundRect(24, 75, 192, 175, 12, BO_SURFACE);

  tft.fillRect(38, 91, 24, 3, BO_CYAN);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString("PAUSED", 38, 99);

  for (int i = 0; i < 3; i++) {
    drawBreakoutPauseOption(i);
  }
}

static void handleBreakoutPause() {
  if (!pauseReady) {
    if (digitalRead(SHOOT) == LOW) pauseReady = true;
    return;
  }

  int cmd = findCommand();
  if (cmd == 0 || cmd == 2) { // UP / DOWN
    int old = pauseSelection;
    pauseSelection = (pauseSelection + (cmd == 0 ? 2 : 1)) % 3;
    drawBreakoutPauseOption(old);
    drawBreakoutPauseOption(pauseSelection);
    playNavClick();
  } else if (cmd == 4) { // SHOOT: Select
    playSelectTone();
    if (pauseSelection == 0) { // Resume
      // Full screen redraw to clear pause menu
      tft.fillScreen(BO_BG);
      tft.drawFastHLine(0, BO_PLAYFIELD_TOP - 1, BO_WIDTH, BO_SURFACE);
      tft.drawFastHLine(0, BO_PLAYFIELD_BOTTOM + 1, BO_WIDTH, BO_SURFACE);
      drawBreakoutHeader();
      renderAllBricks();
      drawBreakoutBottomBar();
      drawPaddle(paddleX, BO_PADDLE);
      drawBall(ballX, ballY);
      gameState = 0;
      menu_drawn = false;
      shootButtonReady = false;
    } else if (pauseSelection == 1) { // Restart
      score = 0;
      lives = 3;
      initBreakoutLevel(1);
      gameState = 0;
      menu_drawn = false;
    } else { // Exit
      switchGame(0);
    }
  }
}

static void drawBreakoutGameOver() {
  currentGame.recordScore(score);

  tft.fillRoundRect(24, 65, 192, 190, 12, BO_CARD);
  tft.drawRoundRect(24, 65, 192, 190, 12, BO_SURFACE);

  tft.fillRect(38, 81, 24, 3, BO_RED);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("BREAKOUT / NO LIVES", 38, 93);

  tft.setTextFont(4);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString("GAME OVER", 38, 107);

  // Score stats
  tft.setTextFont(1);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("SCORE", 38, 145);
  tft.drawString("BEST", 136, 145);

  tft.setTextFont(2);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString(String(score), 38, 158);
  tft.setTextColor(BO_AMBER, BO_CARD);
  tft.drawString(String(currentGame.highScores[0]), 136, 158);

  tft.drawFastHLine(38, 186, 164, BO_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(BO_CYAN, BO_CARD);
  tft.drawString("SHOOT  PLAY AGAIN", 38, 198);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("UP  MAIN MENU", 38, 218);
}

static void handleBreakoutGameOver() {
  int cmd = findCommand();
  if (cmd == 4) {
    playSelectTone();
    score = 0;
    lives = 3;
    initBreakoutLevel(1);
    gameState = 0;
    menu_drawn = false;
  } else if (cmd == 0) {
    playSelectTone();
    switchGame(0);
  }
}

static void drawBreakoutLevelComplete() {
  tft.fillRoundRect(24, 75, 192, 175, 12, BO_CARD);
  tft.drawRoundRect(24, 75, 192, 175, 12, BO_SURFACE);

  tft.fillRect(38, 91, 24, 3, BO_GREEN);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(BO_WHITE, BO_CARD);
  tft.drawString("CLEARED!", 38, 99);

  tft.setTextFont(1);
  tft.setTextColor(BO_MUTED, BO_CARD);
  tft.drawString("LEVEL BONUS: +" + String(lives * 200), 38, 138);

  tft.setTextFont(2);
  tft.setTextColor(BO_AMBER, BO_CARD);
  tft.drawString("SCORE: " + String(score), 38, 158);

  tft.drawFastHLine(38, 186, 164, BO_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(BO_GREEN, BO_CARD);
  tft.drawString("SHOOT  NEXT STAGE", 38, 202);
}

static void handleBreakoutLevelComplete() {
  int cmd = findCommand();
  if (cmd == 4) {
    score += lives * 200;
    playSelectTone();
    initBreakoutLevel(breakoutLevel + 1);
    gameState = 0;
    menu_drawn = false;
  }
}

// -----------------------------------------------------------------
// LIFECYCLE (breakoutSetup & breakoutLoop)
// -----------------------------------------------------------------
void breakoutSetup() {
  tft.setRotation(2); // Strict Vertical / Portrait Orientation
  score = 0;
  lives = 3;
  showBreakoutStartScreen();
}

void breakoutLoop() {
  if (gameState == 0) {
    handleBreakoutInput();

    if (ballLaunched) {
      updateBallAndPhysics();
    }
    updatePowerup();
    // particles removed

    delay(12); // ~60 FPS smooth motion
    return;
  } else if (gameState == 1) { // Pause Menu
    if (!menu_drawn) {
      drawBreakoutPauseMenu();
      menu_drawn = true;
    }
    handleBreakoutPause();
  } else if (gameState == 2) { // Game Over
    if (!menu_drawn) {
      drawBreakoutGameOver();
      menu_drawn = true;
    }
    handleBreakoutGameOver();
  } else if (gameState == 3) { // Level Complete
    if (!menu_drawn) {
      drawBreakoutLevelComplete();
      menu_drawn = true;
    }
    handleBreakoutLevelComplete();
  } else if (gameState == -1) { // Title Screen
    int cmd = findCommand();
    if (cmd == 4) {
      playSelectTone();
      score = 0;
      lives = 3;
      initBreakoutLevel(1);
      gameState = 0;
    }
  }
}
