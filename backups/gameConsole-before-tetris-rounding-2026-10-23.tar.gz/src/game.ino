#include <Arduino.h>
#include <Preferences.h>
#include "game.h"
#include <Adafruit_ADS1X15.h>
#include "images.h"


const char* gameNames[] = { "Menu", "Tetris", "Snake", "Breakout", "Run", "Galaga" };
Preferences prefs;

Game::Game(int i) {
  index = i;
  name = gameNames[index];

  switch (index) {
    case 0:
      gameSetup = menuSetup;
      gameLoop =  menuLoop;
      break;
    case 1:
      gameSetup = tetrisSetup;
      gameLoop = tetrisLoop;
      break;
    case 2:
      gameSetup = setupSnake;
      gameLoop = loopSnake;
      break;
      // in your game registration
    case 3:
      gameSetup = breakoutSetup;
      gameLoop = breakoutLoop;
      break;
    case 4:
      gameSetup = runSetup;
      gameLoop = runLoop;
      break;
    case 5:
      gameSetup = galagaSetup;
      gameLoop = galagaLoop;
      break;
  }

  prefs.begin(name, false);
  for (int i = 0; i < 5; i++) {
    char key[50];
    snprintf(key, sizeof(key), "score_%d", i);
    highScores[i] = prefs.getInt(key);
  }
  prefs.end();
}


void Game::recordScore(int score) {
  int i = 4;
  while ((score > highScores[i]) && (i > 0)) {
    highScores[i] = min(highScores[i - 1], score);
    i--;
  }
  highScores[0] = max(highScores[0], score);

  prefs.begin(name, false);
  for (int i = 0; i < 5; i++) {
    char key[50];
    snprintf(key, sizeof(key), "score_%d", i);
    prefs.putInt(key, highScores[i]);
  }
  prefs.end();
}

extern Game currentGame;

void switchGame(int gameIndex) {
  Serial.printf("[Game] Switching to game %d (%s)\n", gameIndex, (gameIndex >= 0 && gameIndex < 5) ? gameNames[gameIndex] : "Unknown");
  currentGame = Game(gameIndex);
  currentGame.gameSetup();
}

Adafruit_ADS1115 ads;
TFT_eSPI tft = TFT_eSPI();
bool adsConnected = false;

void drawTransparentSpriteFast(int x, int y, int w, int h, const uint16_t *img, uint16_t transparentColor) {
  static uint16_t lineBuffer[128];
  tft.startWrite();
  for (int j = 0; j < h; j++) {
    int pixelsToDraw = 0;
    int startX = -1;
    for (int i = 0; i < w; i++) {
      uint16_t color = pgm_read_word(&img[j * w + i]);
      if (color != transparentColor) {
        if (startX == -1) startX = i;
        lineBuffer[pixelsToDraw++] = color;
      } else {
        if (pixelsToDraw > 0) {
          tft.setAddrWindow(x + startX, y + j, pixelsToDraw, 1);
          tft.pushColors(lineBuffer, pixelsToDraw);
          pixelsToDraw = 0;
          startX = -1;
        }
      }
    }
    if (pixelsToDraw > 0) {
      tft.setAddrWindow(x + startX, y + j, pixelsToDraw, 1);
      tft.pushColors(lineBuffer, pixelsToDraw);
    }
  }
  tft.endWrite();
}

int score = 0;
int gameState = 0;
int menu_drawn = false;
unsigned long lastCommand = 0;
unsigned long lastTimeUpdate = 0;
int selected_menu_item = 1;
const unsigned long debounce_delay = 180;

// Direct ESP32-C3 Hardware LEDC PWM for Buzzer
const int BUZZER_LEDC_CH = 0;

void playToneDirect(unsigned int freq, unsigned long durationMs) {
  if (freq > 0) {
    ledcWriteTone(BUZZER_LEDC_CH, freq);
  } else {
    ledcWrite(BUZZER_LEDC_CH, 0);
  }
  delay(durationMs);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

void playNavClick() {
  // Crisp retro click/blip via hardware PWM
  ledcWriteTone(BUZZER_LEDC_CH, 1800);
  delay(20);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

void playSelectTone() {
  // Two-tone cheerful affirmation
  ledcWriteTone(BUZZER_LEDC_CH, 1319); // E6
  delay(50);
  ledcWriteTone(BUZZER_LEDC_CH, 1760); // A6
  delay(80);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
}

void drawBootHand(int tip, bool fromLeft, uint16_t handColor) {
  // A simple original pixel-style hand silhouette, mirrored around the center.
  auto handX = [tip, fromLeft](int distance, int width) {
    return fromLeft ? tip - distance - width : tip + distance;
  };
  tft.fillRoundRect(handX(57, 56), 138, 56, 23, 5, UI_SURFACE);
  tft.fillRect(handX(91, 8), 138, 8, 23, UI_MUTED);
  tft.fillRoundRect(handX(25, 37), 130, 37, 36, 7, handColor);
  tft.fillRoundRect(handX(0, 31), 126, 31, 6, 2, handColor);
  tft.fillRoundRect(handX(0, 34), 134, 34, 7, 2, handColor);
  tft.fillRoundRect(handX(0, 33), 143, 33, 7, 2, handColor);
  tft.fillRoundRect(handX(4, 27), 152, 27, 6, 2, handColor);
}

void drawBootSpark(int x, int y, uint16_t color) {
  tft.drawFastHLine(x - 5, y, 11, color);
  tft.drawFastVLine(x, y - 5, 11, color);
  tft.drawPixel(x - 3, y - 3, color);
  tft.drawPixel(x + 3, y + 3, color);
}

uint16_t bootRgb565(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

void fillBootGradient(int x, int y, int w, int h,
                      uint8_t r1, uint8_t g1, uint8_t b1,
                      uint8_t r2, uint8_t g2, uint8_t b2) {
  for (int row = 0; row < h; row++) {
    float t = h <= 1 ? 0.0f : (float)row / (float)(h - 1);
    uint8_t r = r1 + (int)((r2 - r1) * t);
    uint8_t g = g1 + (int)((g2 - g1) * t);
    uint8_t b = b1 + (int)((b2 - b1) * t);
    tft.drawFastHLine(x, y + row, w, bootRgb565(r, g, b));
  }
}

void playBootAnimation() {
  Serial.printf("[Boot] Modern startup animation and chime on GPIO %d...\n", BUZZER_PIN);
  const uint16_t accent[] = {UI_CYAN, UI_PURPLE, UI_YELLOW, UI_CYAN, UI_TEXT, UI_GREEN};
  const int notes[] = {523, 659, 784, 988, 1319, 1568};

  tft.fillScreen(UI_BG);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_BG);
  tft.drawString("GAME CONSOLE", 120, 210);
  // Compact centered loading track: x=64..176, with breathing room on both sides.
  tft.drawRoundRect(64, 229, 112, 4, 2, UI_SURFACE);

  for (int frame = 0; frame < 6; frame++) {
    tft.fillRect(0, 62, 240, 128, UI_BG);
    uint16_t color = accent[frame];
    int progress = 24 + frame * 24;
    // Ring zone: y=72..148. The status and progress zones stay below it.
    tft.drawSmoothArc(120, 110, 38, 33, 218, 218 + progress, color, UI_BG, true);
    tft.drawSmoothArc(120, 110, 38, 33, 38, 38 + progress / 2, UI_SURFACE, UI_BG, true);
    tft.drawCircle(120, 110, 25, UI_PANEL);
    tft.fillCircle(120, 110, 13, UI_BG);
    tft.fillRoundRect(113, 103, 14, 14, 4, color);
    tft.fillRoundRect(117, 107, 6, 6, 2, UI_BG);
    // Keep the animated fill within the 144px track from x=48 to x=192.
    int fillWidth = (frame + 1) * 18; // 18..108px, always inside the 112px track.
    tft.fillRoundRect(66, 230, fillWidth, 2, 1, color);
    tft.setTextColor(color, UI_BG);
    tft.drawString("INITIALIZING", 120, 169);
    playToneDirect(notes[frame], 68);
    delay(42);
  }

  tft.fillRect(0, 62, 240, 128, UI_BG);
  tft.drawSmoothArc(120, 110, 39, 33, 0, 360, UI_CYAN, UI_BG, true);
  tft.drawSmoothArc(120, 110, 32, 27, 0, 360, UI_PURPLE, UI_BG, true);
  // Keep the logo card centered on the ring's actual center (120, 110).
  // 58x58 => top-left is (120 - 29, 110 - 29) = (91, 81).
  fillBootGradient(91, 81, 58, 58, 14, 14, 24, 42, 16, 55);
  tft.drawRoundRect(91, 81, 58, 58, 14, UI_SURFACE);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("GC", 120, 110);
  playToneDirect(1760, 100);
  delay(80);

  tft.fillScreen(UI_BG);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_BG);
  tft.drawString("GAME CONSOLE", 120, 112);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_BG);
  tft.drawString("READY TO PLAY", 120, 143);
  tft.drawFastHLine(66, 165, 108, UI_SURFACE);
  tft.drawFastHLine(93, 165, 54, UI_CYAN);
  tft.drawFastHLine(108, 168, 24, UI_PURPLE);
  playToneDirect(2093, 170);
  delay(180);
}
void init_interface() {
  Serial.begin(115200);
  tft.init();
  tft.setRotation(2);
  tft.fillScreen(UI_BG);
  Serial.println("[Game] Starting interface initialization...");

  ledcAttachPin(BUZZER_PIN, BUZZER_LEDC_CH);
  ledcWriteTone(BUZZER_LEDC_CH, 0);
  playBootAnimation();

  Wire.begin(8, 9);
  if (!ads.begin(0x48)) {
    Serial.println("[Game] Warning: ADS1115 not detected at 0x48. Check I2C wiring (SDA=8, SCL=9).");
    adsConnected = false;
  } else {
    ads.setGain(GAIN_ONE);
    adsConnected = true;
    Serial.println("[Game] ADS1115 ADC initialized at 0x48.");
  }

  pinMode(SHOOT, INPUT_PULLDOWN);
}

const int16_t ADC_PRESS_THRESHOLD = 18000;
static int lastActiveCommand = -1;

int findCommand() {
  unsigned long currentTime = millis();
  
  static unsigned long lastDebugPrint = 0;
  if (currentTime - lastDebugPrint >= 1500) {
    lastDebugPrint = currentTime;
    if (adsConnected) {
      Serial.printf("[Sensors] A0=%-5d A1=%-5d A2=%-5d A3=%-5d | GPIO5=%d\n",
                    ads.readADC_SingleEnded(0),
                    ads.readADC_SingleEnded(1),
                    ads.readADC_SingleEnded(2),
                    ads.readADC_SingleEnded(3),
                    digitalRead(5));
    }
  }

  int currentPressed = -1;

  if (adsConnected) {
    for (int i = 0; i < 4; i++) {
      int16_t raw = ads.readADC_SingleEnded(i);
      if (raw > ADC_PRESS_THRESHOLD) {
        delayMicroseconds(300);
        if (ads.readADC_SingleEnded(i) > (ADC_PRESS_THRESHOLD - 2000)) {
          // Screen rotated from landscape (1) to portrait (2):
          // Remap D-pad 90 degrees so physical directions match the new display orientation:
          // Old A0 -> 1 (Right), Old A1 -> 2 (Down), Old A2 -> 3 (Left), Old A3 -> 0 (Up)
          const int rotMap[4] = {1, 2, 3, 0};
          currentPressed = rotMap[i];
          break;
        }
      }
    }
  }

  if (currentPressed == -1 && digitalRead(5)) {
    delayMicroseconds(400);
    if (digitalRead(5)) {
      currentPressed = 4;
    }
  }

  // If nothing is pressed, reset active command state
  if (currentPressed == -1) {
    lastActiveCommand = -1;
    return -1;
  }

  // If the same button is held down, require at least 350ms before repeating
  if (currentPressed == lastActiveCommand) {
    if (currentTime - lastCommand < 350) {
      return -1;
    }
  }

  lastActiveCommand = currentPressed;
  lastCommand = currentTime;
  Serial.printf("[Input] Command triggered: %d\n", currentPressed);
  return currentPressed;
}

void PauseMenuControls() {
  int pressed = findCommand();
  int x = (tft.width() > 250 ? 1 : 0);


  if (pressed == 0 + x) updatePauseMenu(1);
  if (pressed == 2 + x) updatePauseMenu(-1);

  if (pressed == 5) {
    if (gameState == 0) {
      gameState = 1;
      menu_drawn = false;
    } else if (gameState == 1) {
      switch (selected_menu_item) {
        case 1:
          restoreAfterPauseTetris();
        case 0:
          ESP.restart();
        case 2:
          ESP.restart();
      }
    }
  }
}





void updatePauseMenu(int dx) {
  const char* labels[] = {"RETRY", "RESUME", "MENU"};
  int new_item = selected_menu_item + dx;
  if (new_item >= 0 && new_item < 3) selected_menu_item = new_item;

  for (int i = 0; i < 3; i++) {
    int y = 140 + i * 34;
    bool sel = (i == selected_menu_item);
    uint16_t fill = sel ? UI_SURFACE : UI_ICON_BG;
    tft.fillRoundRect(36, y, 168, 28, 6, fill);
    if (sel) tft.drawRoundRect(36, y, 168, 28, 6, 0xFFFF);
    tft.setTextDatum(ML_DATUM);
    tft.setTextFont(2);
    tft.setTextColor(sel ? 0xFFFF : UI_MUTED, fill);
    tft.drawString(labels[i], 48, y + 14);
    if (sel) {
      tft.setTextDatum(MR_DATUM);
      tft.drawString(">", 192, y + 14);
    }
  }
}

void drawPauseMenu(void) {
  tft.fillRoundRect(24, 75, 192, 175, 12, UI_PANEL);
  tft.drawRoundRect(24, 75, 192, 175, 12, UI_SURFACE);
  tft.fillRect(38, 91, 24, 3, 0xFFFF);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("PAUSED", 38, 99);
  updatePauseMenu(0);
}

// =================================================================
//                         GAME OVER
// =================================================================
void showGameOver() {
  static bool gameOverDrawn = false;
  currentGame.recordScore(score);

  if (!gameOverDrawn) {
    tft.fillRoundRect(24, 65, 192, 190, 12, UI_PANEL);
    tft.drawRoundRect(24, 65, 192, 190, 12, UI_SURFACE);

    tft.fillRect(38, 81, 24, 3, UI_RED);
    tft.setTextDatum(TL_DATUM);
    tft.setTextFont(1);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("GAME / FINISHED", 38, 93);

    tft.setTextFont(4);
    tft.setTextColor(UI_TEXT, UI_PANEL);
    tft.drawString("GAME OVER", 38, 107);

    tft.setTextFont(1);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("SCORE", 38, 145);
    tft.drawString("BEST", 136, 145);

    tft.setTextFont(2);
    tft.setTextColor(UI_TEXT, UI_PANEL);
    tft.drawString(String(score), 38, 158);
    tft.setTextColor(0xFFFF, UI_PANEL);
    tft.drawString(String(currentGame.highScores[0]), 136, 158);

    tft.drawFastHLine(38, 186, 164, UI_SURFACE);
    tft.setTextFont(1);
    tft.setTextColor(0xFFFF, UI_PANEL);
    tft.drawString("SHOOT  RETRY", 38, 198);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("UP  MAIN MENU", 38, 218);

    gameOverDrawn = true;
  }
}

void drawDefaultBg(){
   int ymax = tft.width() <= 240 ? 32:24;
      int xmax = tft.width() > 240 ? 32:24;


   for (int y = 0; y < ymax; y++) {
      for (int x = 0; x < 32; x++) {
        tft.fillRect(x * 10, y * 10, 10, 10, bg());
      }
    }
}

void drawDefaultBg2(){
   int ymax = tft.width() <= 240 ? 32:24;
      int xmax = tft.width() > 240 ? 32:24;


   for (int y = 0; y < ymax; y++) {
      for (int x = 0; x < 32; x++) {
        tft.fillRect(x * 10, y * 10, 10, 10, (x+y) % 2 == 0? BG1:BG2);
      }
    }
}

int getDirectHorizontalInput() {
  if (!adsConnected) return 0;
  // In portrait rotation 2: Channel 0 = Right, Channel 2 = Left
  // To completely eliminate ghost/false presses from ADC noise:
  // We use a confirmed threshold (21000) and verify with a confirmation re-read
  int16_t rightRaw = ads.readADC_SingleEnded(0);
  if (rightRaw > 21000) {
    delayMicroseconds(200);
    if (ads.readADC_SingleEnded(0) > 19000) return 1; // Confirmed RIGHT
  }

  int16_t leftRaw = ads.readADC_SingleEnded(2);
  if (leftRaw > 21000) {
    delayMicroseconds(200);
    if (ads.readADC_SingleEnded(2) > 19000) return -1; // Confirmed LEFT
  }

  if (Serial.available()) {
    char c = Serial.peek();
    if (c == 'd' || c == 'l') { Serial.read(); return 1; }
    if (c == 'a' || c == 'j') { Serial.read(); return -1; }
  }
  return 0;
}
