
#include <string.h>
#include <Preferences.h>
#include "config.h"
#include "game.h"

#define SIZE 10
#define SPACE_WIDTH 22
#define SPACE_HEIGHT 24

constexpr int TETRIS_HUD_Y = 260;
constexpr int TETRIS_HUD_H = 50;
constexpr uint16_t TETRIS_GRID = 0x0841;
constexpr uint16_t TETRIS_HIGHLIGHT = 0xFFFF;

unsigned long drop_interval = 600;
unsigned long lastDrop = 0;
unsigned long lastTick = 0;
unsigned long elapsedPlayMs = 0;
unsigned long lastShownSecond = 0;
int tetrisPauseSelection = 0;
bool tetrisPauseReady = false;
bool tetrisShootReady = false;


uint32_t current_color;
int current_shape;

int current_pos[2] = { 0, 0 };
int prev_pos[2] = { 0, 0 };
bool current_body[3][3];
bool prev_body[3][3];
uint32_t colors[] = { TFT_YELLOW, TFT_CYAN, TFT_GREENYELLOW, TFT_MAGENTA,
                      TFT_ORANGE, TFT_PURPLE, TFT_RED, TFT_SKYBLUE };
uint32_t space[SPACE_WIDTH * SPACE_HEIGHT];
uint32_t next_color = colors[random(8)];
int next_shape = random(7);

void updatePauseMenu(int dx);
void tetrisSetup();

bool bodies[7][3][3] = {
  { { 0, 0, 0 }, { 1, 1, 1 }, { 0, 0, 0 } },
  { { 0, 0, 0 }, { 0, 1, 1 }, { 0, 1, 1 } },
  { { 0, 0, 0 }, { 1, 1, 1 }, { 0, 1, 0 } },
  { { 0, 0, 0 }, { 1, 1, 1 }, { 1, 0, 0 } },
  { { 0, 0, 0 }, { 1, 1, 1 }, { 0, 0, 1 } },
  { { 0, 0, 0 }, { 0, 1, 1 }, { 1, 1, 0 } },
  { { 0, 0, 0 }, { 1, 1, 0 }, { 0, 1, 1 } }
};

int getEncode(int x, int y) {
  return x + y * SPACE_WIDTH;
}

void drawRect(int x, int y, uint32_t color) {
  tft.fillRect(MARGIN_X + 1 + x * SIZE, MARGIN_Y + 1 + y * SIZE,
               SIZE - 2, SIZE - 2, color);
}

void drawRect(int x, int y) {
  int px = MARGIN_X + x * SIZE;
  int py = MARGIN_Y + y * SIZE;
  tft.fillRect(px, py, SIZE, SIZE, UI_BG);
  tft.fillRect(px + 1, py + 1, SIZE - 2, SIZE - 2, TETRIS_GRID);
}

void redrawChangedCells() {
  tft.startWrite();
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      int px_old = prev_pos[0] + i - 1;
      int py_old = prev_pos[1] + j - 1;
      int px_new = current_pos[0] + i - 1;
      int py_new = current_pos[1] + j - 1;

      if (prev_body[i][j]) {
        bool still_covered = false;
        int di = px_old - (current_pos[0] - 1);
        int dj = py_old - (current_pos[1] - 1);
        if (di >= 0 && di < 3 && dj >= 0 && dj < 3 && current_body[di][dj])
          still_covered = true;

        if (!still_covered && px_old >= 0 && px_old < SPACE_WIDTH
            && py_old >= 0 && py_old < SPACE_HEIGHT) {
          uint32_t dead = space[getEncode(px_old, py_old)];
          if (dead != TFT_BLACK) drawRect(px_old, py_old, dead);
          else drawRect(px_old, py_old);
        }
      }

      if (current_body[i][j] && px_new >= 0 && px_new < SPACE_WIDTH
          && py_new >= 0 && py_new < SPACE_HEIGHT) {
        drawRect(px_new, py_new, current_color);
      }
    }
  }
  tft.endWrite();
}

void drawBody() {
  tft.startWrite();
  int x = current_pos[0];
  int y = current_pos[1];
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      if (current_body[i][j])
        drawRect(i + x - 1, j + y - 1, current_color);
  tft.endWrite();
}

void ClearBody() {
  tft.startWrite();
  int x = current_pos[0];
  int y = current_pos[1];
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      if (current_body[i][j]) {
        int px = i + x - 1;
        int py = j + y - 1;
        uint32_t dead = space[getEncode(px, py)];
        if (dead != TFT_BLACK) drawRect(px, py, dead);
        else drawRect(px, py);
      }
    }
  }
  tft.endWrite();
}

void drawNext() {
  tft.fillRect(106, TETRIS_HUD_Y + 19, 28, 27, UI_PANEL);
  tft.startWrite();
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++) {
      if (bodies[next_shape][i][j])
        tft.fillRoundRect(108 + i * 8, TETRIS_HUD_Y + 21 + j * 8, 7, 7, 1, next_color);
    }
  tft.endWrite();
}

void redrawRowsAbove(int cleared_row) {
  tft.startWrite();
  for (int y = 0; y <= cleared_row; y++) {
    for (int x = 0; x < SPACE_WIDTH; x++) {
      uint32_t c = space[getEncode(x, y)];
      if (c != TFT_BLACK) drawRect(x, y, c);
      else drawRect(x, y);
    }
  }
  tft.endWrite();
}

void drawMenu(void) {
  const int cardX[] = {8, 84, 160};
  for (int i = 0; i < 3; i++) {
    tft.fillRoundRect(cardX[i], TETRIS_HUD_Y, 72, TETRIS_HUD_H, 7, UI_PANEL);
    tft.drawRoundRect(cardX[i], TETRIS_HUD_Y, 72, TETRIS_HUD_H, 7, UI_SURFACE);
  }
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("SCORE", 16, TETRIS_HUD_Y + 7);
  tft.drawString("NEXT", 92, TETRIS_HUD_Y + 7);
  tft.drawString("TIME", 168, TETRIS_HUD_Y + 7);
  tft.drawFastHLine(16, TETRIS_HUD_Y + 3, 20, TETRIS_HIGHLIGHT);
}

void drawTetrisScore() {
  char buf[16];
  snprintf(buf, sizeof(buf), "%d", score);
  tft.fillRect(16, TETRIS_HUD_Y + 20, 56, 24, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  if (tft.textWidth(buf) > 56) tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(buf, 16, TETRIS_HUD_Y + 22);
}

void updateScore() {
  score += 10;
  drawTetrisScore();
}

void updateTime() {
  unsigned long totalSeconds = elapsedPlayMs / 1000;
  char buffer[16];
  snprintf(buffer, sizeof(buffer), "%02lu:%02lu", totalSeconds / 60, totalSeconds % 60);
  tft.fillRect(168, TETRIS_HUD_Y + 20, 56, 24, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  if (tft.textWidth(buffer) > 56) tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(buffer, 168, TETRIS_HUD_Y + 22);
}

void addToDead() {
  int x = current_pos[0];
  int y = current_pos[1];
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++) {
      int px = x + i - 1;
      int py = y + j - 1;
      if (px >= 0 && px < SPACE_WIDTH && py >= 0 && py < SPACE_HEIGHT)
        if (current_body[i][j])
          space[getEncode(px, py)] = current_color;
    }
}

bool checkCollision(int dx, int dy) {
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      if (current_body[i][j]) {
        int px = current_pos[0] + i - 1 + dx;
        int py = current_pos[1] + j - 1 + dy;
        if (px < 0 || px >= SPACE_WIDTH || py >= SPACE_HEIGHT) return true;
        if (py >= 0 && space[getEncode(px, py)] != TFT_BLACK) return true;
      }
  return false;
}

void rotateClockwise() {
  bool rotated[3][3];
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      rotated[i][j] = current_body[2 - j][i];
  memcpy(current_body, rotated, sizeof(current_body));
}

void newTetro() {
  current_color = next_color;
  current_shape = next_shape;
  next_color = colors[random(8)];
  next_shape = random(7);
  current_pos[0] = random(1, SPACE_WIDTH - 2);
  current_pos[1] = 1;
  drawNext();

  for (int j = 0; j < SPACE_HEIGHT; j++) {
    int fill = 0;
    for (int i = 0; i < SPACE_WIDTH; i++)
      if (space[getEncode(i, j)] != TFT_BLACK) fill++;

    if (fill == SPACE_WIDTH) {
      for (int y = j; y > 0; y--)
        for (int x = 0; x < SPACE_WIDTH; x++)
          space[getEncode(x, y)] = space[getEncode(x, y - 1)];

      for (int x = 0; x < SPACE_WIDTH; x++)
        space[getEncode(x, 0)] = TFT_BLACK;

      redrawRowsAbove(j);
      updateScore();
      j--;
    }
  }

  memcpy(current_body, bodies[current_shape], sizeof(current_body));
  memcpy(prev_pos, current_pos, sizeof(current_pos));
  memcpy(prev_body, current_body, sizeof(current_body));
}

void tryRotate() {
  bool temp[3][3];
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      temp[i][j] = current_body[2 - j][i];

  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      if (temp[i][j]) {
        int px = current_pos[0] + i - 1;
        int py = current_pos[1] + j - 1;
        if (px < 0 || px >= SPACE_WIDTH || py >= SPACE_HEIGHT) return;
        if (py >= 0 && space[getEncode(px, py)] != TFT_BLACK) return;
      }

  memcpy(prev_pos, current_pos, sizeof(current_pos));
  memcpy(prev_body, current_body, sizeof(current_body));
  memcpy(current_body, temp, sizeof(temp));
  redrawChangedCells();
}

void updatePosition(int dx = 0, int dy = 1) {
  if (!checkCollision(dx, dy)) {
    memcpy(prev_pos, current_pos, sizeof(current_pos));
    memcpy(prev_body, current_body, sizeof(current_body));
    current_pos[0] += dx;
    current_pos[1] += dy;
    redrawChangedCells();
  } else if (dy == 1) {
    addToDead();
    newTetro();
    drawBody();
    if (checkCollision(0, 0)) {
      gameState = 2;
      menu_drawn = false;
    }
  }
}




void getCommand() {
  if (digitalRead(SHOOT) == LOW) tetrisShootReady = true;
  int pressed = findCommand();
  if (pressed == 4 && !tetrisShootReady) return;
  switch (pressed) {
    case 0: tryRotate(); break;
    case 1: updatePosition(1, 0); break;
    case 2:
      updatePosition(0, 1);
      lastDrop = millis();
      break;
    case 3: updatePosition(-1, 0); break;
    case 4:
      gameState = 1;
      menu_drawn = false;
      tetrisPauseSelection = 0;
      tetrisPauseReady = false;
      break;
    default:
      break;
  }
}


void restoreAfterPauseTetris() {
  tft.startWrite();
  for (int y = 0; y < SPACE_HEIGHT; y++)
    for (int x = 0; x < SPACE_WIDTH; x++) {
      uint32_t c = space[getEncode(x, y)];
      if (c != TFT_BLACK) drawRect(x, y, c);
      else drawRect(x, y);
    }
  tft.endWrite();
  drawBody();
  lastDrop = millis();
  lastTick = lastDrop;
  gameState = 0;
  menu_drawn = false;
  tetrisShootReady = false;
}

void drawTetrisPauseOption(int item) {
  const char* labels[] = {"RESUME", "RESTART", "MAIN MENU"};
  int y = 130 + item * 34;
  bool selected = item == tetrisPauseSelection;
  uint16_t fill = selected ? UI_SURFACE : UI_ICON_BG;
  tft.fillRoundRect(40, y, 160, 30, 6, fill);
  if (selected) tft.drawRoundRect(40, y, 160, 30, 6, TETRIS_HIGHLIGHT);
  tft.setTextDatum(ML_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(selected ? TETRIS_HIGHLIGHT : UI_MUTED, fill);
  tft.drawString(labels[item], 52, y + 15);
  if (selected) {
    tft.setTextDatum(MR_DATUM);
    tft.drawString(">", 188, y + 15);
  }
}

void drawTetrisPauseMenu() {
  tft.fillRoundRect(26, 61, 188, 177, 12, UI_PANEL);
  tft.drawRoundRect(26, 61, 188, 177, 12, UI_SURFACE);
  tft.fillRect(40, 77, 24, 3, TETRIS_HIGHLIGHT);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("PAUSED", 40, 86);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("UP / DOWN TO CHOOSE", 40, 116);
  for (int item = 0; item < 3; item++) drawTetrisPauseOption(item);
}

void handleTetrisPause() {
  // The same SHOOT press that opened pause must be released before it can resume.
  if (!tetrisPauseReady) {
    if (digitalRead(SHOOT) == LOW) tetrisPauseReady = true;
    return;
  }

  int pressed = findCommand();
  if (pressed == 0 || pressed == 2) {
    int oldSelection = tetrisPauseSelection;
    tetrisPauseSelection = (tetrisPauseSelection + (pressed == 0 ? 2 : 1)) % 3;
    drawTetrisPauseOption(oldSelection);
    drawTetrisPauseOption(tetrisPauseSelection);
    playNavClick();
  } else if (pressed == 4) {
    playSelectTone();
    if (tetrisPauseSelection == 0) restoreAfterPauseTetris();
    else if (tetrisPauseSelection == 1) tetrisSetup();
    else switchGame(0);
  }
}

void drawTetrisGameOver() {
  currentGame.recordScore(score);
  tft.fillRoundRect(26, 63, 188, 174, 12, UI_PANEL);
  tft.drawRoundRect(26, 63, 188, 174, 12, UI_SURFACE);
  tft.fillRect(40, 79, 24, 3, TETRIS_HIGHLIGHT);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("TETRIS / FINISHED", 40, 91);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("GAME OVER", 40, 105);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("SCORE", 40, 143);
  tft.drawString("BEST", 133, 143);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(String(score), 40, 155);
  tft.drawString(String(currentGame.highScores[0]), 133, 155);
  tft.drawFastHLine(40, 184, 160, UI_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("SHOOT  RETRY", 40, 197);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("UP  MAIN MENU", 40, 216);
}

void handleTetrisGameOver() {
  int pressed = findCommand();
  if (pressed == 4) tetrisSetup();
  else if (pressed == 0) switchGame(0);
}



void tetrisSetup() {
  score = 0;
  gameState = 0;
  menu_drawn = false;
  drop_interval = 600;
  elapsedPlayMs = 0;
  lastShownSecond = 0;
  tetrisPauseSelection = 0;
  tetrisPauseReady = false;
  tetrisShootReady = false;
  lastDrop = millis();
  lastTick = lastDrop;
  next_color = colors[random(8)];
  next_shape = random(7);
  for (int i = 0; i < SPACE_WIDTH * SPACE_HEIGHT; i++)
    space[i] = TFT_BLACK;

  tft.setRotation(2);
  tft.fillScreen(UI_BG);
  tft.fillRoundRect(7, 7, 226, 246, 8, UI_PANEL);
  tft.drawRoundRect(7, 7, 226, 246, 8, UI_SURFACE);
  tft.drawFastHLine(16, 7, 26, TETRIS_HIGHLIGHT);

  tft.startWrite();
  for (int i = 0; i < SPACE_WIDTH; i++)
    for (int j = 0; j < SPACE_HEIGHT; j++)
      drawRect(i, j);
  tft.endWrite();

  drawMenu();
  drawTetrisScore();
  updateTime();
  newTetro();
  drawBody();
  lastDrop = millis();
  lastTick = lastDrop;
}

void tetrisLoop() {
  if (gameState == 0) {
    unsigned long currentTime = millis();
    elapsedPlayMs += currentTime - lastTick;
    lastTick = currentTime;
    getCommand();
    if (gameState != 0) return;
    currentTime = millis();

    unsigned long shownSecond = elapsedPlayMs / 1000;
    if (shownSecond != lastShownSecond) {
      lastShownSecond = shownSecond;
      updateTime();
    }

    if (currentTime - lastDrop >= drop_interval) {
      lastDrop = currentTime;
      updatePosition();
    }
  } else if (gameState == 1) {
    if (!menu_drawn) {
      drawTetrisPauseMenu();
      menu_drawn = true;
    }
    handleTetrisPause();
  } else if (gameState == 2) {
    if (!menu_drawn) {
      drawTetrisGameOver();
      menu_drawn = true;
    }
    handleTetrisGameOver();
  }
}
