#include "game.h"
#include "retro_icons_40x40.h"
#include "config.h"

// Define apps
struct App {
  const char* label;
  int x_coord;
  int y_coord;
  const uint16_t *img;
  int gameIndex; // 1 = Tetris, 2 = Snake, 3 = Breakout, -1 = Info
};

App Apps[] = {
  {"TETRIS",   0, 0, tetris_icon,    1},
  {"SNAKE",    0, 0, snake_icon,     2},
  {"BREAKOUT", 0, 0, breakout_icon,  3},
  {"RUN",      0, 0, run_icon,       4},
  {"GALAGA",   0, 0, galaga_icon,    5},
  {"SOUND",    0, 0, sound_icon,    -1},
  {"SETTINGS", 0, 0, settings_icon, -1},
  {"ABOUT",    0, 0, about_icon,    -1}
};

const int APP_COUNT = sizeof(Apps) / sizeof(App);

// Fixed portrait layout. Every drawn area stays inside its own bounds.
// Header: 0..61, section: 65..82, grid: 88..279, footer: 288..309.
constexpr int PORTRAIT_W = 240;
constexpr int PORTRAIT_H = 320;
constexpr int COLS = 3;
constexpr int VISIBLE_ROWS = 3;
constexpr int TILE_W = 70;
constexpr int TILE_H = 60;
constexpr int START_Y = 88;
constexpr int COL_GAP = 8;
constexpr int ROW_GAP = 6;
constexpr int MARGIN_LEFT = 7;
constexpr int FOOTER_Y = 288;
constexpr uint16_t MENU_CARD = UI_ICON_BG;
constexpr uint16_t MENU_ACCENT = 0xFFFF;
constexpr uint16_t MENU_ACCENT_DIM = 0xAD55;

static_assert(MARGIN_LEFT * 2 + COLS * TILE_W + (COLS - 1) * COL_GAP == PORTRAIT_W,
              "Menu tiles must fit the screen width");
static_assert(START_Y + VISIBLE_ROWS * TILE_H + (VISIBLE_ROWS - 1) * ROW_GAP < FOOTER_Y,
              "Menu tiles must end above the footer");
static_assert(FOOTER_Y + 22 <= PORTRAIT_H - 10,
              "Menu footer must leave a bottom margin");

int selectedApp = 0;
int scrollOffset = 0;
unsigned long lastAnimTime = 0;
bool highlightBright = true;

void drawAppTile(int index, bool selected = false);
void redrawVisibleTiles();

void drawBottomBar() {
  tft.fillRoundRect(7, FOOTER_Y, 226, 22, 6, UI_PANEL);
  tft.drawFastVLine(PORTRAIT_W / 2, FOOTER_Y + 5, 12, UI_SURFACE);
  tft.setTextFont(1);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("D-PAD", 16, FOOTER_Y + 7);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("MOVE", 57, FOOTER_Y + 7);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("SHOOT", 137, FOOTER_Y + 7);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("OPEN", 184, FOOTER_Y + 7);
}

void displayMenuTitle() {
  tft.fillScreen(UI_BG);
  tft.fillRect(0, 0, PORTRAIT_W, 62, UI_PANEL);
  tft.fillRoundRect(9, 11, 3, 37, 1, MENU_ACCENT);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("GAME", 20, 8);
  tft.drawString("CONSOLE", 20, 27);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("ESP32-C3  /  ARCADE", 20, 49);

  int playable = 0;
  for (int i = 0; i < APP_COUNT; i++) {
    if (Apps[i].gameIndex > 0) playable++;
  }
  char count[4];
  snprintf(count, sizeof(count), "%02d", playable);
  tft.setTextDatum(TR_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString(count, 228, 8);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("PLAYABLE", 228, 43);

  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(UI_MUTED, UI_BG);
  tft.drawString("LIBRARY", 9, 68);
  tft.drawFastHLine(9, 82, PORTRAIT_W - 18, UI_SURFACE);
}

void drawLibraryPosition() {
  tft.fillRect(181, 65, 50, 14, UI_BG);
  char position[12];
  snprintf(position, sizeof(position), "%02d / %02d", selectedApp + 1, APP_COUNT);
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(MENU_ACCENT, UI_BG);
  tft.drawString(position, 231, 68);
}

void getTileCoordinates(int index, int &outX, int &outY) {
  int col = index % COLS;
  int row = index / COLS;
  int visibleRow = row - scrollOffset;
  outX = MARGIN_LEFT + col * (TILE_W + COL_GAP);
  outY = START_Y + visibleRow * (TILE_H + ROW_GAP);
}

void drawSelectionAccent(int index) {
  int row = index / COLS;
  if (row < scrollOffset || row >= scrollOffset + VISIBLE_ROWS) return;
  int x, y;
  getTileCoordinates(index, x, y);
  uint16_t accent = highlightBright ? MENU_ACCENT : MENU_ACCENT_DIM;
  tft.drawRoundRect(x, y, TILE_W, TILE_H, 8, accent);
  tft.drawRoundRect(x + 1, y + 1, TILE_W - 2, TILE_H - 2, 7, UI_SURFACE);
  tft.drawFastHLine(x + 24, y + TILE_H - 3, TILE_W - 48, accent);
}

void drawAppTile(int index, bool selected) {
  int row = index / COLS;
  if (row < scrollOffset || row >= scrollOffset + VISIBLE_ROWS) return;
  int x, y;
  getTileCoordinates(index, x, y);
  Apps[index].x_coord = x;
  Apps[index].y_coord = y;

  tft.fillRoundRect(x, y, TILE_W, TILE_H, 8, MENU_CARD);
  if (!selected) tft.drawRoundRect(x, y, TILE_W, TILE_H, 8, UI_SURFACE);

  // Icon: y+4..43. Label: y+47..55. Both stay inside the 60px card.
  tft.setSwapBytes(true);
  tft.pushImage(x + 15, y + 4, 40, 40, Apps[index].img, 0x0022);
  tft.setTextColor(selected ? MENU_ACCENT : UI_TEXT, MENU_CARD);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.drawString(Apps[index].label, x + TILE_W / 2, y + 51);
  if (selected) drawSelectionAccent(index);
}

void redrawVisibleTiles() {
  tft.fillRect(0, 84, PORTRAIT_W, FOOTER_Y - 84, UI_BG);
  int startApp = scrollOffset * COLS;
  int endApp = min(startApp + (VISIBLE_ROWS * COLS), APP_COUNT);
  for (int i = startApp; i < endApp; i++) {
    drawAppTile(i, i == selectedApp);
  }
  drawLibraryPosition();
  drawBottomBar();
}

void showAboutScreen() {
  tft.fillRoundRect(14, 42, 212, 244, 12, UI_PANEL);
  tft.drawRoundRect(14, 42, 212, 244, 12, UI_SURFACE);
  
  tft.fillRect(26, 56, 24, 3, MENU_ACCENT);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("DEVICE / SPECIFICATIONS", 26, 68);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("CONSOLE", 26, 82);

  const char* specs[][2] = {
    {"CPU ARCH", "ESP32-C3 RISC-V"},
    {"CLOCK", "160 MHz"},
    {"DISPLAY", "ILI9341 240x320"},
    {"ADC INPUT", "ADS1115 16-Bit I2C"},
    {"AUDIO", "GPIO 10 LEDC PWM"}
  };

  tft.setTextFont(1);
  for (int i = 0; i < 5; i++) {
    int sy = 126 + i * 24;
    tft.fillRoundRect(24, sy - 2, 192, 20, 4, UI_ICON_BG);
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(UI_MUTED, UI_ICON_BG);
    tft.drawString(specs[i][0], 30, sy + 7);
    tft.setTextDatum(MR_DATUM);
    tft.setTextColor(UI_TEXT, UI_ICON_BG);
    tft.drawString(specs[i][1], 208, sy + 7);
  }
  
  tft.drawFastHLine(24, 252, 192, UI_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("PRESS SHOOT TO RETURN", 120, 268);
  
  delay(300);
  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      Serial.read();
      break;
    }
    if (c == 4 || c == 0 || c == 1 || c == 2 || c == 3) break;
    delay(20);
  }
  menuSetup();
}

struct SongNote {
  uint16_t freq;
  uint16_t duration;
};

struct Track {
  const char* title;
  const char* artist;
  const SongNote* notes;
  int noteCount;
};

// 1. Never Gonna Give You Up (Rick Astley)
const SongNote rickNotes[] = {
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {494, 280}, {440, 380}, {0, 140},
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {440, 280}, {392, 380}, {0, 140},
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {392, 220}, {440, 200}, {370, 280}, {330, 220}, {294, 380}
};

// 2. Astronomia / Coffin Dance (Vicetone)
const SongNote astronomiaNotes[] = {
  {587, 110}, {587, 110}, {587, 110}, {587, 110},
  {392, 220}, {494, 220}, {440, 220}, {523, 220},
  {494, 220}, {392, 220}, {440, 220}, {587, 220},
  {494, 220}, {392, 220}, {440, 220}, {587, 220}
};

// 3. Blinding Lights (The Weeknd)
const SongNote blindingNotes[] = {
  {698, 170}, {698, 170}, {622, 170}, {698, 220},
  {784, 220}, {523, 330}, {0, 90},
  {698, 170}, {698, 170}, {622, 170}, {698, 220},
  {784, 220}, {523, 330}, {0, 90},
  {784, 170}, {784, 170}, {698, 170}, {622, 220}, {523, 380}
};

// 4. Bad Guy (Billie Eilish)
const SongNote badGuyNotes[] = {
  {392, 130}, {392, 130}, {392, 130}, {294, 130},
  {349, 130}, {392, 130}, {0, 130},
  {392, 130}, {392, 130}, {392, 130}, {294, 130},
  {349, 130}, {392, 130}, {0, 130},
  {466, 130}, {440, 130}, {392, 260}
};

// 5. Despacito (Luis Fonsi) - Extended Chorus & Main Hook
const SongNote despacitoNotes[] = {
  // Main iconic intro hook: D5 - C#5 - B4 - F#4
  {587, 300}, {554, 180}, {494, 200}, {370, 220}, {0, 100},
  // "Des - pa - ci - to..."
  {370, 140}, {370, 140}, {370, 140}, {370, 140},
  {494, 180}, {494, 180}, {494, 180}, {494, 240},
  {440, 160}, {494, 160}, {392, 360}, {0, 120},
  // Second phrase: "Quiero respirar tu cuello despacito..."
  {392, 140}, {392, 140}, {392, 140}, {392, 140},
  {392, 180}, {494, 180}, {494, 180}, {494, 240},
  {440, 160}, {392, 160}, {440, 320}, {0, 120},
  // Third phrase: "Deja que te diga cosas al oído..."
  {440, 140}, {440, 140}, {440, 140}, {440, 140},
  {440, 180}, {587, 180}, {587, 180}, {587, 240},
  {554, 160}, {494, 160}, {440, 280}, {370, 360}
};

// 6. Tetris Theme A (Korobeiniki)
const SongNote tetrisNotes[] = {
  {659, 220}, {494, 120}, {523, 120}, {587, 220}, {523, 120}, {494, 120},
  {440, 220}, {440, 120}, {523, 120}, {659, 220}, {587, 120}, {523, 120},
  {494, 280}, {523, 120}, {587, 220}, {659, 220},
  {523, 220}, {440, 220}, {440, 320}
};

const Track jukeboxPlaylist[] = {
  {"Never Gonna Give You Up", "Rick Astley", rickNotes, sizeof(rickNotes)/sizeof(rickNotes[0])},
  {"Astronomia (Coffin)",     "Vicetone",    astronomiaNotes, sizeof(astronomiaNotes)/sizeof(astronomiaNotes[0])},
  {"Blinding Lights",         "The Weeknd",  blindingNotes, sizeof(blindingNotes)/sizeof(blindingNotes[0])},
  {"Bad Guy",                 "Billie Eilish", badGuyNotes, sizeof(badGuyNotes)/sizeof(badGuyNotes[0])},
  {"Despacito",               "Luis Fonsi",  despacitoNotes, sizeof(despacitoNotes)/sizeof(despacitoNotes[0])},
  {"Tetris Korobeiniki",      "Retro Classic", tetrisNotes, sizeof(tetrisNotes)/sizeof(tetrisNotes[0])}
};

const int JUKEBOX_COUNT = sizeof(jukeboxPlaylist)/sizeof(jukeboxPlaylist[0]);

void playSoundTestScreen() {
  int currentSong = 4; // Default directly to Despacito (Track #5)
  bool isPlaying = false;
  
  auto drawJukeboxUI = [&]() {
    tft.fillRoundRect(14, 42, 212, 246, 12, UI_PANEL);
    tft.drawRoundRect(14, 42, 212, 246, 12, UI_SURFACE);
    
    tft.fillRect(26, 54, 24, 3, MENU_ACCENT);
    tft.setTextDatum(TL_DATUM);
    tft.setTextFont(1);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("AUDIO / CHIPTONE", 26, 64);
    tft.setTextFont(4);
    tft.setTextColor(UI_TEXT, UI_PANEL);
    tft.drawString("JUKEBOX", 26, 76);
    
    // Song list
    tft.setTextFont(1);
    for (int i = 0; i < JUKEBOX_COUNT; i++) {
      int y = 108 + i * 23;
      bool sel = (i == currentSong);
      
      if (sel) {
        tft.fillRoundRect(22, y - 2, 196, 21, 6, UI_SURFACE);
        tft.drawRoundRect(22, y - 2, 196, 21, 6, MENU_ACCENT);
        tft.setTextColor(MENU_ACCENT, UI_SURFACE);
      } else {
        tft.fillRoundRect(22, y - 2, 196, 21, 6, UI_ICON_BG);
        tft.setTextColor(UI_MUTED, UI_ICON_BG);
      }
      
      char buf[36];
      snprintf(buf, sizeof(buf), "%d. %s", i + 1, jukeboxPlaylist[i].title);
      tft.setTextDatum(ML_DATUM);
      tft.drawString(buf, 28, y + 7);
      if (sel) {
        tft.setTextDatum(MR_DATUM);
        tft.drawString(isPlaying ? "||" : ">", 210, y + 7);
      }
    }
    
    // Status banner at bottom of card
    tft.drawFastHLine(22, 248, 196, UI_SURFACE);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(isPlaying ? MENU_ACCENT : UI_MUTED, UI_PANEL);
    tft.drawString(isPlaying ? "NOW PLAYING" : "SHOOT: PLAY / PAUSE", 120, 258);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("UP/DOWN: PICK  |  LEFT: EXIT", 120, 272);
  };
  
  drawJukeboxUI();
  delay(250);

  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      char sc = Serial.read();
      if (sc == ' ' || sc == 'x' || sc == 'e') c = 4;
      else if (sc == 'w') c = 0;
      else if (sc == 's') c = 2;
      else if (sc == 'a' || sc == 'q') c = 3;
    }
    
    // Exit back to menu on LEFT (command 3)
    if (c == 3) {
      ledcWriteTone(BUZZER_LEDC_CH, 0);
      playNavClick();
      break;
    }

    if (c == 0) { // UP
      ledcWriteTone(BUZZER_LEDC_CH, 0);
      isPlaying = false;
      currentSong = (currentSong - 1 + JUKEBOX_COUNT) % JUKEBOX_COUNT;
      playNavClick();
      drawJukeboxUI();
      delay(150);
    } else if (c == 2) { // DOWN
      ledcWriteTone(BUZZER_LEDC_CH, 0);
      isPlaying = false;
      currentSong = (currentSong + 1) % JUKEBOX_COUNT;
      playNavClick();
      drawJukeboxUI();
      delay(150);
    } else if (c == 4) { // SHOOT: Play / Stop
      if (isPlaying) {
        ledcWriteTone(BUZZER_LEDC_CH, 0);
        isPlaying = false;
        drawJukeboxUI();
        delay(200);
      } else {
        isPlaying = true;
        drawJukeboxUI();
        
        // Play selected track with interactive abort on any button press
        const Track& trk = jukeboxPlaylist[currentSong];
        for (int i = 0; i < trk.noteCount; i++) {
          // Check for button press to stop or change song
          int interruptCmd = findCommand();
          if (interruptCmd == 4 || interruptCmd == 0 || interruptCmd == 2 || interruptCmd == 3) {
            ledcWriteTone(BUZZER_LEDC_CH, 0);
            isPlaying = false;
            break;
          }
          if (Serial.available()) {
            Serial.read();
            ledcWriteTone(BUZZER_LEDC_CH, 0);
            isPlaying = false;
            break;
          }
          
          uint16_t freq = trk.notes[i].freq;
          uint16_t dur = trk.notes[i].duration;
          
          if (freq > 0) {
            ledcWriteTone(BUZZER_LEDC_CH, freq);
          } else {
            ledcWriteTone(BUZZER_LEDC_CH, 0);
          }
          
          // Mini visualizer bar in card
          int barW = map(freq, 200, 900, 10, 180);
          barW = constrain(barW, 10, 180);
          tft.fillRect(30, 240, 180, 4, UI_PANEL);
          if (freq > 0) {
            tft.fillRect(30, 240, barW, 4, MENU_ACCENT_DIM);
          }
          
          delay(dur);
          ledcWriteTone(BUZZER_LEDC_CH, 0);
          delay(20);
        }
        
        ledcWriteTone(BUZZER_LEDC_CH, 0);
        isPlaying = false;
        drawJukeboxUI();
      }
    }
    delay(20);
  }
  
  ledcWriteTone(BUZZER_LEDC_CH, 0);
  menuSetup();
}

void showNotice(const char* name) {
  tft.fillRoundRect(20, 100, 200, 120, 12, UI_PANEL);
  tft.drawRoundRect(20, 100, 200, 120, 12, UI_SURFACE);
  tft.fillRect(36, 114, 20, 3, MENU_ACCENT);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.setTextFont(4);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(name, 120, 138);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.setTextFont(1);
  tft.drawString("Feature Coming Soon", 120, 168);
  tft.drawFastHLine(36, 186, 168, UI_SURFACE);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("PRESS SHOOT TO RETURN", 120, 202);
  delay(300);
  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      Serial.read();
      break;
    }
    if (c == 4 || c == 0 || c == 1 || c == 2 || c == 3) break;
    delay(20);
  }
  menuSetup();
}

void menuSetup() {
  Serial.println("[Menu] Opening Main Menu (3 apps per row, vertical mode)...");
  tft.setRotation(2); // Vertical (Portrait) mode: 240x320
  selectedApp = 0;
  scrollOffset = 0;
  highlightBright = true;
  displayMenuTitle();
  redrawVisibleTiles();
  lastAnimTime = millis();
}

void menuLoop() {
  unsigned long currentTime = millis();

  // Pulse only the pixels inside the selected card's border.
  if (currentTime - lastAnimTime >= 350) {
    lastAnimTime = currentTime;
    highlightBright = !highlightBright;
    drawSelectionAccent(selectedApp);
  }

  // Check inputs
  int cmd = findCommand();
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'w' || c == 'W') cmd = 0;       // UP
    else if (c == 'd' || c == 'D') cmd = 1;  // RIGHT
    else if (c == 's' || c == 'S') cmd = 2;  // DOWN
    else if (c == 'a' || c == 'A') cmd = 3;  // LEFT
    else if (c == ' ' || c == '\n' || c == '\r' || c == 'e' || c == 'E' || c == 'x' || c == 'X') cmd = 4; // SELECT
  }

  if (cmd == -1) return;

  int newSelected = selectedApp;

  switch (cmd) {
    case 0: // UP
      if (selectedApp >= COLS) newSelected = selectedApp - COLS;
      break;

    case 2: // DOWN
      if (selectedApp + COLS < APP_COUNT) newSelected = selectedApp + COLS;
      break;

    case 1: // RIGHT
      if (selectedApp + 1 < APP_COUNT) newSelected = selectedApp + 1;
      break;

    case 3: // LEFT
      if (selectedApp > 0) newSelected = selectedApp - 1;
      break;

    case 4: // SELECT
      {
        playSelectTone();
        int target = Apps[selectedApp].gameIndex;
        if (target > 0) {
          Serial.printf("[Menu] Launching Game %d: %s\n", target, Apps[selectedApp].label);
          switchGame(target);
          return;
        } else if (strcasecmp(Apps[selectedApp].label, "about") == 0) {
          showAboutScreen();
          return;
        } else if (strcasecmp(Apps[selectedApp].label, "sound") == 0) {
          playSoundTestScreen();
          return;
        } else {
          showNotice(Apps[selectedApp].label);
          return;
        }
      }
      break;
  }

  if (newSelected != selectedApp) {
    playNavClick();
    drawAppTile(selectedApp, false);
    selectedApp = newSelected;

    int newRow = selectedApp / COLS;
    if (newRow < scrollOffset) {
      scrollOffset = newRow;
      redrawVisibleTiles();
    } else if (newRow >= scrollOffset + VISIBLE_ROWS) {
      scrollOffset = newRow - VISIBLE_ROWS + 1;
      redrawVisibleTiles();
    } else {
      drawAppTile(selectedApp, true);
    }
    drawLibraryPosition();
  }
}
