#include <Arduino.h>
#include "game.h"

namespace {
constexpr int WIDTH = 240, HEIGHT = 320, STRIP = 16;
uint16_t displayPixels[WIDTH * STRIP];

int bounce(unsigned long position, int range) {
  int value = position % (2 * range);
  return value <= range ? value : 2 * range - value;
}
}

// USB serial 'b' from the launcher measures display writes on the real board.
// Repeating one static pattern avoids flashing colors. This checks throughput;
// the write-only wiring cannot verify whether the panel received clean pixels.
void benchmarkDisplay() {
  constexpr int FRAMES = 8;
  auto &pixels = displayPixels;
  for (int y = 0; y < STRIP; ++y) {
    for (int x = 0; x < WIDTH; ++x) {
      int r = (x * 31) / (WIDTH - 1);
      int g = (y * 63) / (STRIP - 1);
      int b = ((x / 8 + y / 4) & 1) ? 24 : 4;
      pixels[y * WIDTH + x] = (r << 11) | (g << 5) | b;
    }
  }
  setup_t settings;
  tft.getSetup(settings);
  tft.setRotation(2);
  bool oldSwap = tft.getSwapBytes();
  tft.setSwapBytes(true);
  Serial.printf("[DisplayBench] begin spi_hz=%lu frames=%d bytes_per_frame=%d\n",
                (unsigned long)settings.tft_spi_freq * 100000UL, FRAMES, WIDTH * HEIGHT * 2);
  unsigned long started = micros();
  for (int frame = 0; frame < FRAMES; ++frame) {
    tft.startWrite();
    for (int y = 0; y < HEIGHT; y += STRIP)
      tft.pushImage(0, y, WIDTH, STRIP, pixels);
    tft.endWrite();
    yield();
  }
  unsigned long elapsed = micros() - started;
  tft.setSwapBytes(oldSwap);
  Serial.printf("[DisplayBench] done image_frame_ms=%.3f image_fps=%.2f elapsed_us=%lu\n",
                elapsed / (1000.0 * FRAMES), FRAMES * 1000000.0 / elapsed, elapsed);
}

// USB serial 'v' runs a continuous, full-frame visual stress demo. Shoot or
// serial 'q' returns to the launcher. The FPS includes CPU drawing and text.
void demoDisplay() {
  setup_t settings;
  tft.getSetup(settings);
  bool oldSwap = tft.getSwapBytes();
  tft.setRotation(2);
  tft.setSwapBytes(true);
  // Compose both panels off-screen. Blending their completed pixels into each
  // strip prevents the background from ever appearing between the text draws.
  TFT_eSprite hud(&tft);
  hud.setColorDepth(16);
  auto *hudPixels = static_cast<uint16_t *>(hud.createSprite(224, 74));
  if (!hudPixels) {
    tft.setSwapBytes(oldSwap);
    Serial.println("[DisplayDemo] insufficient memory for text panels");
    return;
  }
  unsigned long began = millis(), windowAt = began, pressedAt = began;
  unsigned long totalFrames = 0, windowFrames = 0;
  bool released = !digitalRead(SHOOT), pressing = false;
  float fps = 0;
  auto updateHud = [&]() {
    hud.fillSprite(TFT_MAGENTA);
    hud.fillRoundRect(0, 0, 224, 42, 8, 0);
    hud.setTextDatum(MC_DATUM);
    hud.setTextFont(2);
    hud.setTextColor(TFT_WHITE, 0);
    hud.drawString("DISPLAY SPEED TEST", 112, 13);
    char text[40];
    snprintf(text, sizeof(text), "SPI %d MHz  %.1f FPS", settings.tft_spi_freq / 10, fps);
    hud.setTextFont(1);
    hud.drawString(text, 112, 31);
    hud.fillRoundRect(0, 42, 224, 32, 8, 0);
    hud.drawString("SHOOT: BACK TO MENU", 112, 52);
    hud.drawString("CHECK LINES / WRONG COLORS", 112, 65);
  };
  updateHud();
  Serial.printf("[DisplayDemo] begin spi_hz=%lu; Shoot or serial q exits\n",
                (unsigned long)settings.tft_spi_freq * 100000UL);
  while (true) {
    unsigned long now = millis();
    if (!digitalRead(SHOOT)) { released = true; pressing = false; }
    else if (released) {
      if (!pressing) { pressing = true; pressedAt = now; }
      else if (now - pressedAt >= 30) break;
    }
    if (Serial.available()) {
      char c = Serial.read();
      if (c == 'q' || c == 'Q') break;
    }
    unsigned long elapsed = now - began;
    int phase = (elapsed / 12) & 255;
    int cx = 24 + bounce(elapsed / 4, WIDTH - 48);
    int cy = 75 + bounce(elapsed / 6, 155);
    tft.startWrite();
    for (int top = 0; top < HEIGHT; top += STRIP) {
      for (int r = 0; r < STRIP; ++r) {
        int y = top + r;
        int green = ((y + phase / 2) & 255) >> 2;
        for (int x = 0; x < WIDTH; ++x) {
          int red = ((x + phase) & 255) >> 3;
          int blue = ((x / 2 + y / 2 + phase) & 255) >> 3;
          uint16_t color = (red << 11) | (green << 5) | blue;
          if ((x & 31) == 0 || (y & 31) == 0) color = 0x2945;
          int dx = x - cx, dy = y - cy;
          int distance = dx * dx + dy * dy;
          if (distance <= 24 * 24) color = distance >= 21 * 21 ? 0 : 0xFFFF;
          dx = x - (WIDTH - cx); dy = y - (305 - cy);
          distance = dx * dx + dy * dy;
          if (distance <= 17 * 17) color = distance >= 14 * 14 ? 0xFFFF : 0xF800;
          if (y >= 252 && y < 270)
            color = ((x + y) & 1) ? 0xFFFF : 0;
          if (x >= 8 && x < 232) {
            int panelY = y >= 8 && y < 50 ? y - 8 :
                         y >= 280 && y < 312 ? 42 + y - 280 : -1;
            if (panelY >= 0) {
              // 16-bit sprite memory stores bytes in display order; the strip
              // stores native RGB565 and pushImage performs its byte swap.
              uint16_t packed = hudPixels[panelY * 224 + x - 8];
              uint16_t overlay = (packed >> 8) | (packed << 8);
              if (overlay != TFT_MAGENTA) color = overlay;
            }
          }
          displayPixels[r * WIDTH + x] = color;
        }
      }
      tft.pushImage(0, top, WIDTH, STRIP, displayPixels);
    }
    tft.endWrite();
    ++totalFrames; ++windowFrames;
    unsigned long duration = millis() - windowAt;
    if (duration >= 1000) {
      fps = windowFrames * 1000.0f / duration;
      updateHud();
      Serial.printf("[DisplayDemo] full_frame_fps=%.2f frames=%lu spi_mhz=%d\n",
                    fps, totalFrames, settings.tft_spi_freq / 10);
      windowAt = millis(); windowFrames = 0;
    }
    yield();
  }
  tft.setSwapBytes(oldSwap);
  Serial.printf("[DisplayDemo] ended frames=%lu\n", totalFrames);
}
