#include "game.h"
#include "modern_icons_40x40.h"
#include "config.h"

// Define apps
struct App {
  const char* label;
  int x_coord;
  int y_coord;
  const uint16_t* img;
  int gameIndex; // Positive indices launch a game/app; -1 opens a utility.
};

App Apps[] = {
  {"TETRIS",   0, 0, tetris_icon,   1},
  {"SNAKE",    0, 0, snake_icon,    2},
  {"BREAKOUT", 0, 0, breakout_icon, 3},
  {"RUN",      0, 0, run_icon,      4},
  {"GALAGA",   0, 0, galaga_icon,   5},
  {"PUZZLE",   0, 0, tetris_icon,   6},
  {"TIC-TAC",  0, 0, tic_tac_icon,  7},
  {"PONG",     0, 0, pong_icon,     8},
  {"MINES",    0, 0, mines_icon,    9},
  {"Conway's", 0, 0, life_icon,    10},
  {"MANDEL",   0, 0, mandelbrot_icon,11},
  {"SOUND",    0, 0, sound_icon,   -1},
  {"SETTINGS", 0, 0, settings_icon,-1},
  {"ABOUT",    0, 0, about_icon,   -1}
};

const int APP_COUNT = sizeof(Apps) / sizeof(App);

// Fixed portrait layout. Every drawn area stays inside its own bounds.
// Header: 0..61, section: 65..82, grid: 88..279, footer: 288..309.
constexpr int PORTRAIT_W = 240;
constexpr int PORTRAIT_H = 320;
constexpr int COLS = 3;
constexpr int VISIBLE_ROWS = 3;
constexpr int TILE_W = 70;
constexpr int TILE_H = 60;
constexpr int START_Y = 88;
constexpr int COL_GAP = 8;
constexpr int ROW_GAP = 6;
constexpr int MARGIN_LEFT = 7;
constexpr int FOOTER_Y = 288;
#define MENU_CARD UI_ICON_BG
#define MENU_ACCENT UI_CYAN
#define MENU_ACCENT_DIM UI_PURPLE

static_assert(MARGIN_LEFT * 2 + COLS * TILE_W + (COLS - 1) * COL_GAP == PORTRAIT_W,
              "Menu tiles must fit the screen width");
static_assert(START_Y + VISIBLE_ROWS * TILE_H + (VISIBLE_ROWS - 1) * ROW_GAP < FOOTER_Y,
              "Menu tiles must end above the footer");
static_assert(FOOTER_Y + 22 <= PORTRAIT_H - 10,
              "Menu footer must leave a bottom margin");

int selectedApp = 0;
int scrollOffset = 0;
unsigned long lastAnimTime = 0;
bool highlightBright = true;

void drawAppTile(int index, bool selected = false);
void redrawVisibleTiles();

// Blend RGB565 channels independently so gradients never change hue at bit boundaries.
static uint16_t menuBlend(uint16_t a, uint16_t b, int amount) {
  int r = (((a >> 11) & 31) * (255 - amount) + ((b >> 11) & 31) * amount) / 255;
  int g = (((a >> 5) & 63) * (255 - amount) + ((b >> 5) & 63) * amount) / 255;
  int blue = ((a & 31) * (255 - amount) + (b & 31) * amount) / 255;
  return (r << 11) | (g << 5) | blue;
}

static void drawMenuCard(int x, int y, int w, int h, uint16_t top, uint16_t bottom) {
  const int radius = 8;
  for (int row = 0; row < h; ++row) {
    int edge = min(row, h - 1 - row);
    int inset = edge < radius
        ? radius - (int)sqrtf(radius * radius - (radius - edge) * (radius - edge)) : 0;
    tft.drawFastHLine(x + inset, y + row, w - inset * 2,
                     menuBlend(top, bottom, row * 255 / (h - 1)));
  }
}

void drawModernIcon(int index, int x, int y, bool selected) {
  const uint16_t primary = selected ? UI_BG : UI_TEXT;
  const uint16_t secondary = selected ? UI_SURFACE : UI_MUTED;
  const uint16_t iconBg = selected ? TFT_WHITE : MENU_CARD;

  switch (index) {
    case 0: { // Tetris: compact falling blocks
      const uint16_t c = selected ? UI_BG : UI_CYAN;
      const int blocks[][2] = {{7, 4}, {15, 4}, {15, 12}, {23, 12},
                               {7, 25}, {15, 25}, {23, 25}, {23, 17}};
      for (int i = 0; i < 8; i++)
        tft.fillRoundRect(x + blocks[i][0], y + blocks[i][1], 7, 7, 2, c);
      break;
    }
    case 1: { // Snake: smooth segmented path and eye
      const int points[][2] = {{8, 9}, {15, 9}, {22, 9}, {29, 9},
                               {29, 16}, {22, 16}, {15, 16}, {15, 23},
                               {22, 23}, {29, 23}, {29, 30}};
      for (int i = 0; i < 11; i++)
        tft.fillCircle(x + points[i][0], y + points[i][1], 4,
                       selected ? UI_BG : UI_GREEN);
      tft.fillCircle(x + 30, y + 29, 1, selected ? TFT_WHITE : UI_BG);
      break;
    }
    case 2: // Breakout: paddle, ball, and floating bricks
      for (int row = 0; row < 2; row++)
        for (int col = 0; col < 3; col++)
          tft.fillRoundRect(x + 4 + col * 11, y + 5 + row * 7,
                            9, 5, 2, selected ? UI_BG : (row ? UI_PURPLE : UI_CYAN));
      tft.fillCircle(x + 23, y + 23, 3, primary);
      tft.fillRoundRect(x + 9, y + 31, 22, 4, 2, primary);
      break;
    case 3: // Run: minimal moving figure
      tft.fillCircle(x + 24, y + 7, 4, primary);
      tft.drawWideLine(x + 21, y + 13, x + 16, y + 23, 4, primary, iconBg);
      tft.drawWideLine(x + 18, y + 17, x + 29, y + 20, 3, primary, iconBg);
      tft.drawWideLine(x + 17, y + 23, x + 9, y + 33, 4, primary, iconBg);
      tft.drawWideLine(x + 17, y + 23, x + 29, y + 31, 4, primary, iconBg);
      tft.drawFastHLine(x + 4, y + 36, 32, secondary);
      break;
    case 4: // Galaga: symmetric modern spacecraft
      tft.fillTriangle(x + 20, y + 3, x + 8, y + 32, x + 32, y + 32, primary);
      tft.fillTriangle(x + 7, y + 17, x + 2, y + 34, x + 14, y + 30, secondary);
      tft.fillTriangle(x + 33, y + 17, x + 38, y + 34, x + 26, y + 30, secondary);
      tft.fillTriangle(x + 20, y + 12, x + 15, y + 27, x + 25, y + 27,
                       iconBg);
      break;
    case 5: // Sound: speaker with two clean wave arcs
      tft.fillRoundRect(x + 5, y + 15, 8, 11, 2, primary);
      tft.fillTriangle(x + 12, y + 15, x + 23, y + 7, x + 23, y + 34, primary);
      tft.drawCircle(x + 23, y + 20, 9, secondary);
      tft.drawCircle(x + 23, y + 20, 15, primary);
      tft.fillRect(x, y, 23, 40, iconBg);
      tft.fillRoundRect(x + 5, y + 15, 8, 11, 2, primary);
      tft.fillTriangle(x + 12, y + 15, x + 23, y + 7, x + 23, y + 34, primary);
      break;
    case 6: { // Settings: simple gear
      tft.fillCircle(x + 20, y + 20, 14, primary);
      for (int a = 0; a < 8; a++) {
        float angle = a * PI / 4.0f;
        int gx = x + 20 + (int)(16 * cos(angle));
        int gy = y + 20 + (int)(16 * sin(angle));
        tft.fillCircle(gx, gy, 3, primary);
      }
      tft.fillCircle(x + 20, y + 20, 7, iconBg);
      tft.fillCircle(x + 20, y + 20, 3, secondary);
      break;
    }
    case 7: // About: restrained information symbol
      tft.drawCircle(x + 20, y + 20, 15, primary);
      tft.fillCircle(x + 20, y + 12, 2, primary);
      tft.fillRoundRect(x + 18, y + 17, 4, 13, 2, primary);
      break;
  }
}

void drawBottomBar() {
  tft.fillRoundRect(7, FOOTER_Y, 226, 22, 6, UI_PANEL);
  tft.drawFastVLine(PORTRAIT_W / 2, FOOTER_Y + 5, 12, UI_SURFACE);
  tft.setTextFont(1);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("D-PAD", 16, FOOTER_Y + 7);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("MOVE", 57, FOOTER_Y + 7);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("SHOOT", 137, FOOTER_Y + 7);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("OPEN", 184, FOOTER_Y + 7);
}

void displayMenuTitle() {
  tft.fillScreen(UI_BG);
  drawMenuCard(7, 4, 226, 58, menuBlend(UI_PANEL, UI_CYAN, 24), UI_PANEL);
  tft.fillRoundRect(9, 11, 3, 37, 1, MENU_ACCENT);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT);
  tft.drawString("GAME", 20, 8);
  tft.drawString("CONSOLE", 20, 27);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED);
  tft.drawString("PICK YOUR NEXT ADVENTURE", 20, 49);

  int playable = 0;
  for (int i = 0; i < APP_COUNT; i++) {
    if (Apps[i].gameIndex > 0) playable++;
  }
  char count[4];
  snprintf(count, sizeof(count), "%02d", playable);
  tft.setTextDatum(TR_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(MENU_ACCENT);
  tft.drawString(count, 228, 8);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED);
  tft.drawString("PLAYABLE", 228, 43);

  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(UI_MUTED, UI_BG);
  tft.drawString("LIBRARY", 9, 68);
  tft.drawFastHLine(9, 82, PORTRAIT_W - 18, UI_SURFACE);
}

void drawLibraryPosition() {
  tft.fillRect(181, 65, 50, 14, UI_BG);
  char position[12];
  snprintf(position, sizeof(position), "%02d / %02d", selectedApp + 1, APP_COUNT);
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(MENU_ACCENT, UI_BG);
  tft.drawString(position, 231, 68);
}

void getTileCoordinates(int index, int &outX, int &outY) {
  int col = index % COLS;
  int row = index / COLS;
  int visibleRow = row - scrollOffset;
  outX = MARGIN_LEFT + col * (TILE_W + COL_GAP);
  outY = START_Y + visibleRow * (TILE_H + ROW_GAP);
}

void drawSelectionAccent(int index) {
  int row = index / COLS;
  if (row < scrollOffset || row >= scrollOffset + VISIBLE_ROWS) return;
  int x, y;
  getTileCoordinates(index, x, y);
  uint16_t accent = MENU_ACCENT;
  tft.drawRoundRect(x, y, TILE_W, TILE_H, 8, accent);
  tft.drawRoundRect(x + 1, y + 1, TILE_W - 2, TILE_H - 2, 7, accent);
  tft.drawRoundRect(x + 2, y + 2, TILE_W - 4, TILE_H - 4, 6,
                    menuBlend(MENU_ACCENT, UI_PURPLE, 128));
}

void drawAppTile(int index, bool selected) {
  int row = index / COLS;
  if (row < scrollOffset || row >= scrollOffset + VISIBLE_ROWS) return;
  int x, y;
  getTileCoordinates(index, x, y);
  Apps[index].x_coord = x;
  Apps[index].y_coord = y;

  uint16_t fill = MENU_CARD;
  const uint16_t accents[] = {UI_PURPLE, UI_GREEN, UI_RED, UI_YELLOW, UI_CYAN};
  uint16_t accent = accents[index % (sizeof(accents) / sizeof(accents[0]))];
  drawMenuCard(x, y, TILE_W, TILE_H, menuBlend(fill, accent, 30), fill);
  if (!selected) tft.drawRoundRect(x, y, TILE_W, TILE_H, 8, UI_SURFACE);

  // The alpha-clean conversion reserves one exact RGB565 value for transparency.
  tft.setSwapBytes(true);
  if (Apps[index].img) {
    tft.pushImage(x + 15, y + 3, 40, 40, Apps[index].img, 0xF81F);
  } else if (Apps[index].gameIndex == 7) {
    tft.drawFastVLine(x + 29, y + 8, 28, UI_MUTED);
    tft.drawFastVLine(x + 40, y + 8, 28, UI_MUTED);
    tft.drawFastHLine(x + 20, y + 18, 30, UI_MUTED);
    tft.drawFastHLine(x + 20, y + 28, 30, UI_MUTED);
    tft.drawLine(x + 22, y + 10, x + 27, y + 15, UI_CYAN);
    tft.drawLine(x + 27, y + 10, x + 22, y + 15, UI_CYAN);
    tft.drawCircle(x + 35, y + 23, 3, UI_YELLOW);
  } else if (Apps[index].gameIndex == 8) {
    tft.fillRoundRect(x + 16, y + 8, 4, 28, 2, UI_CYAN);
    tft.fillRoundRect(x + 50, y + 8, 4, 28, 2, UI_PURPLE);
    tft.drawFastVLine(x + 35, y + 10, 24, UI_MUTED);
    tft.fillCircle(x + 37, y + 19, 4, UI_YELLOW);
  } else {
    for (int r = 0; r < 4; ++r)
      for (int c = 0; c < 4; ++c)
        tft.fillRoundRect(x + 17 + c * 10, y + 6 + r * 9, 8, 7, 2,
                          (r == 1 && c == 2) ? UI_RED : UI_SURFACE);
    tft.fillTriangle(x + 41, y + 16, x + 41, y + 23, x + 48, y + 19, UI_YELLOW);
  }
  tft.setTextColor(selected ? MENU_ACCENT : UI_TEXT);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.drawString(Apps[index].label, x + TILE_W / 2, y + 51);
  if (selected) drawSelectionAccent(index);
}

void redrawVisibleTiles() {
  tft.fillRect(0, 84, PORTRAIT_W, FOOTER_Y - 84, UI_BG);
  int startApp = scrollOffset * COLS;
  int endApp = min(startApp + (VISIBLE_ROWS * COLS), APP_COUNT);
  for (int i = startApp; i < endApp; i++) {
    drawAppTile(i, i == selectedApp);
  }
  drawLibraryPosition();
  drawBottomBar();
}

// Selection changes only affect the border and label. Preserve the icon and
// card interior so navigation does not block on repainting thousands of pixels.
void updateAppSelection(int index, bool selected) {
  int row = index / COLS;
  if (row < scrollOffset || row >= scrollOffset + VISIBLE_ROWS) return;
  int x, y;
  getTileCoordinates(index, x, y);
  if (!selected) {
    const uint16_t accents[] = {UI_PURPLE, UI_GREEN, UI_RED, UI_YELLOW, UI_CYAN};
    uint16_t top = menuBlend(MENU_CARD, accents[index % 5], 30);
    tft.startWrite();
    for (int r = 0; r < TILE_H; ++r) {
      int edge = min(r, TILE_H - 1 - r);
      int inset = edge < 8 ? 8 - (int)sqrtf(64 - (8 - edge) * (8 - edge)) : 0;
      uint16_t color = menuBlend(top, MENU_CARD, r * 255 / (TILE_H - 1));
      if (edge < 3) {
        tft.drawFastHLine(x, y + r, TILE_W, UI_BG);
        tft.drawFastHLine(x + inset, y + r, TILE_W - inset * 2, color);
      } else {
        int strip = edge < 8 ? 9 : 3;
        tft.drawFastHLine(x, y + r, strip, UI_BG);
        tft.drawFastHLine(x + TILE_W - strip, y + r, strip, UI_BG);
        tft.drawFastHLine(x + inset, y + r, strip - inset, color);
        tft.drawFastHLine(x + TILE_W - strip, y + r, strip - inset, color);
      }
    }
    tft.drawRoundRect(x, y, TILE_W, TILE_H, 8, UI_SURFACE);
    tft.endWrite();
  } else drawSelectionAccent(index);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(selected ? MENU_ACCENT : UI_TEXT);
  tft.drawString(Apps[index].label, x + TILE_W / 2, y + 51);
}

void showAboutScreen() {
  tft.fillRoundRect(14, 42, 212, 244, 12, UI_PANEL);
  tft.drawRoundRect(14, 42, 212, 244, 12, UI_SURFACE);
  
  tft.fillRect(26, 56, 24, 3, MENU_ACCENT);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("DEVICE / SPECIFICATIONS", 26, 68);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("CONSOLE", 26, 82);

  const char* specs[][2] = {
    {"CPU ARCH", "ESP32-C3 RISC-V"},
    {"CLOCK", "160 MHz"},
    {"DISPLAY", "ILI9341 240x320"},
    {"ADC INPUT", "ADS1115 16-Bit I2C"},
    {"AUDIO", "GPIO 10 LEDC PWM"}
  };

  tft.setTextFont(1);
  for (int i = 0; i < 5; i++) {
    int sy = 126 + i * 24;
    tft.fillRoundRect(24, sy - 2, 192, 20, 4, UI_ICON_BG);
    tft.setTextDatum(ML_DATUM);
    tft.setTextColor(UI_MUTED, UI_ICON_BG);
    tft.drawString(specs[i][0], 30, sy + 7);
    tft.setTextDatum(MR_DATUM);
    tft.setTextColor(UI_TEXT, UI_ICON_BG);
    tft.drawString(specs[i][1], 208, sy + 7);
  }
  
  tft.drawFastHLine(24, 252, 192, UI_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("PRESS SHOOT TO RETURN", 120, 268);
  
  delay(300);
  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      Serial.read();
      break;
    }
    if (c == 4 || c == 0 || c == 1 || c == 2 || c == 3) break;
    delay(20);
  }
  menuSetup();
}

struct SongNote {
  uint16_t freq;
  uint16_t duration;
};

struct Track {
  const char* title;
  const char* artist;
  const SongNote* notes;
  int noteCount;
};

// 1. Never Gonna Give You Up (Rick Astley)
const SongNote rickNotes[] = {
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {494, 280}, {440, 380}, {0, 140},
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {440, 280}, {392, 380}, {0, 140},
  {294, 150}, {330, 150}, {392, 150}, {330, 150},
  {392, 220}, {440, 200}, {370, 280}, {330, 220}, {294, 380}
};

// 2. Astronomia / Coffin Dance (Vicetone)
const SongNote astronomiaNotes[] = {
  {587, 110}, {587, 110}, {587, 110}, {587, 110},
  {392, 220}, {494, 220}, {440, 220}, {523, 220},
  {494, 220}, {392, 220}, {440, 220}, {587, 220},
  {494, 220}, {392, 220}, {440, 220}, {587, 220}
};

// 3. Blinding Lights (The Weeknd)
const SongNote blindingNotes[] = {
  {698, 170}, {698, 170}, {622, 170}, {698, 220},
  {784, 220}, {523, 330}, {0, 90},
  {698, 170}, {698, 170}, {622, 170}, {698, 220},
  {784, 220}, {523, 330}, {0, 90},
  {784, 170}, {784, 170}, {698, 170}, {622, 220}, {523, 380}
};

// 4. Bad Guy (Billie Eilish)
const SongNote badGuyNotes[] = {
  {392, 130}, {392, 130}, {392, 130}, {294, 130},
  {349, 130}, {392, 130}, {0, 130},
  {392, 130}, {392, 130}, {392, 130}, {294, 130},
  {349, 130}, {392, 130}, {0, 130},
  {466, 130}, {440, 130}, {392, 260}
};

// 5. Despacito (Luis Fonsi) - Extended Chorus & Main Hook
const SongNote despacitoNotes[] = {
  // Main iconic intro hook: D5 - C#5 - B4 - F#4
  {587, 300}, {554, 180}, {494, 200}, {370, 220}, {0, 100},
  // "Des - pa - ci - to..."
  {370, 140}, {370, 140}, {370, 140}, {370, 140},
  {494, 180}, {494, 180}, {494, 180}, {494, 240},
  {440, 160}, {494, 160}, {392, 360}, {0, 120},
  // Second phrase: "Quiero respirar tu cuello despacito..."
  {392, 140}, {392, 140}, {392, 140}, {392, 140},
  {392, 180}, {494, 180}, {494, 180}, {494, 240},
  {440, 160}, {392, 160}, {440, 320}, {0, 120},
  // Third phrase: "Deja que te diga cosas al oído..."
  {440, 140}, {440, 140}, {440, 140}, {440, 140},
  {440, 180}, {587, 180}, {587, 180}, {587, 240},
  {554, 160}, {494, 160}, {440, 280}, {370, 360}
};

// 6. Tetris Theme A (Korobeiniki)
const SongNote tetrisNotes[] = {
  {659, 220}, {494, 120}, {523, 120}, {587, 220}, {523, 120}, {494, 120},
  {440, 220}, {440, 120}, {523, 120}, {659, 220}, {587, 120}, {523, 120},
  {494, 280}, {523, 120}, {587, 220}, {659, 220},
  {523, 220}, {440, 220}, {440, 320}
};

const Track jukeboxPlaylist[] = {
  {"Never Gonna Give You Up", "Rick Astley", rickNotes, sizeof(rickNotes)/sizeof(rickNotes[0])},
  {"Astronomia (Coffin)",     "Vicetone",    astronomiaNotes, sizeof(astronomiaNotes)/sizeof(astronomiaNotes[0])},
  {"Blinding Lights",         "The Weeknd",  blindingNotes, sizeof(blindingNotes)/sizeof(blindingNotes[0])},
  {"Bad Guy",                 "Billie Eilish", badGuyNotes, sizeof(badGuyNotes)/sizeof(badGuyNotes[0])},
  {"Despacito",               "Luis Fonsi",  despacitoNotes, sizeof(despacitoNotes)/sizeof(despacitoNotes[0])},
  {"Tetris Korobeiniki",      "Retro Classic", tetrisNotes, sizeof(tetrisNotes)/sizeof(tetrisNotes[0])}
};

const int JUKEBOX_COUNT = sizeof(jukeboxPlaylist)/sizeof(jukeboxPlaylist[0]);

void playSoundTestScreen() {
  int currentSong = 4; // Default directly to Despacito (Track #5)
  bool isPlaying = false;
  
  auto drawJukeboxUI = [&]() {
    tft.fillRoundRect(14, 42, 212, 246, 12, UI_PANEL);
    tft.drawRoundRect(14, 42, 212, 246, 12, UI_SURFACE);
    
    tft.fillRect(26, 54, 24, 3, MENU_ACCENT);
    tft.setTextDatum(TL_DATUM);
    tft.setTextFont(1);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("AUDIO / CHIPTONE", 26, 64);
    tft.setTextFont(4);
    tft.setTextColor(UI_TEXT, UI_PANEL);
    tft.drawString("JUKEBOX", 26, 76);
    
    // Song list
    tft.setTextFont(1);
    for (int i = 0; i < JUKEBOX_COUNT; i++) {
      int y = 108 + i * 23;
      bool sel = (i == currentSong);
      
      if (sel) {
        tft.fillRoundRect(22, y - 2, 196, 21, 6, UI_ICON_BG);
        tft.drawRoundRect(22, y - 2, 196, 21, 6, UI_PURPLE);
        tft.drawRoundRect(23, y - 1, 194, 19, 5, UI_PURPLE);
        tft.drawRoundRect(24, y, 192, 17, 4, UI_CYAN);
        tft.setTextColor(UI_TEXT, UI_ICON_BG);
      } else {
        tft.fillRoundRect(22, y - 2, 196, 21, 6, UI_ICON_BG);
        tft.setTextColor(UI_MUTED, UI_ICON_BG);
      }
      
      char buf[36];
      snprintf(buf, sizeof(buf), "%d. %s", i + 1, jukeboxPlaylist[i].title);
      tft.setTextDatum(ML_DATUM);
      tft.drawString(buf, 28, y + 7);
      if (sel) {
        tft.setTextDatum(MR_DATUM);
        tft.drawString(isPlaying ? "||" : ">", 210, y + 7);
      }
    }
    
    // Status banner at bottom of card
    tft.drawFastHLine(22, 248, 196, UI_SURFACE);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(isPlaying ? MENU_ACCENT : UI_MUTED, UI_PANEL);
    tft.drawString(isPlaying ? "NOW PLAYING" : "SHOOT: PLAY / PAUSE", 120, 258);
    tft.setTextColor(UI_MUTED, UI_PANEL);
    tft.drawString("UP/DOWN: PICK  |  LEFT: EXIT", 120, 272);
  };
  
  drawJukeboxUI();
  delay(250);

  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      char sc = Serial.read();
      if (sc == ' ' || sc == 'x' || sc == 'e') c = 4;
      else if (sc == 'w') c = 0;
      else if (sc == 's') c = 2;
      else if (sc == 'a' || sc == 'q') c = 3;
    }
    
    // Exit back to menu on LEFT (command 3)
    if (c == 3) {
      setBuzzerTone(0);
      playNavClick();
      break;
    }

    if (c == 0) { // UP
      setBuzzerTone(0);
      isPlaying = false;
      currentSong = (currentSong - 1 + JUKEBOX_COUNT) % JUKEBOX_COUNT;
      playNavClick();
      drawJukeboxUI();
      delay(150);
    } else if (c == 2) { // DOWN
      setBuzzerTone(0);
      isPlaying = false;
      currentSong = (currentSong + 1) % JUKEBOX_COUNT;
      playNavClick();
      drawJukeboxUI();
      delay(150);
    } else if (c == 4) { // SHOOT: Play / Stop
      if (isPlaying) {
        setBuzzerTone(0);
        isPlaying = false;
        drawJukeboxUI();
        delay(200);
      } else {
        isPlaying = true;
        drawJukeboxUI();
        
        // Play selected track with interactive abort on any button press
        const Track& trk = jukeboxPlaylist[currentSong];
        for (int i = 0; i < trk.noteCount; i++) {
          // Check for button press to stop or change song
          int interruptCmd = findCommand();
          if (interruptCmd == 4 || interruptCmd == 0 || interruptCmd == 2 || interruptCmd == 3) {
            setBuzzerTone(0);
            isPlaying = false;
            break;
          }
          if (Serial.available()) {
            Serial.read();
            setBuzzerTone(0);
            isPlaying = false;
            break;
          }
          
          uint16_t freq = trk.notes[i].freq;
          uint16_t dur = trk.notes[i].duration;
          
          if (freq > 0) {
            setBuzzerTone(freq);
          } else {
            setBuzzerTone(0);
          }
          
          // Mini visualizer bar in card
          int barW = map(freq, 200, 900, 10, 180);
          barW = constrain(barW, 10, 180);
          tft.fillRect(30, 240, 180, 4, UI_PANEL);
          if (freq > 0) {
            tft.fillRect(30, 240, barW, 4, MENU_ACCENT_DIM);
          }
          
          delay(dur);
          setBuzzerTone(0);
          delay(20);
        }
        
        setBuzzerTone(0);
        isPlaying = false;
        drawJukeboxUI();
      }
    }
    delay(20);
  }
  
  setBuzzerTone(0);
  menuSetup();
}

void drawSettingsRow(int row, bool selected) {
  const int y = 106 + row * 62;
  const uint16_t fill = UI_ICON_BG;
  const uint16_t ink = UI_TEXT;

  tft.fillRoundRect(22, y, 196, 50, 9, fill);
  tft.drawRoundRect(22, y, 196, 50, 9, selected ? UI_PURPLE : UI_SURFACE);
  if (selected) {
    tft.drawRoundRect(23, y + 1, 194, 48, 8, UI_PURPLE);
    tft.drawRoundRect(24, y + 2, 192, 46, 7, UI_CYAN);
  }

  tft.setTextFont(1);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(selected ? UI_TEXT : UI_MUTED, fill);
  tft.drawString(row == 0 ? "APPEARANCE" : "SYSTEM AUDIO", 32, y + 8);

  tft.setTextFont(2);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(ink, fill);
  tft.drawString(row == 0 ? "THEME" : "SOUND", 32, y + 32);

  tft.setTextDatum(MR_DATUM);
  if (row == 0) {
    tft.setTextFont(1);
    tft.drawString(themeName(activeTheme), 207, y + 32);
  } else {
    tft.setTextFont(2);
    tft.drawString(soundEnabled ? "ON" : "OFF", 207, y + 32);
  }
}

void drawSettingsScreen(int selectedRow) {
  tft.fillScreen(UI_BG);
  tft.fillRoundRect(12, 12, 216, 296, 14, UI_PANEL);
  tft.drawRoundRect(12, 12, 216, 296, 14, UI_SURFACE);

  tft.fillRoundRect(24, 25, 4, 50, 2, UI_CYAN);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("CONSOLE / PERSONALIZE", 38, 26);
  tft.setTextFont(4);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("SETTINGS", 38, 42);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("Changes preview instantly", 38, 71);

  drawSettingsRow(0, selectedRow == 0);
  drawSettingsRow(1, selectedRow == 1);

  // Eight palette indicators fit between the audio card and help section.
  for (int i = 0; i < THEME_COUNT; ++i) {
    const uint16_t swatches[] = {0x2EDC, 0x34BF, 0xC01A, 0xE800,
                                0xCFE0, 0xFE48, 0x5FBA, 0xEF7D};
    int x = 43 + i * 22;
    tft.fillCircle(x, 228, 4, swatches[i]);
    if (i == activeTheme) tft.drawCircle(x, 228, 7, UI_TEXT);
  }

  tft.drawFastHLine(24, 238, 192, UI_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("UP / DOWN    SELECT", 120, 253);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.drawString("LEFT / RIGHT    CHANGE", 120, 270);
  tft.setTextColor(UI_GREEN, UI_PANEL);
  tft.drawString("SHOOT    SAVE & EXIT", 120, 289);
}

void showSettingsScreen() {
  int selectedRow = 0;
  drawSettingsScreen(selectedRow);
  delay(220);

  while (true) {
    int cmd = findCommand();
    if (Serial.available()) {
      char c = Serial.read();
      if (c == 'w' || c == 'W') cmd = 0;
      else if (c == 'd' || c == 'D') cmd = 1;
      else if (c == 's' || c == 'S') cmd = 2;
      else if (c == 'a' || c == 'A') cmd = 3;
      else if (c == ' ' || c == '\n' || c == '\r' || c == 'e' || c == 'E' || c == 'x' || c == 'X') cmd = 4;
    }

    if (cmd == 0 || cmd == 2) {
      selectedRow = 1 - selectedRow;
      playNavClick();
      drawSettingsScreen(selectedRow);
      delay(100);
    } else if (cmd == 1 || cmd == 3) {
      if (selectedRow == 0) {
        int direction = (cmd == 1) ? 1 : -1;
        applyThemePreset((activeTheme + direction + THEME_COUNT) % THEME_COUNT, false);
        playNavClick();
      } else {
        setSoundEnabled(!soundEnabled, false);
        playNavClick();
      }
      drawSettingsScreen(selectedRow);
      delay(100);
    } else if (cmd == 4) {
      applyThemePreset(activeTheme, true);
      setSoundEnabled(soundEnabled, true);
      playSelectTone();
      menuSetup();
      return;
    }
    delay(16);
  }
}

void showNotice(const char* name) {
  tft.fillRoundRect(20, 100, 200, 120, 12, UI_PANEL);
  tft.drawRoundRect(20, 100, 200, 120, 12, UI_SURFACE);
  tft.fillRect(36, 114, 20, 3, MENU_ACCENT);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.setTextFont(4);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(name, 120, 138);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.setTextFont(1);
  tft.drawString("Feature Coming Soon", 120, 168);
  tft.drawFastHLine(36, 186, 168, UI_SURFACE);
  tft.setTextColor(MENU_ACCENT, UI_PANEL);
  tft.drawString("PRESS SHOOT TO RETURN", 120, 202);
  delay(300);
  while (true) {
    int c = findCommand();
    if (Serial.available()) {
      Serial.read();
      break;
    }
    if (c == 4 || c == 0 || c == 1 || c == 2 || c == 3) break;
    delay(20);
  }
  menuSetup();
}

void menuSetup() {
  Serial.println("[Menu] Opening Main Menu (3 apps per row, vertical mode)...");
  tft.setRotation(2); // Vertical (Portrait) mode: 240x320
  selectedApp = 0;
  scrollOffset = 0;
  highlightBright = true;
  displayMenuTitle();
  redrawVisibleTiles();
  lastAnimTime = millis();
}

void menuLoop() {
  unsigned long currentTime = millis();

  // Pulse only the pixels inside the selected card's border.
  if (currentTime - lastAnimTime >= 350) {
    lastAnimTime = currentTime;
    highlightBright = !highlightBright;
    drawSelectionAccent(selectedApp);
  }

  // Check inputs
  int cmd = findCommand();
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'w' || c == 'W') cmd = 0;       // UP
    else if (c == 'd' || c == 'D') cmd = 1;  // RIGHT
    else if (c == 's' || c == 'S') cmd = 2;  // DOWN
    else if (c == 'a' || c == 'A') cmd = 3;  // LEFT
    else if (c == ' ' || c == '\n' || c == '\r' || c == 'e' || c == 'E' || c == 'x' || c == 'X') cmd = 4; // SELECT
  }

  if (cmd == -1) return;

  int newSelected = selectedApp;

  switch (cmd) {
    case 0: // UP
      if (selectedApp >= COLS) newSelected = selectedApp - COLS;
      break;

    case 2: // DOWN
      if (selectedApp + COLS < APP_COUNT) newSelected = selectedApp + COLS;
      break;

    case 1: // RIGHT
      if (selectedApp + 1 < APP_COUNT) newSelected = selectedApp + 1;
      break;

    case 3: // LEFT
      if (selectedApp > 0) newSelected = selectedApp - 1;
      break;

    case 4: // SELECT
      {
        playSelectTone();
        int target = Apps[selectedApp].gameIndex;
        if (target > 0) {
          Serial.printf("[Menu] Launching Game %d: %s\n", target, Apps[selectedApp].label);
          switchGame(target);
          return;
        } else if (strcasecmp(Apps[selectedApp].label, "about") == 0) {
          showAboutScreen();
          return;
        } else if (strcasecmp(Apps[selectedApp].label, "sound") == 0) {
          playSoundTestScreen();
          return;
        } else if (strcasecmp(Apps[selectedApp].label, "settings") == 0) {
          showSettingsScreen();
          return;
        } else {
          showNotice(Apps[selectedApp].label);
          return;
        }
      }
      break;
  }

  if (newSelected != selectedApp) {
    playNavClick();
    updateAppSelection(selectedApp, false);
    selectedApp = newSelected;

    int newRow = selectedApp / COLS;
    if (newRow < scrollOffset) {
      scrollOffset = newRow;
      redrawVisibleTiles();
    } else if (newRow >= scrollOffset + VISIBLE_ROWS) {
      scrollOffset = newRow - VISIBLE_ROWS + 1;
      redrawVisibleTiles();
    } else {
      updateAppSelection(selectedApp, true);
    }
    drawLibraryPosition();
  }
}
