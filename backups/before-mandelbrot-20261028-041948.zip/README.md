# ESP32-C3 Retro Game Console (PlatformIO & TFT_eSPI)

A retro game console project running on the **ESP32-C3** with an **ILI9341 SPI TFT Display (320x240)** and **ADS1115 I2C ADC** for analog gamepad/button controls.

---

## 🎮 Included Games & Menus

- **Main Menu:** Icon grid launcher with animated selection glow.
- **Snake:** Nokia-style retro snake with particle effects and stars.
- **Breakout:** Brick-breaker game with bat and bouncing ball physics.
- **Tetris:** Classic block puzzle with rotation, line clearing, and pause menu.
- **Tic-tac-toe:** Play X against the console's O opponent. Move with the D-pad, tap Shoot to place, and hold Shoot to pause.
- **Pong:** Move the paddle with Left and Right, keep the ball in play, and survive three misses. Shoot pauses.
- **Minesweeper:** Clear an 8×8 board with ten mines. White raised tiles, colored numbers, red flags, and a magenta selection outline follow the supplied icon's style. Tap Shoot to reveal, hold Shoot to flag, and press Up while holding Shoot to pause. The first reveal is safe. A small dot marks a revealed tile with no neighboring mines.
- **Conway's Life:** Opens directly into an automatic B3/S23 simulation with wrapping edges. The launcher calls it **Conway's**. Random mode is the only simulation mode; the Info field guide explains the rules and illustrates common patterns across 16 pages. Only changed cells redraw during simulation.
- **Menu scrolling:** The launcher scrolls vertically to show additional rows of games and apps.
- **High Score System:** High scores persisted to ESP32 Flash via `Preferences` (NVS).

---

## Conway's Life controls

| Screen | Controls |
| :--- | :--- |
| Running | Shoot pauses; Up/Down changes speed. |
| Paused | Shoot resumes; Up/Down changes speed. |
| Run or pause | Hold Shoot to open options. |
| Options | Up/Down chooses; Shoot selects. Resume, new random, speed, Info, or main menu. Hold Shoot to return. |

Speed limits: 1, 2, 4, 8, 12, 20, or 30 generations per second; actual speed depends on how many pixels change. Default target is 20. The app reads the D-pad asynchronously, batches same-color cell updates, and refreshes counters five times per second. USB serial `p` reports measured generation rate and the last frame's duration.

Random mode uses 2-pixel cells on a 112×96 board (10,752 cells). There is no cell editor or start prompt.

Hold Shoot → Info to read the field guide. Left/Right changes pages; Shoot returns to options. It includes the laws, population changes, blocks, beehives, loaves, boats, blinkers, toads, beacons, gliders, lightweight spaceships, and pulsars. Moving examples animate independently while your random world stays paused and unchanged.

A cell is born with three live neighbors; a live cell survives with two or three. Populations naturally shrink from isolation or overcrowding, and may become still, oscillate, or die out. Opposite edges are connected, so traveling patterns can eventually collide with existing cells. Extinction is labeled on screen; the app does not silently reseed or alter Conway's rules.

The supplied Tic-tac-toe, Pong, Minesweeper, and Life icons are in the launcher. Gallery and Mandelbrot artwork is converted and ready for their future apps.

---

## 🔌 Hardware Circuit & Pinout

### 1. ILI9341 Display (SPI)
Configured via [`lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h`](file:///home/pahasara/Documents/antigravity/embedded/esp32c3-ili9341/lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h):

| ILI9341 Pin | ESP32-C3 Pin | Notes |
| :--- | :--- | :--- |
| **CS** | **GPIO 3** | Chip Select |
| **DC / RS** | **GPIO 1** | Data / Command Select |
| **RST / RESET** | **GPIO 2** | Display Hardware Reset |
| **MOSI / SDI** | **GPIO 0** | SPI Data Out |
| **SCLK / CLK** | **GPIO 4** | SPI Clock |
| **MISO / SDO** | **GPIO 10** | SPI Data In |
| **VCC** | **3.3V** / **5V** | Power |
| **GND** | **GND** | Ground |
| **LED / BL** | **3.3V** *(or GPIO)* | Backlight |

### 2. Controls & Peripherals

| Peripheral | ESP32-C3 Pin | Notes |
| :--- | :--- | :--- |
| **I2C SDA** | **GPIO 8** | Connected to ADS1115 ADC (`0x48`) |
| **I2C SCL** | **GPIO 9** | Connected to ADS1115 ADC (`0x48`) |
| **Shoot Button** | **GPIO 5** | Digital Input (`INPUT_PULLDOWN`) |

---

## 📁 Project Structure

```text
esp32c3-ili9341/
├── lib/
│   └── TFT_eSPI/           # Customized TFT_eSPI with ESP32-C3 register & timing fixes
├── src/
│   ├── gameConsoleNew.ino  # Entry point (setup and loop)
│   ├── game.h / game.ino   # Core Game engine, ADC input handler, high score manager
│   ├── menu.ino            # Main menu launcher & icon renderer
│   ├── snake.ino           # Snake game
│   ├── breakout.ino        # Breakout game
│   ├── tetris.ino          # Tetris game
│   ├── mini_games.ino      # Tic-tac-toe, Pong, and Minesweeper
│   ├── life.cpp            # Life interface, random world, and controls
│   ├── life_model.h        # Conway B3/S23 simulation
│   ├── life_guide.h        # Offline rules and animated pattern diagrams
│   ├── life_input.cpp      # Nonblocking ADS1115 controls for Life
│   ├── config.h            # Colors, screen dimensions, button pins
│   ├── icons.h             # 60x60 game icon bitmaps
│   ├── images.h            # UI bitmaps (pause, undo, play)
│   └── Petme8x8.h          # 8x8 bitmap font
├── platformio.ini          # PlatformIO config & library dependencies
└── README.md
```

---

## 🛠️ Build and Upload in VS Code

1. Open folder in VS Code:
   `/home/pahasara/Documents/antigravity/embedded/esp32c3-ili9341`
2. Click **Build (`✓`)** or press `Ctrl+Alt+B`.
3. Connect ESP32-C3 and click **Upload (`→`)**.
4. Open the Serial Monitor at `115200` baud.
