#include "game.h"
#include <Arduino.h>
#include "snake_background_240x320.h"

// =================================================================
// 1. MODERN IPHONE-INSPIRED SNAKE (PORTRAIT ORIENTATION: 240x320)
// =================================================================

// Display & Grid specifications
// Screen: 240 x 320 (Portrait rotation 2)
// Header Card: y = 5..43 (h = 38)
// Playfield Area: y = 48..288 (h = 240, w = 240)
// Bottom Dynamic Bar: y = 294..316 (h = 22)
constexpr int PLAYFIELD_X = 0;
constexpr int PLAYFIELD_Y = 48;
constexpr int PLAYFIELD_W = 240;
constexpr int PLAYFIELD_H = 240;
constexpr int BLOCK_SIZE  = 10;
constexpr int GRID_COLS   = PLAYFIELD_W / BLOCK_SIZE; // 24
constexpr int GRID_ROWS   = PLAYFIELD_H / BLOCK_SIZE; // 24
constexpr int MAX_SNAKE_LEN = GRID_COLS * GRID_ROWS;  // 576

// User's Original Grass Colors (Random Mosaic lawn, non-checkerboard)
#define GRASS1 0x07c0
#define GRASS2 0x0780
static const uint16_t grasses[] = { GRASS1, GRASS2 };

// Persistent random field for consistent cell grass colors across movement/refresh
static uint8_t lawnMap[GRID_COLS][GRID_ROWS];

static inline uint16_t getGrassColor(int gx, int gy) {
  if (gx < 0 || gx >= GRID_COLS || gy < 0 || gy >= GRID_ROWS) return GRASS1;
  return grasses[lawnMap[gx][gy]];
}

// Modern iOS Inspired Accents & UI
#define IOS_BG UI_BG
#define IOS_CARD UI_PANEL
#define IOS_SURFACE UI_SURFACE
#define IOS_WHITE UI_TEXT
#define IOS_MUTED UI_MUTED
constexpr uint16_t IOS_GREEN     = 0x3666;     // Apple Vibrant Mint/Green
constexpr uint16_t IOS_RED       = 0xFA48;     // Coral Crimson Apple
constexpr uint16_t IOS_AMBER     = 0xFE04;     // Golden Honey Yellow

// Snake Body & Apple Colors
constexpr uint16_t SNAKE_HEAD    = 0x001F;     // Crisp Cyan/Blue head accent on green lawn
constexpr uint16_t SNAKE_BODY_1  = 0x2016;     // Original Bright Green
constexpr uint16_t SNAKE_BODY_2  = 0x281F;     // Original Medium Green

// -----------------------------------------------------------------
// 2. DATA STRUCTURES & PARTICLES
// -----------------------------------------------------------------
struct SnakeParticle {
  float x, y;
  float speedX, speedY;
  uint16_t color;
  int life;
};

// -----------------------------------------------------------------
// 3. GAME STATE VARIABLES
// -----------------------------------------------------------------
static Vec2 snakeBody[MAX_SNAKE_LEN];
static int snakeLength = 4;
static int currentDirection = 1; // 0=UP, 1=RIGHT, 2=DOWN, 3=LEFT
static int lastDirection = 1;
static Vec2 foodPos;
static unsigned long lastMoveTime = 0;
static int gameSpeed_ms = 220;
static int snakePauseSelection = 0;
static bool snakePauseReady = false;
static bool snakeShootReady = false;

// Visual FX
static SnakeParticle particles[20];
static int particleCount = 0;
static bool foodPulse = false;

// -----------------------------------------------------------------
// 4. SOUND EFFECTS
// -----------------------------------------------------------------
static void playBiteSound() {
  setBuzzerTone(1175); // D6
  delay(35);
  setBuzzerTone(1760); // A6
  delay(45);
  setBuzzerTone(0);
}

static void playDeathSound() {
  setBuzzerTone(440);
  delay(80);
  setBuzzerTone(330);
  delay(90);
  setBuzzerTone(220);
  delay(140);
  setBuzzerTone(0);
}

// -----------------------------------------------------------------
// 5. RANDOM GRASS TILE & PLAYFIELD DRAWING
// -----------------------------------------------------------------
static void initRandomLawn() {
  for (int x = 0; x < GRID_COLS; x++) {
    for (int y = 0; y < GRID_ROWS; y++) {
      lawnMap[x][y] = (uint8_t)random(0, 2);
    }
  }
}

static void drawGrassyCell(int gx, int gy) {
  if (gx < 0 || gx >= GRID_COLS || gy < 0 || gy >= GRID_ROWS) return;
  int px = PLAYFIELD_X + gx * BLOCK_SIZE;
  int py = PLAYFIELD_Y + gy * BLOCK_SIZE;
  static uint16_t tile[BLOCK_SIZE * BLOCK_SIZE];
  for (int yy = 0; yy < BLOCK_SIZE; yy++) {
    for (int xx = 0; xx < BLOCK_SIZE; xx++) {
      tile[yy * BLOCK_SIZE + xx] = pgm_read_word(&snake_background_240x320[(py + yy) * 240 + px + xx]);
    }
  }
  tft.setSwapBytes(true);
  tft.pushImage(px, py, BLOCK_SIZE, BLOCK_SIZE, tile);
  tft.setSwapBytes(false);
}

static void renderFullGrassBoard() {
  tft.setSwapBytes(true);
  tft.pushImage(0, PLAYFIELD_Y, PLAYFIELD_W, PLAYFIELD_H,
                &snake_background_240x320[PLAYFIELD_Y * 240]);
  tft.setSwapBytes(false);
  // Clean hairline separating header and grassy lawn
  tft.drawFastHLine(0, PLAYFIELD_Y - 1, PLAYFIELD_W, 0x0540);
  tft.drawFastHLine(0, PLAYFIELD_Y + PLAYFIELD_H, PLAYFIELD_W, 0x0540);
}

// -----------------------------------------------------------------
// 6. MODERN IPHONE HEADER & HUD
// -----------------------------------------------------------------
static void drawModernHeader() {
  // Island Card Header: x=8, y=5, w=224, h=38
  tft.fillRoundRect(8, 5, 224, 38, 10, IOS_CARD);
  tft.drawRoundRect(8, 5, 224, 38, 10, IOS_SURFACE);

  // Left Section: Pill Tag & Game Title
  tft.fillRoundRect(16, 12, 44, 24, 6, IOS_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(IOS_GREEN, IOS_SURFACE);
  tft.drawString("SNAKE", 38, 24);

  // Center: Score Pill
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("SCORE", 72, 11);
  tft.setTextFont(2);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 72, 21);

  // Right: Best Record
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("BEST", 218, 11);
  tft.setTextFont(2);
  tft.setTextColor(IOS_AMBER, IOS_CARD);
  char bestStr[10];
  snprintf(bestStr, sizeof(bestStr), "%d", currentGame.highScores[0]);
  tft.drawString(bestStr, 218, 21);
}

static void updateScoreHUD() {
  // Fast partial update to score area
  tft.fillRect(72, 21, 55, 18, IOS_CARD);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  char scoreStr[10];
  snprintf(scoreStr, sizeof(scoreStr), "%d", score);
  tft.drawString(scoreStr, 72, 21);
}

static void drawBottomControlBar() {
  // Bottom dynamic pill bar: x=8, y=294, w=224, h=22
  tft.fillRoundRect(8, 294, 224, 22, 6, IOS_CARD);
  tft.setTextFont(1);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("D-PAD: TURN  |  SHOOT: PAUSE", 120, 305);
}

// -----------------------------------------------------------------
// 7. ENTITY RENDERING (SNAKE & APPLE)
// -----------------------------------------------------------------
void drawSnakeHead() {
  Vec2 head = snakeBody[0];
  int px = PLAYFIELD_X + head.x * BLOCK_SIZE;
  int py = PLAYFIELD_Y + head.y * BLOCK_SIZE;

  // Head block with rounded finish
  tft.fillRoundRect(px, py, BLOCK_SIZE, BLOCK_SIZE, 3, SNAKE_HEAD);

  // Direction-tracking eyes
  int eye1X = px + 2, eye1Y = py + 2;
  int eye2X = px + 6, eye2Y = py + 2;

  switch (currentDirection) {
    case 0: // UP
      eye1X = px + 2; eye1Y = py + 2;
      eye2X = px + 6; eye2Y = py + 2;
      break;
    case 2: // DOWN
      eye1X = px + 2; eye1Y = py + 6;
      eye2X = px + 6; eye2Y = py + 6;
      break;
    case 3: // LEFT
      eye1X = px + 2; eye1Y = py + 2;
      eye2X = px + 2; eye2Y = py + 6;
      break;
    case 1: // RIGHT
      eye1X = px + 6; eye1Y = py + 2;
      eye2X = px + 6; eye2Y = py + 6;
      break;
  }

  // Cute expressive eyes
  tft.fillCircle(eye1X, eye1Y, 1, IOS_WHITE);
  tft.fillCircle(eye2X, eye2Y, 1, IOS_WHITE);
}

static void drawSnakeSegment(int index) {
  Vec2 seg = snakeBody[index];
  int px = PLAYFIELD_X + seg.x * BLOCK_SIZE;
  int py = PLAYFIELD_Y + seg.y * BLOCK_SIZE;
  uint16_t col = (index % 2 == 0) ? SNAKE_BODY_1 : SNAKE_BODY_2;
  tft.fillRoundRect(px + 1, py + 1, BLOCK_SIZE - 2, BLOCK_SIZE - 2, 2, col);
}

static void drawApple() {
  int px = PLAYFIELD_X + foodPos.x * BLOCK_SIZE;
  int py = PLAYFIELD_Y + foodPos.y * BLOCK_SIZE;

  // Restore grassy cell background underneath apple
  drawGrassyCell(foodPos.x, foodPos.y);

  // High-contrast food marker: pure red fruit with a yellow glint.
  tft.fillCircle(px + 4, py + 5, 3, 0xF800);
  tft.fillCircle(px + 6, py + 5, 3, 0xF800);
  tft.drawPixel(px + 5, py + 2, 0xFFE0);
  tft.drawPixel(px + 3, py + 4, 0xFFE0);
}

// -----------------------------------------------------------------
// 8. PARTICLE FX
// -----------------------------------------------------------------
static void createAppleParticles(int gx, int gy) {
  int cx = PLAYFIELD_X + gx * BLOCK_SIZE + 5;
  int cy = PLAYFIELD_Y + gy * BLOCK_SIZE + 5;
  particleCount = 0;
  for (int i = 0; i < 12; i++) {
    particles[i].x = cx;
    particles[i].y = cy;
    float angle = (i / 12.0f) * 6.283f;
    float speed = random(12, 28) / 10.0f;
    particles[i].speedX = cos(angle) * speed;
    particles[i].speedY = sin(angle) * speed;
    particles[i].color = (i % 2 == 0) ? IOS_RED : TFT_GREEN;
    particles[i].life = random(6, 12);
    particleCount++;
  }
}

void updateParticles() {
  for (int i = 0; i < particleCount; i++) {
    if (particles[i].life > 0) {
      int prevX = (int)particles[i].x;
      int prevY = (int)particles[i].y;
      
      // Erase previous particle with actual grass color at that tile
      int gx = (prevX - PLAYFIELD_X) / BLOCK_SIZE;
      int gy = (prevY - PLAYFIELD_Y) / BLOCK_SIZE;
      if (gx >= 0 && gx < GRID_COLS && gy >= 0 && gy < GRID_ROWS) {
        tft.drawPixel(prevX, prevY, getGrassColor(gx, gy));
      }

      particles[i].x += particles[i].speedX;
      particles[i].y += particles[i].speedY;
      particles[i].life--;

      int nx = (int)particles[i].x;
      int ny = (int)particles[i].y;
      if (particles[i].life > 0 && nx >= PLAYFIELD_X && nx < PLAYFIELD_X + PLAYFIELD_W &&
          ny >= PLAYFIELD_Y && ny < PLAYFIELD_Y + PLAYFIELD_H) {
        tft.drawPixel(nx, ny, particles[i].color);
      }
    }
  }
}

// -----------------------------------------------------------------
// 9. FOOD GENERATION & COLLISION
// -----------------------------------------------------------------
void generateFood() {
  bool placed = false;
  int tries = 0;
  while (!placed && tries < 200) {
    tries++;
    foodPos.x = random(1, GRID_COLS - 1);
    foodPos.y = random(1, GRID_ROWS - 1);

    bool collision = false;
    for (int i = 0; i < snakeLength; i++) {
      if (foodPos.x == snakeBody[i].x && foodPos.y == snakeBody[i].y) {
        collision = true;
        break;
      }
    }
    if (!collision) placed = true;
  }
}

bool checkSelfCollision(Vec2 head) {
  for (int i = 1; i < snakeLength; i++) {
    if (head.x == snakeBody[i].x && head.y == snakeBody[i].y) {
      return true;
    }
  }
  return false;
}

// -----------------------------------------------------------------
// 10. INPUT & MOVEMENT
// -----------------------------------------------------------------
void handleInput() {
  if (digitalRead(SHOOT) == LOW) snakeShootReady = true;

  int cmd = findCommand();
  if (cmd == 4 && snakeShootReady) {
    gameState = 1; // Pause
    menu_drawn = false;
    snakePauseSelection = 0;
    snakePauseReady = false;
    return;
  }

  // Prevent 180-degree self-reversals
  bool isReverse = (cmd >= 0) && (abs(cmd - lastDirection) == 2);
  if (!isReverse && cmd >= 0 && cmd < 4) {
    currentDirection = cmd;
  }
}

void moveSnake() {
  Vec2 oldTail = snakeBody[snakeLength - 1];

  for (int i = snakeLength - 1; i > 0; i--) {
    snakeBody[i] = snakeBody[i - 1];
  }

  Vec2 newHead = snakeBody[0];
  switch (currentDirection) {
    case 0: newHead.y--; break; // UP
    case 1: newHead.x++; break; // RIGHT
    case 2: newHead.y++; break; // DOWN
    case 3: newHead.x--; break; // LEFT
  }

  // Toroidal Wrapping
  if (newHead.x < 0) newHead.x = GRID_COLS - 1;
  if (newHead.x >= GRID_COLS) newHead.x = 0;
  if (newHead.y < 0) newHead.y = GRID_ROWS - 1;
  if (newHead.y >= GRID_ROWS) newHead.y = 0;

  snakeBody[0] = newHead;
  lastDirection = currentDirection;

  // Collision with self -> Game Over
  if (checkSelfCollision(newHead)) {
    playDeathSound();
    gameState = 2;
    menu_drawn = false;
    return;
  }

  // Eating food
  if (newHead.x == foodPos.x && newHead.y == foodPos.y) {
    if (snakeLength < MAX_SNAKE_LEN) {
      snakeBody[snakeLength] = oldTail;
      snakeLength++;
    }
    score++;
    createAppleParticles(foodPos.x, foodPos.y);
    playBiteSound();

    if (gameSpeed_ms > 90) {
      gameSpeed_ms -= 6;
    }

    updateScoreHUD();
    generateFood();
    drawApple();
  } else {
    // Erase old tail with persistent random grass texture
    drawGrassyCell(oldTail.x, oldTail.y);
  }

  // Draw snake head and updated segments
  drawSnakeHead();
  if (snakeLength > 1) {
    drawSnakeSegment(1);
  }
}

// -----------------------------------------------------------------
// 11. MODAL SCREENS (START / PAUSE / GAME OVER)
// -----------------------------------------------------------------
void showSnakeMenu() {
  gameState = -1;
  tft.setRotation(2); // Strict Vertical / Portrait Orientation
  tft.fillScreen(IOS_BG);

  initRandomLawn();

  // Show the supplied grass artwork behind the instruction card.
  tft.setSwapBytes(true);
  tft.pushImage(0, 0, 240, 70, snake_background_240x320);
  tft.setSwapBytes(false);

  // Main Card in center
  tft.fillRoundRect(16, 70, 208, 235, 12, IOS_CARD);
  tft.drawRoundRect(16, 70, 208, 235, 12, IOS_SURFACE);

  // App Icon / Pill Header
  tft.fillRoundRect(28, 86, 50, 24, 6, IOS_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(IOS_GREEN, IOS_SURFACE);
  tft.drawString("SNAKE", 53, 98);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  tft.drawString("CLASSIC", 28, 118);
  tft.drawString("SNAKE", 28, 144);

  // Instruction list
  tft.setTextFont(1);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("CONTROLS", 28, 180);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  tft.drawString("D-PAD: Navigate snake", 28, 196);
  tft.drawString("SHOOT: Pause / Action", 28, 212);
  tft.drawString("Apples: +1 pt & speed boost", 28, 228);

  // Best score badge
  tft.fillRoundRect(28, 248, 184, 26, 6, IOS_SURFACE);
  tft.setTextColor(IOS_AMBER, IOS_SURFACE);
  tft.drawString("RECORD: " + String(currentGame.highScores[0]) + " PTS", 38, 256);

  // Pulsing start prompt at bottom
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(IOS_GREEN, IOS_CARD);
  tft.drawString("PRESS ANY KEY TO START", 120, 290);
}

void initGame() {
  gameState = 0;
  snakeLength = 4;
  currentDirection = 1;
  lastDirection = 1;
  score = 0;
  gameSpeed_ms = 220;
  particleCount = 0;
  snakeShootReady = false;

  initRandomLawn();

  tft.fillScreen(IOS_BG);
  drawModernHeader();
  renderFullGrassBoard();
  drawBottomControlBar();

  // Initial snake positioned in upper-middle lawn
  int startX = 6;
  int startY = 12;
  for (int i = 0; i < snakeLength; i++) {
    snakeBody[i] = { startX - i, startY };
  }

  for (int i = 1; i < snakeLength; i++) {
    drawSnakeSegment(i);
  }
  drawSnakeHead();

  generateFood();
  drawApple();
  lastMoveTime = millis();
}

static void drawSnakePauseOption(int item) {
  const char* labels[] = { "RESUME", "RESTART", "MAIN MENU" };
  int y = 140 + item * 34;
  bool selected = (item == snakePauseSelection);
  uint16_t fill = UI_ICON_BG;

  tft.fillRoundRect(36, y, 168, 28, 6, fill);
  if (selected) {
    tft.drawRoundRect(36, y, 168, 28, 6, UI_PURPLE);
    tft.drawRoundRect(37, y + 1, 166, 26, 5, UI_PURPLE);
    tft.drawRoundRect(38, y + 2, 164, 24, 4, UI_CYAN);
  }

  tft.setTextDatum(ML_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(selected ? IOS_WHITE : IOS_MUTED, fill);
  tft.drawString(labels[item], 48, y + 14);

  if (selected) {
    tft.setTextDatum(MR_DATUM);
    tft.drawString(">", 192, y + 14);
  }
}

static void drawSnakePauseMenu() {
  tft.fillRoundRect(24, 75, 192, 175, 12, IOS_CARD);
  tft.drawRoundRect(24, 75, 192, 175, 12, IOS_SURFACE);

  tft.fillRect(38, 91, 24, 3, IOS_GREEN);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  tft.drawString("PAUSED", 38, 99);

  for (int i = 0; i < 3; i++) {
    drawSnakePauseOption(i);
  }
}

static void handleSnakePause() {
  if (!snakePauseReady) {
    if (digitalRead(SHOOT) == LOW) snakePauseReady = true;
    return;
  }

  int cmd = findCommand();
  if (cmd == 0 || cmd == 2) { // UP / DOWN
    int old = snakePauseSelection;
    snakePauseSelection = (snakePauseSelection + (cmd == 0 ? 2 : 1)) % 3;
    drawSnakePauseOption(old);
    drawSnakePauseOption(snakePauseSelection);
    playNavClick();
  } else if (cmd == 4) { // SHOOT: Select
    playSelectTone();
    if (snakePauseSelection == 0) { // Resume
      // Redraw lawn and entities cleanly
      renderFullGrassBoard();
      drawApple();
      for (int i = 1; i < snakeLength; i++) drawSnakeSegment(i);
      drawSnakeHead();
      lastMoveTime = millis();
      gameState = 0;
      menu_drawn = false;
      snakeShootReady = false;
    } else if (snakePauseSelection == 1) { // Restart
      initGame();
    } else { // Exit to main menu
      switchGame(0);
    }
  }
}

static void drawSnakeGameOverScreen() {
  currentGame.recordScore(score);

  tft.fillRoundRect(24, 65, 192, 190, 12, IOS_CARD);
  tft.drawRoundRect(24, 65, 192, 190, 12, IOS_SURFACE);

  tft.fillRect(38, 81, 24, 3, IOS_RED);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("SNAKE / CRASHED", 38, 93);

  tft.setTextFont(4);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  tft.drawString("GAME OVER", 38, 107);

  // Score stats cards
  tft.setTextFont(1);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("SCORE", 38, 145);
  tft.drawString("BEST", 136, 145);

  tft.setTextFont(2);
  tft.setTextColor(IOS_WHITE, IOS_CARD);
  tft.drawString(String(score), 38, 158);
  tft.setTextColor(IOS_AMBER, IOS_CARD);
  tft.drawString(String(currentGame.highScores[0]), 136, 158);

  tft.drawFastHLine(38, 186, 164, IOS_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(IOS_GREEN, IOS_CARD);
  tft.drawString("SHOOT  PLAY AGAIN", 38, 198);
  tft.setTextColor(IOS_MUTED, IOS_CARD);
  tft.drawString("UP  MAIN MENU", 38, 218);
}

static void handleSnakeGameOver() {
  int cmd = findCommand();
  if (cmd == 4) {
    playSelectTone();
    initGame();
  } else if (cmd == 0) {
    playSelectTone();
    switchGame(0);
  }
}

// -----------------------------------------------------------------
// 12. LIFECYCLE (setupSnake & loopSnake)
// -----------------------------------------------------------------
void setupSnake() {
  tft.setRotation(2); // Strict Vertical / Portrait Orientation
  showSnakeMenu();
}

void loopSnake() {
  if (gameState == 0) {
    handleInput();

    if (millis() - lastMoveTime >= (unsigned long)gameSpeed_ms) {
      moveSnake();
      lastMoveTime = millis();
      drawApple();
    }

    if (particleCount > 0) {
      updateParticles();
    }
    return;
  } else if (gameState == 1) { // Pause Menu
    if (!menu_drawn) {
      drawSnakePauseMenu();
      menu_drawn = true;
    }
    handleSnakePause();
  } else if (gameState == 2) { // Game Over
    if (!menu_drawn) {
      drawSnakeGameOverScreen();
      menu_drawn = true;
    }
    handleSnakeGameOver();
  } else if (gameState == -1) { // Title Screen
    if (findCommand() >= 0) {
      playSelectTone();
      initGame();
    }
  }
}
