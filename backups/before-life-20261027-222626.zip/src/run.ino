#include "game.h"
#include <Arduino.h>
#include "run_background_240x320.h"

// =================================================================
// MODERN VERTICAL ENDLESS RUNNER (240x320 PORTRAIT ORIENTATION)
// =================================================================

// Portrait dimensions: 240 width x 320 height (Rotation 2)
// Header Card: y = 5..43 (h = 38)
// Playfield Area: y = 48..290 (w = 240, h = 242)
// Ground Line: y = 265, Ground Block: y = 266..290
// Bottom Dynamic Pill Bar: y = 295..316 (h = 21)

constexpr int RUN_W = 240;
constexpr int RUN_H = 320;
constexpr int RUN_PLAYFIELD_TOP = 48;
constexpr int RUN_GROUND_Y = 262;

// Runner Character Physics (Vertical Portrait space)
constexpr int RUNNER_X = 34;
constexpr int RUNNER_W = 20;
constexpr int RUNNER_H = 28;
// Compact arcade jump: about 49px high, enough to clear every barrier reliably.
constexpr float GRAVITY = 1.35f;
constexpr float JUMP_VELOCITY = -12.2f;

// Colors matching OLED Modern Palette
#define RUN_BG UI_BG
#define RUN_CARD UI_PANEL
#define RUN_SURFACE UI_SURFACE
#define RUN_WHITE UI_TEXT
#define RUN_MUTED UI_MUTED
#define RUN_CYAN UI_CYAN
constexpr uint16_t RUN_GREEN     = 0x3666;
constexpr uint16_t RUN_AMBER     = 0xFE04;
constexpr uint16_t RUN_RED       = 0xFA48;
constexpr uint16_t RUN_GROUND    = 0x0204;
constexpr uint16_t RUN_GROUND_HI = 0x07FF;

// -----------------------------------------------------------------
// GAME STATE
// -----------------------------------------------------------------
static float runnerY = RUN_GROUND_Y - RUNNER_H;
static float prevRunnerY = runnerY;
static float runnerVY = 0;
static bool isJumping = false;
static int legAnimFrame = 0;
static unsigned long runLastAnimTime = 0;
static float gameSpeed = 4.2f;

// Obstacles
struct RunObstacle {
  float x;
  int w, h;
  uint16_t color;
  bool active;
};
static const int MAX_RUN_OBS = 3;
static RunObstacle obs[MAX_RUN_OBS];
static unsigned long lastObsSpawn = 0;

static int runPauseSelection = 0;
static bool runPauseReady = false;
static bool runShootReady = false;

// Stars / Cloud speed lines in background
struct RunSpeedLine {
  float x, y;
  float speed;
  int len;
};
static RunSpeedLine speedLines[8];

static uint16_t runnerBackdropAt(int x, int y) {
  x = constrain(x, 0, RUN_W - 1);
  y = constrain(y, 0, RUN_H - 1);
  return pgm_read_word(&run_background_240x320[y * RUN_W + x]);
}

static void restoreRunnerBackdropRect(int x, int y, int w, int h) {
  int x0 = max(0, x);
  int x1 = min(RUN_W, x + w);
  int y0 = max(0, y);
  int y1 = min(RUN_H, y + h);
  if (x1 <= x0 || y1 <= y0) return;

  static uint16_t row[RUN_W];
  tft.setSwapBytes(true);
  for (int yy = y0; yy < y1; yy++) {
    for (int xx = x0; xx < x1; xx++) row[xx - x0] = runnerBackdropAt(xx, yy);
    tft.pushImage(x0, yy, x1 - x0, 1, row);
  }
  if (y0 <= RUN_GROUND_Y && y1 > RUN_GROUND_Y)
    tft.drawFastHLine(x0, RUN_GROUND_Y, x1 - x0, RUN_GROUND_HI);
  tft.setSwapBytes(false);
}

static void drawRunnerBackdrop() {
  tft.setSwapBytes(true);
  tft.pushImage(0, 0, RUN_W, RUN_H, run_background_240x320);
  tft.setSwapBytes(false);
}

// -----------------------------------------------------------------
// SOUND EFFECTS
// -----------------------------------------------------------------
static void soundJump() {
  setBuzzerTone(659); // E5
  delay(20);
  setBuzzerTone(880); // A5
  delay(30);
  setBuzzerTone(0);
}

static void soundCrash() {
  setBuzzerTone(220);
  delay(60);
  setBuzzerTone(165);
  delay(100);
  setBuzzerTone(0);
}

static void soundMilestone() {
  setBuzzerTone(1319);
  delay(40);
  setBuzzerTone(1760);
  delay(60);
  setBuzzerTone(0);
}

// -----------------------------------------------------------------
// BACKGROUND SPEED LINES & GROUND
// -----------------------------------------------------------------
static void initSpeedLines() {
  for (int i = 0; i < 8; i++) {
    speedLines[i].x = random(0, RUN_W);
    speedLines[i].y = random(148, 178);
    speedLines[i].speed = random(20, 45) / 10.0f;
    speedLines[i].len = random(8, 20);
  }
}

static void updateSpeedLines() {
  for (int i = 0; i < 8; i++) {
    // Erase old line
    restoreRunnerBackdropRect((int)speedLines[i].x, (int)speedLines[i].y,
                              speedLines[i].len, 1);

    speedLines[i].x -= speedLines[i].speed;
    if (speedLines[i].x + speedLines[i].len < 0) {
      speedLines[i].x = RUN_W + random(10, 40);
      speedLines[i].y = random(148, 178);
      speedLines[i].speed = random(20, 45) / 10.0f;
      speedLines[i].len = random(8, 20);
    }

    // Draw new line
    uint16_t streak = (i & 1) ? 0x07FF : 0xFFFF;
    tft.drawFastHLine((int)speedLines[i].x, (int)speedLines[i].y, speedLines[i].len, streak);
  }
}

static void drawGroundFloor() {
  tft.drawFastHLine(0, RUN_GROUND_Y, RUN_W, RUN_GROUND_HI);
}

// -----------------------------------------------------------------
// MODERN IPHONE HEADER & HUD
// -----------------------------------------------------------------
static void drawRunnerHeader() {
  // Island Card Header: x=8, y=5, w=224, h=38
  tft.fillRoundRect(8, 5, 224, 38, 10, RUN_CARD);
  tft.drawRoundRect(8, 5, 224, 38, 10, RUN_SURFACE);

  // Left Tag: Pill Tag
  tft.fillRoundRect(16, 12, 42, 24, 6, RUN_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(RUN_AMBER, RUN_SURFACE);
  tft.drawString("RUN", 37, 24);

  // Center: Distance / Score
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("DISTANCE", 68, 11);
  tft.setTextFont(2);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  char scoreStr[16];
  snprintf(scoreStr, sizeof(scoreStr), "%d M", score);
  tft.drawString(scoreStr, 68, 21);

  // Right: Best Record
  tft.setTextFont(1);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("RECORD", 218, 11);
  tft.setTextFont(2);
  tft.setTextColor(RUN_AMBER, RUN_CARD);
  char bestStr[16];
  snprintf(bestStr, sizeof(bestStr), "%d M", currentGame.highScores[0]);
  tft.drawString(bestStr, 218, 21);
}

static void updateRunnerScoreHUD() {
  tft.fillRect(68, 21, 65, 18, RUN_CARD);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  char scoreStr[16];
  snprintf(scoreStr, sizeof(scoreStr), "%d M", score);
  tft.drawString(scoreStr, 68, 21);
}

static void drawRunnerBottomBar() {
  // Bottom dynamic pill bar: x=8, y=295, w=224, h=21
  tft.fillRoundRect(8, 295, 224, 21, 6, RUN_CARD);
  tft.setTextFont(1);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("UP / SHOOT: JUMP  |  DOWN: DUCK", 120, 305);
}

// -----------------------------------------------------------------
// RUNNER SPRITE & OBSTACLE RENDERING
// -----------------------------------------------------------------
static void drawRunner(int px, int py, int anim, bool inAir) {
  // Readable pixel athlete: hair, face, jacket, animated limbs and bright shoes.
  constexpr uint16_t SKIN = 0xFD0F;
  constexpr uint16_t HAIR = 0x4008;
  constexpr uint16_t JACKET = 0x07FF;
  constexpr uint16_t PANTS = 0x03A6;
  constexpr uint16_t SHOE = 0xFFFF;
  tft.fillCircle(px + 11, py + 4, 4, SKIN);
  tft.fillRoundRect(px + 7, py, 8, 3, 2, HAIR);
  tft.drawPixel(px + 14, py + 4, 0x0000);
  tft.fillRoundRect(px + 6, py + 8, 10, 10, 2, JACKET);
  tft.fillRect(px + 8, py + 10, 2, 6, 0x07FF);
  tft.drawFastHLine(px + 6, py + 17, 10, RUN_AMBER);

  if (inAir) {
    tft.drawWideLine(px + 7, py + 10, px + 2, py + 6, 3, SKIN);
    tft.drawWideLine(px + 15, py + 10, px + 19, py + 6, 3, SKIN);
  } else if (anim == 0) {
    tft.drawWideLine(px + 7, py + 10, px + 2, py + 15, 3, SKIN);
    tft.drawWideLine(px + 15, py + 10, px + 18, py + 7, 3, SKIN);
  } else {
    tft.drawWideLine(px + 7, py + 10, px + 3, py + 7, 3, SKIN);
    tft.drawWideLine(px + 15, py + 10, px + 19, py + 15, 3, SKIN);
  }

  if (inAir) {
    tft.drawWideLine(px + 9, py + 18, px + 5, py + 23, 4, PANTS);
    tft.drawWideLine(px + 14, py + 18, px + 18, py + 22, 4, PANTS);
    tft.fillRoundRect(px + 2, py + 22, 7, 3, 1, SHOE);
    tft.fillRoundRect(px + 15, py + 21, 5, 3, 1, SHOE);
  } else if (anim == 0) {
    tft.drawWideLine(px + 9, py + 18, px + 5, py + 26, 4, PANTS);
    tft.drawWideLine(px + 14, py + 18, px + 17, py + 23, 4, PANTS);
    tft.fillRoundRect(px + 1, py + 25, 8, 3, 1, SHOE);
    tft.fillRoundRect(px + 15, py + 22, 5, 3, 1, SHOE);
  } else {
    tft.drawWideLine(px + 9, py + 18, px + 5, py + 23, 4, PANTS);
    tft.drawWideLine(px + 14, py + 18, px + 17, py + 26, 4, PANTS);
    tft.fillRoundRect(px + 2, py + 22, 6, 3, 1, SHOE);
    tft.fillRoundRect(px + 15, py + 25, 5, 3, 1, SHOE);
  }
}

static void eraseRunner(int px, int py) {
  restoreRunnerBackdropRect(px - 2, py - 2, RUNNER_W + 5, RUNNER_H + 5);
}

static void spawnRunObstacle() {
  for (int i = 0; i < MAX_RUN_OBS; i++) {
    if (!obs[i].active) {
      obs[i].x = RUN_W + 10;
      int obsType = random(0, 3);
      if (obsType == 0) {
        // Low barrier / energy pylon (jumpable)
        obs[i].w = 12;
        obs[i].h = 18;
        obs[i].color = RUN_RED;
      } else if (obsType == 1) {
        // Tall drone pylon
        obs[i].w = 14;
        obs[i].h = 28;
        obs[i].color = 0xFD20; // Neon Orange
      } else {
        // Double barrier
        obs[i].w = 22;
        obs[i].h = 16;
        obs[i].color = RUN_AMBER;
      }
      obs[i].active = true;
      lastObsSpawn = millis();
      break;
    }
  }
}

static void updateAndDrawObstacles() {
  for (int i = 0; i < MAX_RUN_OBS; i++) {
    if (obs[i].active) {
      int prevX = (int)obs[i].x;
      int oy = RUN_GROUND_Y - obs[i].h;

      // Erase trailing edge
      restoreRunnerBackdropRect(prevX + obs[i].w - (int)gameSpeed, oy,
                                (int)gameSpeed + 2, obs[i].h);

      obs[i].x -= gameSpeed;

      // If obstacle completely passed screen
      if (obs[i].x + obs[i].w < 0) {
        restoreRunnerBackdropRect(0, oy, obs[i].w + 2, obs[i].h);
        obs[i].active = false;
        continue;
      }

      // Draw obstacle with tech hazard glow
      int curX = (int)obs[i].x;
      if (curX < RUN_W) {
        tft.fillRoundRect(curX, oy, obs[i].w, obs[i].h, 3, obs[i].color);
        tft.drawFastHLine(curX + 2, oy + 2, obs[i].w - 4, 0xFFFF);
      }

      // Collision Check with Runner (AABB with 2px forgiveness)
      int rx = RUNNER_X + 2;
      int ry = (int)runnerY + 2;
      int rw = RUNNER_W - 4;
      int rh = RUNNER_H - 4;

      if (curX < rx + rw && curX + obs[i].w > rx &&
          oy < ry + rh && oy + obs[i].h > ry) {
        soundCrash();
        gameState = 2; // Game Over
        menu_drawn = false;
        return;
      }
    }
  }
}

// -----------------------------------------------------------------
// GAME INITIALIZATION
// -----------------------------------------------------------------
static void initRunnerGame() {
  score = 0;
  gameSpeed = 4.2f;
  runnerY = RUN_GROUND_Y - RUNNER_H;
  prevRunnerY = runnerY;
  runnerVY = 0;
  isJumping = false;
  legAnimFrame = 0;
  runLastAnimTime = millis();
  lastObsSpawn = millis();

  for (int i = 0; i < MAX_RUN_OBS; i++) {
    obs[i].active = false;
  }

  tft.fillScreen(RUN_BG);
  drawRunnerBackdrop();
  tft.drawFastHLine(0, RUN_PLAYFIELD_TOP - 1, RUN_W, RUN_SURFACE);
  drawRunnerHeader();
  drawGroundFloor();
  drawRunnerBottomBar();
  initSpeedLines();

  drawRunner(RUNNER_X, (int)runnerY, legAnimFrame, isJumping);
}

// -----------------------------------------------------------------
// MODAL SCREENS (START / PAUSE / GAME OVER)
// -----------------------------------------------------------------
static void showRunnerStartScreen() {
  gameState = -1;
  tft.setRotation(2);
  tft.fillScreen(RUN_BG);
  drawRunnerBackdrop();

  // Main Card
  tft.fillRoundRect(16, 50, 208, 250, 12, RUN_CARD);
  tft.drawRoundRect(16, 50, 208, 250, 12, RUN_SURFACE);

  // Pill Header
  tft.fillRoundRect(28, 66, 60, 24, 6, RUN_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(RUN_AMBER, RUN_SURFACE);
  tft.drawString("ARCADE", 58, 78);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  tft.drawString("CYBER", 28, 98);
  tft.drawString("RUNNER", 28, 124);

  // Instructions
  tft.setTextFont(1);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("CONTROLS", 28, 160);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  tft.drawString("UP / SHOOT: Jump obstacles", 28, 176);
  tft.drawString("Distance = Score", 28, 192);

  // Best Record Banner
  tft.fillRoundRect(28, 218, 184, 28, 6, RUN_SURFACE);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(RUN_AMBER, RUN_SURFACE);
  tft.drawString("BEST: " + String(currentGame.highScores[0]) + " METERS", 38, 232);

  // Start Prompt
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(RUN_GREEN, RUN_CARD);
  tft.drawString("PRESS SHOOT TO START", 120, 275);
}

static void drawRunnerPauseOption(int item) {
  const char* labels[] = { "RESUME", "RESTART", "MAIN MENU" };
  int y = 140 + item * 34;
  bool selected = (item == runPauseSelection);
  uint16_t fill = UI_ICON_BG;

  tft.fillRoundRect(36, y, 168, 28, 6, fill);
  if (selected) {
    tft.drawRoundRect(36, y, 168, 28, 6, UI_PURPLE);
    tft.drawRoundRect(37, y + 1, 166, 26, 5, UI_PURPLE);
    tft.drawRoundRect(38, y + 2, 164, 24, 4, UI_CYAN);
  }

  tft.setTextDatum(ML_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(selected ? RUN_WHITE : RUN_MUTED, fill);
  tft.drawString(labels[item], 48, y + 14);

  if (selected) {
    tft.setTextDatum(MR_DATUM);
    tft.drawString(">", 192, y + 14);
  }
}

static void drawRunnerPauseMenu() {
  tft.fillRoundRect(24, 75, 192, 175, 12, RUN_CARD);
  tft.drawRoundRect(24, 75, 192, 175, 12, RUN_SURFACE);

  tft.fillRect(38, 91, 24, 3, RUN_AMBER);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(4);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  tft.drawString("PAUSED", 38, 99);

  for (int i = 0; i < 3; i++) {
    drawRunnerPauseOption(i);
  }
}

static void handleRunnerPause() {
  if (!runPauseReady) {
    if (digitalRead(SHOOT) == LOW) runPauseReady = true;
    return;
  }

  int cmd = findCommand();
  if (cmd == 0 || cmd == 2) { // UP / DOWN
    int old = runPauseSelection;
    runPauseSelection = (runPauseSelection + (cmd == 0 ? 2 : 1)) % 3;
    drawRunnerPauseOption(old);
    drawRunnerPauseOption(runPauseSelection);
    playNavClick();
  } else if (cmd == 4) { // SHOOT: Select
    playSelectTone();
    if (runPauseSelection == 0) { // Resume
      tft.fillScreen(RUN_BG);
      drawRunnerBackdrop();
      tft.drawFastHLine(0, RUN_PLAYFIELD_TOP - 1, RUN_W, RUN_SURFACE);
      drawRunnerHeader();
      drawGroundFloor();
      drawRunnerBottomBar();
      drawRunner(RUNNER_X, (int)runnerY, legAnimFrame, isJumping);
      gameState = 0;
      menu_drawn = false;
      runShootReady = false;
    } else if (runPauseSelection == 1) { // Restart
      initRunnerGame();
      gameState = 0;
      menu_drawn = false;
    } else { // Exit
      switchGame(0);
    }
  }
}

static void drawRunnerGameOver() {
  currentGame.recordScore(score);

  tft.fillRoundRect(24, 65, 192, 190, 12, RUN_CARD);
  tft.drawRoundRect(24, 65, 192, 190, 12, RUN_SURFACE);

  tft.fillRect(38, 81, 24, 3, RUN_RED);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("RUNNER / CRASHED", 38, 93);

  tft.setTextFont(4);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  tft.drawString("GAME OVER", 38, 107);

  // Score stats
  tft.setTextFont(1);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("DISTANCE", 38, 145);
  tft.drawString("RECORD", 136, 145);

  tft.setTextFont(2);
  tft.setTextColor(RUN_WHITE, RUN_CARD);
  tft.drawString(String(score) + " M", 38, 158);
  tft.setTextColor(RUN_AMBER, RUN_CARD);
  tft.drawString(String(currentGame.highScores[0]) + " M", 136, 158);

  tft.drawFastHLine(38, 186, 164, RUN_SURFACE);
  tft.setTextFont(1);
  tft.setTextColor(RUN_GREEN, RUN_CARD);
  tft.drawString("SHOOT  RUN AGAIN", 38, 198);
  tft.setTextColor(RUN_MUTED, RUN_CARD);
  tft.drawString("UP  MAIN MENU", 38, 218);
}

static void handleRunnerGameOver() {
  int cmd = findCommand();
  if (cmd == 4) {
    playSelectTone();
    initRunnerGame();
    gameState = 0;
    menu_drawn = false;
  } else if (cmd == 0) {
    playSelectTone();
    switchGame(0);
  }
}

// -----------------------------------------------------------------
// LIFECYCLE (runSetup & runLoop)
// -----------------------------------------------------------------
void runSetup() {
  tft.setRotation(2); // Native vertical / portrait orientation
  showRunnerStartScreen();
}

void runLoop() {
  if (gameState == 0) {
    if (digitalRead(SHOOT) == LOW) runShootReady = true;

    // Check Jump input (UP button = 0, or SHOOT button = 4)
    int cmd = findCommand();
    if ((cmd == 0 || (cmd == 4 && runShootReady)) && !isJumping) {
      runnerVY = JUMP_VELOCITY;
      isJumping = true;
      runShootReady = false;
      soundJump();
    }

    // Physics
    eraseRunner(RUNNER_X, (int)prevRunnerY);
    runnerVY += GRAVITY;
    runnerY += runnerVY;

    // Floor landing
    if (runnerY >= RUN_GROUND_Y - RUNNER_H) {
      runnerY = RUN_GROUND_Y - RUNNER_H;
      runnerVY = 0;
      isJumping = false;
    }

    // Animation & Distance score progression
    if (millis() - runLastAnimTime > 120) {
      legAnimFrame = !legAnimFrame;
      runLastAnimTime = millis();
      score++; // Increment distance
      updateRunnerScoreHUD();

      // Progressive speed increase
      if (score % 50 == 0 && gameSpeed < 7.5f) {
        gameSpeed += 0.25f;
        soundMilestone();
      }
    }

    // Update background lines & obstacles
    updateSpeedLines();

    // Spawn obstacles at dynamic distance
    if (millis() - lastObsSpawn > (unsigned long)(random(1100, 2200) * (4.2f / gameSpeed))) {
      spawnRunObstacle();
    }
    updateAndDrawObstacles();

    // Redraw runner at current position
    drawRunner(RUNNER_X, (int)runnerY, legAnimFrame, isJumping);
    prevRunnerY = runnerY;

    delay(14); // ~60 FPS smooth motion
    return;
  } else if (gameState == 1) { // Pause
    if (!menu_drawn) {
      drawRunnerPauseMenu();
      menu_drawn = true;
    }
    handleRunnerPause();
  } else if (gameState == 2) { // Game Over
    if (!menu_drawn) {
      drawRunnerGameOver();
      menu_drawn = true;
    }
    handleRunnerGameOver();
  } else if (gameState == -1) { // Title Screen
    int cmd = findCommand();
    if (cmd == 4) {
      playSelectTone();
      initRunnerGame();
      gameState = 0;
    }
  }
}
