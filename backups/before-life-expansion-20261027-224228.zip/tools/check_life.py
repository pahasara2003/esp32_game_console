"""Run the actual Life model and controller with simulated input and display.

Run: python tools/check_life.py (requires g++).
"""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src" / "life.cpp").read_text()
source = "\n".join(line for line in source.splitlines() if not line.startswith("#include"))
prefix = r'''
#include "life_model.h"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <deque>
#include <iostream>
#include <random>
#include <string>
#include <vector>
struct String : std::string {
  using std::string::string;
  String(int n) : std::string(std::to_string(n)) {}
  String(const std::string &s) : std::string(s) {}
};
template<class T> T constrain(T v, T lo, T hi) { return std::min(hi, std::max(lo, v)); }
constexpr uint16_t UI_BG=0, UI_PANEL=0x1082, UI_SURFACE=0x2104,
  UI_CYAN=0x2EDC, UI_TEXT=0xEF7D, UI_MUTED=0x8C51, UI_ICON_BG=0x18C3,
  TFT_MAGENTA=0xF81F;
constexpr int TL_DATUM=0, TR_DATUM=1, MC_DATUM=2, SHOOT=5;
unsigned long clockMs=100;
bool button=false;
int command=-1, switched=-1;
unsigned long millis() { return clockMs; }
int digitalRead(int) { return button; }
int findCommand() { int c=command; command=-1; return c; }
void switchGame(int i) { switched=i; }
void playNavClick() {}
void playSelectTone() {}
std::mt19937 rng(1729);
long random(long bound) { return std::uniform_int_distribution<long>(0,bound-1)(rng); }
struct {
  std::deque<char> chars;
  int available() { return chars.size(); }
  char read() { char c=chars.front(); chars.pop_front(); return c; }
} Serial;
struct {
  int clears=0, cells=0, pixels=0;
  int datum=TL_DATUM, font=1;
  void reset() { clears=cells=pixels=0; }
  void bounds(int x,int y,int w,int h) { assert(x>=0&&y>=0&&w>0&&h>0&&x+w<=240&&y+h<=320); }
  void fillScreen(uint16_t) { ++clears; }
  void fillRect(int x,int y,int w,int h,uint16_t) { bounds(x,y,w,h); pixels+=w*h; }
  void fillRoundRect(int x,int y,int w,int h,int r,uint16_t) {
    bounds(x,y,w,h); assert(r>=0&&r*2<=w&&r*2<=h);
    if(w==6&&h==6) ++cells;
  }
  void drawRoundRect(int x,int y,int w,int h,int r,uint16_t) { bounds(x,y,w,h); assert(r>=0); }
  void drawRect(int x,int y,int w,int h,uint16_t) { bounds(x,y,w,h); }
  void setTextDatum(int value) { datum=value; }
  void setTextFont(int value) { font=value; }
  template<class... T> void setTextColor(T...) {}
  void drawString(const std::string &text,int x,int y) {
    // Actual TFT_eSPI Font 2 advances for ASCII 32..95; Font 1 is 6x8.
    static const int widths[] = {
      6,3,4,9,8,9,9,3,7,7,8,6,3,6,5,7,
      8,8,8,8,8,8,8,8,8,8,3,3,6,6,6,8,
      9,8,8,8,8,8,8,8,8,4,8,8,7,10,8,8,
      8,8,8,8,8,8,8,10,8,8,8,4,7,4,7,9
    };
    int w=0,h=font==2?16:8;
    for(unsigned char c:text) {
      if(font==2) { assert(c>=32&&c<96); w+=widths[c-32]; }
      else w+=6;
    }
    if(datum==TR_DATUM) x-=w;
    if(datum==MC_DATUM) { x-=w/2; y-=h/2; }
    bounds(x,y,w,h);
  }
  void startWrite() {}
  void endWrite() {}
  void setRotation(int) {}
} tft;
'''
suffix = r'''
static void key(char c) { Serial.chars.push_back(c); lifeLoop(); }
static void tick(unsigned long delta) { clockMs+=delta; lifeLoop(); }
static void fresh() { button=false; Serial.chars.clear(); command=-1; clockMs=100; lifeSetup(); }
int main() {
  using lifeModel::Board;
  constexpr int W=lifeModel::WIDTH,H=lifeModel::HEIGHT,N=lifeModel::COUNT;
  Board b;
  b.set(2,2,true); b.set(3,2,true); b.set(2,3,true); b.set(3,3,true);
  assert(!b.step()&&b.population==4&&b.generation==1);
  b.clear(); for(int x=5;x<=7;++x) b.set(x,5,true);
  b.step(); assert(b.cells[4*W+6]&&b.cells[5*W+6]&&b.cells[6*W+6]&&b.population==3);
  b.step(); for(int x=5;x<=7;++x) assert(b.cells[5*W+x]);
  b.clear(); b.set(-1,0,true); b.set(W,0,true); b.set(0,H,true); assert(b.population==0);
  b.set(0,0,true); b.set(0,0,true); assert(b.population==1);
  b.set(0,0,false); b.set(0,0,false); assert(b.population==0);
  // The reference sums contributions from live cells, independently of the model's per-cell neighbor scan.
  for(int sample=0;sample<200;++sample) {
    b.clear(); for(int i=0;i<N;++i) if(rng()%3==0) b.set(i%W,i/W,true);
    for(int generation=0;generation<12;++generation) {
      int counts[N]={}; uint8_t expected[N]={}; int population=0;
      for(int i=0;i<N;++i) if(b.cells[i])
        for(int dy=-1;dy<=1;++dy) for(int dx=-1;dx<=1;++dx) {
          if(!dx&&!dy) continue;
          ++counts[((i/W+dy+H)%H)*W+(i%W+dx+W)%W];
        }
      for(int i=0;i<N;++i) {
        expected[i]=counts[i]==3||(b.cells[i]&&counts[i]==2); population+=expected[i];
      }
      b.step(); assert(b.population==population);
      for(int i=0;i<N;++i) assert(b.cells[i]==expected[i]);
    }
  }
  std::cout<<"PASS: 2400 randomized generation comparisons, B3/S23, population invariants, block, blinker and bounds\n";
  fresh(); key('e'); assert(lifeApp::mode==lifeApp::RUNNING&&lifeApp::board.population==5);
  uint8_t expected[N]={};
  for(int i=0;i<N;++i) if(lifeApp::board.cells[i]) expected[((i/W+1)%H)*W+(i%W+1)%W]=1;
  for(int i=0;i<4;++i) lifeApp::board.step();
  for(int i=0;i<N;++i) assert(lifeApp::board.cells[i]==expected[i]);
  // Repeat the glider test at the bottom-right edge to verify wrapping.
  b.clear();
  for(int i=0;i<N;++i) if(expected[i]) b.set((i%W+W/2-1)%W,(i/W+H/2-1)%H,true);
  uint8_t wrapped[N]={};
  for(int i=0;i<N;++i) if(b.cells[i]) wrapped[((i/W+1)%H)*W+(i%W+1)%W]=1;
  for(int i=0;i<4;++i) b.step();
  for(int i=0;i<N;++i) assert(b.cells[i]==wrapped[i]);
  lifeApp::pattern=2; lifeApp::loadPattern(); assert(lifeApp::board.population==48);
  uint8_t pulsar[N]; memcpy(pulsar,lifeApp::board.cells,N);
  for(int i=0;i<3;++i) lifeApp::board.step();
  assert(memcmp(pulsar,lifeApp::board.cells,N)==0);
  std::cout<<"PASS: glider translation, toroidal edge crossing and period-three pulsar\n";
  fresh(); key('e'); tft.reset(); lifeLoop(); assert(tft.clears==0&&tft.cells==0);
  tick(251); assert(lifeApp::board.generation==1&&tft.cells==4&&tft.clears==0);
  key('e'); assert(lifeApp::mode==lifeApp::EDITING);
  uint32_t gen=lifeApp::board.generation; tick(1000); assert(lifeApp::board.generation==gen);
  tft.reset(); key('d'); assert(tft.cells==2&&tft.clears==0);
  int before=lifeApp::board.population, index=lifeApp::cursor;
  bool wasAlive=lifeApp::board.cells[index]; tft.reset(); key('e');
  assert(tft.cells==1&&lifeApp::board.population==before+(wasAlive?-1:1));
  key('q'); assert(lifeApp::mode==lifeApp::OPTIONS);
  key('s'); key('e'); assert(lifeApp::mode==lifeApp::EDITING&&lifeApp::board.generation==gen+1);
  key('q'); key('e'); assert(lifeApp::mode==lifeApp::RUNNING);
  for(int i=0;i<12;++i) key('w'); assert(lifeApp::speed==4);
  for(int i=0;i<12;++i) key('s'); assert(lifeApp::speed==0);
  lifeApp::pattern=0; key('a'); assert(lifeApp::pattern==5&&lifeApp::board.population==0);
  key('d'); assert(lifeApp::pattern==0&&lifeApp::board.population==5);
  key('q'); for(int i=0;i<4;++i) key('s'); key('e');
  assert(lifeApp::mode==lifeApp::EDITING&&lifeApp::board.population==0);
  key('q'); for(int i=0;i<5;++i) key('s'); key('e'); assert(switched==0);
  std::cout<<"PASS: run/pause, edit, single step, speed limits, presets, clear and exit; no full-screen frame redraws\n";
  fresh(); button=true; lifeLoop(); tick(40); button=false; lifeLoop(); assert(lifeApp::mode==lifeApp::RUNNING);
  button=true; lifeLoop(); tick(900); assert(lifeApp::mode==lifeApp::OPTIONS);
  button=false; lifeLoop(); assert(lifeApp::mode==lifeApp::OPTIONS);
  button=true; lifeLoop(); tick(40); button=false; lifeLoop(); assert(lifeApp::mode==lifeApp::RUNNING);
  std::cout<<"PASS: physical tap/hold input sequence and release suppression; all shapes stay inside 240x320\n";
}
'''
with tempfile.TemporaryDirectory(prefix="life-check-") as tmp:
    path = Path(tmp)
    (path / "check.cpp").write_text(prefix + source + suffix)
    subprocess.run(["g++", "-std=c++11", "-O2", "-D_GLIBCXX_ASSERTIONS", "-I", str(ROOT / "src"),
                    str(path / "check.cpp"), "-o", str(path / "check")], check=True)
    subprocess.run([str(path / "check")], check=True)
