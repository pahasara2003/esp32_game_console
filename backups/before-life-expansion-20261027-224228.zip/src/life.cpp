#include <Arduino.h>
#include "game.h"
#include "life_model.h"

namespace lifeApp {
enum Mode { INTRO, RUNNING, EDITING, OPTIONS };
static Mode mode = INTRO;
static lifeModel::Board board;
static uint8_t drawn[lifeModel::COUNT];
static constexpr int CELL = 8;
static constexpr int LEFT = 8;
static constexpr int TOP = 64;
static constexpr uint16_t FIELD = 0x0803;
static constexpr uint16_t DEAD = 0x2109;
static constexpr uint16_t LIVE = 0xBFE0;
static constexpr int PERIODS[] = {1000, 500, 250, 125, 83};
static constexpr int RATES[] = {1, 2, 4, 8, 12};
static const char *PATTERNS[] = {"GLIDER", "BLINKERS", "PULSAR", "R-PENTOMINO", "RANDOM", "EMPTY"};
static constexpr int PATTERN_COUNT = sizeof(PATTERNS) / sizeof(PATTERNS[0]);
static int pattern = 0, speed = 2, cursor = 12 * lifeModel::WIDTH + 14;
static int option = 0;
static unsigned long lastStep = 0, pressedAt = 0;
static bool shootHeld = false, holdSent = false;

static_assert(LEFT * 2 + lifeModel::WIDTH * CELL == 240, "Life board must be centered");
static_assert(TOP + lifeModel::HEIGHT * CELL < 264, "Life board must clear footer");

static void resetInput() { shootHeld = holdSent = false; }

static int input() {
  int cmd = findCommand();
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'w' || c == 'W') return 0;
    if (c == 'd' || c == 'D') return 1;
    if (c == 's' || c == 'S') return 2;
    if (c == 'a' || c == 'A') return 3;
    if (c == ' ' || c == 'e' || c == 'E') return 4;
    if (c == 'q' || c == 'Q') return 5;
  }
  if (digitalRead(SHOOT)) {
    if (!shootHeld) { shootHeld = true; holdSent = false; pressedAt = millis(); }
    if (!holdSent && millis() - pressedAt >= 850) {
      holdSent = true;
      return 5;
    }
    return -1;
  }
  if (shootHeld) {
    bool tapped = !holdSent && millis() - pressedAt >= 35;
    resetInput();
    if (tapped) return 4;
  }
  return cmd == 4 ? -1 : cmd;
}

static void drawState() {
  tft.fillRect(168, 16, 54, 10, UI_PANEL);
  tft.setTextDatum(TR_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(mode == RUNNING ? LIVE : UI_CYAN, UI_PANEL);
  tft.drawString(mode == RUNNING ? "RUNNING" : mode == OPTIONS ? "OPTIONS" :
                 mode == INTRO ? "B3/S23" : "EDIT", 222, 17);
}

static void drawStats() {
  char text[24];
  tft.fillRect(18, 35, 204, 12, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  snprintf(text, sizeof(text), "GEN %lu", (unsigned long)board.generation);
  tft.drawString(text, 18, 37);
  snprintf(text, sizeof(text), "ALIVE %u", board.population);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(LIVE, UI_PANEL);
  tft.drawString(text, 222, 37);
}

static void drawHeader() {
  tft.fillRoundRect(8, 8, 224, 46, 9, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("CONWAY'S LIFE", 18, 13);
  drawState();
  drawStats();
}

static void drawFooter() {
  tft.fillRoundRect(8, 264, 224, 48, 8, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(LIVE, UI_PANEL);
  tft.drawString(mode == OPTIONS ? "OPTIONS" : mode == EDITING ? "EDIT CELLS" : PATTERNS[pattern], 16, 272);
  tft.setTextDatum(TR_DATUM);
  tft.drawString(String(RATES[speed]) + " GEN/S", 224, 272);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(mode == OPTIONS ? "UP/DOWN CHOOSE  SHOOT SELECT" :
                 mode == RUNNING ? "SHOOT PAUSE  UP/DN SPEED" : "D-PAD MOVE  SHOOT TOGGLE", 120, 290);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString(mode == OPTIONS ? "HOLD SHOOT BACK TO EDIT" :
                 mode == RUNNING ? "L/R PATTERN  HOLD OPTIONS" : "HOLD SHOOT FOR RUN / STEP / EXIT", 120, 304);
}

static void drawCell(int index) {
  int x = LEFT + (index % lifeModel::WIDTH) * CELL;
  int y = TOP + (index / lifeModel::WIDTH) * CELL;
  tft.fillRect(x, y, CELL, CELL, FIELD);
  tft.fillRoundRect(x + 1, y + 1, CELL - 2, CELL - 2, 1,
                    board.cells[index] ? LIVE : DEAD);
  if (mode == EDITING && index == cursor) tft.drawRect(x, y, CELL, CELL, TFT_MAGENTA);
  drawn[index] = board.cells[index];
}

static void drawBoard(bool force = false) {
  tft.startWrite();
  for (int i = 0; i < lifeModel::COUNT; ++i)
    if (force || drawn[i] != board.cells[i]) drawCell(i);
  tft.endWrite();
}

static void loadPattern() {
  board.clear();
  const int cx = lifeModel::WIDTH / 2, cy = lifeModel::HEIGHT / 2;
  if (pattern == 0) {
    const int points[][2] = {{0,-1},{1,0},{-1,1},{0,1},{1,1}};
    for (const auto &p : points) board.set(cx + p[0], cy + p[1], true);
  } else if (pattern == 1) {
    for (int y : {6, 12, 18})
      for (int x : {7, 14, 21})
        for (int dx = -1; dx <= 1; ++dx) board.set(x + dx, y, true);
  } else if (pattern == 2) {
    const int bars[] = {2, 3, 4, 8, 9, 10};
    const int lines[] = {0, 5, 7, 12};
    for (int a : bars) for (int b : lines) {
      board.set(cx - 6 + a, cy - 6 + b, true);
      board.set(cx - 6 + b, cy - 6 + a, true);
    }
  } else if (pattern == 3) {
    const int points[][2] = {{0,-1},{1,-1},{-1,0},{0,0},{0,1}};
    for (const auto &p : points) board.set(cx + p[0], cy + p[1], true);
  } else if (pattern == 4) {
    for (int i = 0; i < lifeModel::COUNT; ++i)
      if (random(100) < 28) board.set(i % lifeModel::WIDTH, i / lifeModel::WIDTH, true);
  }
  cursor = cy * lifeModel::WIDTH + cx;
  lastStep = millis();
}

static void changePattern(int delta) {
  pattern = (pattern + delta + PATTERN_COUNT) % PATTERN_COUNT;
  loadPattern();
  drawBoard();
  if (mode == EDITING) drawCell(cursor);
  drawStats();
  drawFooter();
}

static void drawOption(int i) {
  const char *labels[] = {"RUN / RESUME", "STEP ONCE", "NEXT PATTERN", "SPEED", "CLEAR / EDIT", "MAIN MENU"};
  int y = 106 + i * 23;
  tft.fillRoundRect(28, y, 184, 21, 4, UI_ICON_BG);
  if (i == option) {
    tft.drawRoundRect(28, y, 184, 21, 4, TFT_MAGENTA);
    tft.drawRoundRect(29, y + 1, 182, 19, 3, TFT_MAGENTA);
  }
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(i == option ? UI_TEXT : UI_MUTED, UI_ICON_BG);
  String label = i == 3 ? String("SPEED  ") + String(RATES[speed]) + " GEN/S" : String(labels[i]);
  tft.drawString(label, 120, y + 10);
}

static void drawOptions() {
  tft.fillRoundRect(18, 73, 204, 180, 10, UI_PANEL);
  tft.drawRoundRect(18, 73, 204, 180, 10, UI_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("LIFE CONTROLS", 120, 89);
  for (int i = 0; i < 6; ++i) drawOption(i);
}

static void leaveOptions(Mode next) {
  mode = next;
  lastStep = millis();
  drawBoard(true); // Restore the cells covered by the one-time menu overlay.
  drawState();
  drawStats();
  drawFooter();
}

static void drawIntro() {
  tft.fillScreen(UI_BG);
  drawHeader();
  const int glider[][2] = {{1,0},{2,1},{0,2},{1,2},{2,2}};
  for (int y = 0; y < 5; ++y) for (int x = 0; x < 5; ++x) {
    bool alive = false;
    for (const auto &p : glider) if (x == p[0] + 1 && y == p[1] + 1) alive = true;
    tft.fillRoundRect(78 + x * 17, 69 + y * 17, 14, 14, 3, alive ? LIVE : DEAD);
  }
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, UI_BG);
  tft.drawString("3 neighbors: a cell is born", 120, 174);
  tft.drawString("2 or 3: a live cell survives", 120, 190);
  tft.setTextColor(UI_MUTED, UI_BG);
  tft.drawString("Edges wrap around the board", 120, 210);
  tft.drawString("Pause to draw your own cells", 120, 228);
  tft.fillRoundRect(8, 264, 224, 48, 8, UI_PANEL);
  tft.setTextColor(LIVE, UI_PANEL);
  tft.drawString("SHOOT  START SIMULATION", 120, 280);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  tft.drawString("UP  MAIN MENU", 120, 300);
}
} // namespace lifeApp

void lifeSetup() {
  tft.setRotation(2);
  lifeApp::mode = lifeApp::INTRO;
  lifeApp::resetInput();
  lifeApp::pattern = 0;
  lifeApp::speed = 2;
  lifeApp::board.clear();
  lifeApp::drawIntro();
}

void lifeLoop() {
  using namespace lifeApp;
  int cmd = input();
  if (mode == INTRO) {
    if (cmd == 0) { switchGame(0); return; }
    if (cmd == 4) {
      mode = RUNNING;
      loadPattern();
      tft.fillScreen(UI_BG);
      drawHeader(); drawBoard(true); drawFooter();
      playSelectTone();
    }
    return;
  }
  if (mode == OPTIONS) {
    if (cmd == 0 || cmd == 2) {
      int previous = option;
      option = (option + (cmd == 2 ? 1 : 5)) % 6;
      drawOption(previous); drawOption(option); playNavClick();
    } else if (cmd == 5) leaveOptions(EDITING);
    else if (cmd == 4) {
      playSelectTone();
      if (option == 5) { switchGame(0); return; }
      if (option == 0) leaveOptions(RUNNING);
      else if (option == 1) { board.step(); leaveOptions(EDITING); }
      else if (option == 2) { pattern = (pattern + 1) % PATTERN_COUNT; loadPattern(); leaveOptions(EDITING); }
      else if (option == 3) { speed = (speed + 1) % 5; drawOption(option); drawFooter(); }
      else if (option == 4) { pattern = PATTERN_COUNT - 1; loadPattern(); leaveOptions(EDITING); }
    }
    return;
  }
  if (cmd == 5) {
    mode = OPTIONS; option = 0; drawState(); drawOptions(); drawFooter();
    return;
  }
  if (mode == RUNNING) {
    if (cmd == 4) {
      mode = EDITING;
      drawCell(cursor); drawState(); drawFooter();
      return;
    }
    if (cmd == 1 || cmd == 3) changePattern(cmd == 1 ? 1 : -1);
    if (cmd == 0 || cmd == 2) {
      speed = constrain(speed + (cmd == 0 ? 1 : -1), 0, 4);
      drawFooter();
      lastStep = millis();
    }
    if (millis() - lastStep >= (unsigned long)PERIODS[speed]) {
      board.step(); drawBoard(); drawStats(); lastStep = millis();
    }
  } else if (mode == EDITING) {
    if (cmd == 4) {
      board.set(cursor % lifeModel::WIDTH, cursor / lifeModel::WIDTH, !board.cells[cursor]);
      drawCell(cursor); drawStats(); playNavClick();
    } else if (cmd >= 0 && cmd <= 3) {
      int x = cursor % lifeModel::WIDTH, y = cursor / lifeModel::WIDTH;
      if (cmd == 0 && y > 0) --y;
      if (cmd == 2 && y < lifeModel::HEIGHT - 1) ++y;
      if (cmd == 3 && x > 0) --x;
      if (cmd == 1 && x < lifeModel::WIDTH - 1) ++x;
      int old = cursor;
      cursor = y * lifeModel::WIDTH + x;
      if (cursor != old) { drawCell(old); drawCell(cursor); }
    }
  }
}
