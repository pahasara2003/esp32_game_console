#pragma once

#include <stdint.h>
#include <string.h>

namespace lifeModel {
constexpr int WIDTH = 28;
constexpr int HEIGHT = 24;
constexpr int COUNT = WIDTH * HEIGHT;

// Conway B3/S23, with a toroidal board: cells across each edge are neighbors.
struct Board {
  uint8_t cells[COUNT] = {};
  uint8_t next[COUNT] = {};
  uint32_t generation = 0;
  uint16_t population = 0;

  void clear() {
    memset(cells, 0, sizeof(cells));
    memset(next, 0, sizeof(next));
    generation = 0;
    population = 0;
  }

  void set(int x, int y, bool alive) {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) return;
    int index = y * WIDTH + x;
    if (cells[index] == alive) return;
    if (alive) ++population;
    else --population;
    cells[index] = alive;
  }

  bool step() {
    bool changed = false;
    uint16_t total = 0;
    for (int y = 0; y < HEIGHT; ++y) {
      for (int x = 0; x < WIDTH; ++x) {
        int neighbors = 0;
        for (int dy = -1; dy <= 1; ++dy) {
          for (int dx = -1; dx <= 1; ++dx) {
            if (!dx && !dy) continue;
            int nx = (x + dx + WIDTH) % WIDTH;
            int ny = (y + dy + HEIGHT) % HEIGHT;
            neighbors += cells[ny * WIDTH + nx];
          }
        }
        int i = y * WIDTH + x;
        next[i] = neighbors == 3 || (cells[i] && neighbors == 2);
        total += next[i];
        changed |= next[i] != cells[i];
      }
    }
    memcpy(cells, next, sizeof(cells));
    population = total;
    ++generation;
    return changed;
  }
};
} // namespace lifeModel
