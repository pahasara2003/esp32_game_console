# ESP32-C3 Retro Game Console (PlatformIO & TFT_eSPI)

A retro game console project running on the **ESP32-C3** with an **ILI9341 SPI TFT Display (320x240)** and **ADS1115 I2C ADC** for analog gamepad/button controls.

---

## 🎮 Included Games & Menus

- **Main Menu:** Icon grid launcher with animated selection glow.
- **Snake:** Nokia-style retro snake with particle effects and stars.
- **Breakout:** Brick-breaker game with bat and bouncing ball physics.
- **Tetris:** Classic block puzzle with rotation, line clearing, and pause menu.
- **Tic-tac-toe:** Play X against the console's O opponent. Move with the D-pad, tap Shoot to place, and hold Shoot to pause.
- **Pong:** Move the paddle with Left and Right, keep the ball in play, and survive three misses. Shoot pauses.
- **Minesweeper:** Clear an 8×8 board with ten mines. White raised tiles, colored numbers, red flags, and a magenta selection outline follow the supplied icon's style. Tap Shoot to reveal, hold Shoot to flag, and press Up while holding Shoot to pause. The first reveal is safe. A small dot marks a revealed tile with no neighboring mines.
- **Conway's Life:** A 28×24 simulation using the B3/S23 rules and wrapping edges. Includes gliders, blinkers, a pulsar, R-pentomino, random cells, and an empty board for drawing. Only changed cells redraw during simulation.
- **Menu scrolling:** The launcher scrolls vertically to show additional rows of games and apps.
- **High Score System:** High scores persisted to ESP32 Flash via `Preferences` (NVS).

---

## Conway's Life controls

| Screen | Controls |
| :--- | :--- |
| Intro | Shoot starts; Up returns to the main menu. |
| Running | Shoot pauses for editing; Left/Right changes pattern; Up/Down changes speed. |
| Editing | D-pad moves the magenta cursor; Shoot toggles the selected cell. |
| Run or edit | Hold Shoot to open options. |
| Options | Up/Down chooses; Shoot selects. Run, step once, next pattern, speed, clear, or exit. |

Speeds: 1, 2, 4, 8, or approximately 12 generations per second. A cell is born with three live neighbors; a live cell survives with two or three. Opposite edges are connected.

The supplied Tic-tac-toe, Pong, Minesweeper, and Life icons are in the launcher. Gallery and Mandelbrot artwork is converted and ready for their future apps.

---

## 🔌 Hardware Circuit & Pinout

### 1. ILI9341 Display (SPI)
Configured via [`lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h`](file:///home/pahasara/Documents/antigravity/embedded/esp32c3-ili9341/lib/TFT_eSPI/User_Setups/Setup70c_ESP32_C3_ILI9341.h):

| ILI9341 Pin | ESP32-C3 Pin | Notes |
| :--- | :--- | :--- |
| **CS** | **GPIO 3** | Chip Select |
| **DC / RS** | **GPIO 1** | Data / Command Select |
| **RST / RESET** | **GPIO 2** | Display Hardware Reset |
| **MOSI / SDI** | **GPIO 0** | SPI Data Out |
| **SCLK / CLK** | **GPIO 4** | SPI Clock |
| **MISO / SDO** | **GPIO 10** | SPI Data In |
| **VCC** | **3.3V** / **5V** | Power |
| **GND** | **GND** | Ground |
| **LED / BL** | **3.3V** *(or GPIO)* | Backlight |

### 2. Controls & Peripherals

| Peripheral | ESP32-C3 Pin | Notes |
| :--- | :--- | :--- |
| **I2C SDA** | **GPIO 8** | Connected to ADS1115 ADC (`0x48`) |
| **I2C SCL** | **GPIO 9** | Connected to ADS1115 ADC (`0x48`) |
| **Shoot Button** | **GPIO 5** | Digital Input (`INPUT_PULLDOWN`) |

---

## 📁 Project Structure

```text
esp32c3-ili9341/
├── lib/
│   └── TFT_eSPI/           # Customized TFT_eSPI with ESP32-C3 register & timing fixes
├── src/
│   ├── gameConsoleNew.ino  # Entry point (setup and loop)
│   ├── game.h / game.ino   # Core Game engine, ADC input handler, high score manager
│   ├── menu.ino            # Main menu launcher & icon renderer
│   ├── snake.ino           # Snake game
│   ├── breakout.ino        # Breakout game
│   ├── tetris.ino          # Tetris game
│   ├── mini_games.ino      # Tic-tac-toe, Pong, and Minesweeper
│   ├── life.cpp            # Life interface, presets, and controls
│   ├── life_model.h        # Conway B3/S23 simulation
│   ├── config.h            # Colors, screen dimensions, button pins
│   ├── icons.h             # 60x60 game icon bitmaps
│   ├── images.h            # UI bitmaps (pause, undo, play)
│   └── Petme8x8.h          # 8x8 bitmap font
├── platformio.ini          # PlatformIO config & library dependencies
└── README.md
```

---

## 🛠️ Build and Upload in VS Code

1. Open folder in VS Code:
   `/home/pahasara/Documents/antigravity/embedded/esp32c3-ili9341`
2. Click **Build (`✓`)** or press `Ctrl+Alt+B`.
3. Connect ESP32-C3 and click **Upload (`→`)**.
4. Open the Serial Monitor at `115200` baud.
