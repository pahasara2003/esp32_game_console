#include <Arduino.h>
#include "game.h"
#include "life_model.h"
#include "life_patterns.h"

namespace lifeApp {
enum Mode { RUNNING, PAUSED, OPTIONS };
static Mode mode = RUNNING, optionsReturn = RUNNING;
static lifeModel::Board board;
static uint8_t drawn[lifeModel::CAPACITY];
static int cellSize = 8, drawnCellSize = 0;
static constexpr int FIELD_W = 224, FIELD_H = 192;
static constexpr int LEFT = 8;
static constexpr int TOP = 64;
static constexpr uint16_t FIELD = 0x0803;
static constexpr uint16_t DEAD = 0x2109;
static constexpr uint16_t LIVE = 0xBFE0;
static constexpr int PERIODS[] = {1000, 500, 250, 125, 83, 50, 33};
static constexpr int RATES[] = {1, 2, 4, 8, 12, 20, 30};
static constexpr int SPEED_COUNT = sizeof(RATES) / sizeof(RATES[0]);
static constexpr int PATTERN_COUNT = lifePatterns::COUNT;
static int pattern = lifePatterns::RANDOM, speed = 5;
static int option = 0;
static unsigned long lastStep = 0, lastStats = 0, pressedAt = 0;
static bool shootHeld = false, holdSent = false;
static bool stable = false;
static unsigned long rateWindowAt = 0, rateWindowGeneration = 0, lastFrameMs = 0;
static float measuredRate = 0;

static_assert(LEFT * 2 + FIELD_W == 240, "Life board must be centered");
static_assert(TOP + FIELD_H < 264, "Life board must clear footer");

static void resetInput() { shootHeld = holdSent = false; }

static void resetRate() {
  rateWindowAt = millis();
  rateWindowGeneration = board.generation;
  measuredRate = 0;
}

static int input() {
  int cmd = lifeInputPoll();
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'w' || c == 'W') return 0;
    if (c == 'd' || c == 'D') return 1;
    if (c == 's' || c == 'S') return 2;
    if (c == 'a' || c == 'A') return 3;
    if (c == ' ' || c == 'e' || c == 'E') return 4;
    if (c == 'q' || c == 'Q') return 5;
    if (c == 'p' || c == 'P') {
      Serial.printf("[Life] mode=%d preset=%d %dx%d gen=%lu alive=%u target=%d/s measured=%.1f/s frame=%lums\n",
                    (int)mode, pattern, board.width, board.height, (unsigned long)board.generation, board.population,
                    RATES[speed], measuredRate, lastFrameMs);
      return -1;
    }
  }
  if (digitalRead(SHOOT)) {
    if (!shootHeld) { shootHeld = true; holdSent = false; pressedAt = millis(); }
    if (!holdSent && millis() - pressedAt >= 850) {
      holdSent = true;
      return 5;
    }
    return -1;
  }
  if (shootHeld) {
    bool tapped = !holdSent && millis() - pressedAt >= 35;
    resetInput();
    if (tapped) return 4;
  }
  return cmd == 4 ? -1 : cmd;
}

static void drawState() {
  tft.fillRect(168, 16, 54, 10, UI_PANEL);
  tft.setTextDatum(TR_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(mode == RUNNING ? LIVE : UI_CYAN, UI_PANEL);
  tft.drawString(mode == RUNNING ? (board.population == 0 ? "EXTINCT" : stable ? "STILL" : "RUNNING") :
                 mode == OPTIONS ? "OPTIONS" : "PAUSED", 222, 17);
}

static void drawStats() {
  char text[24];
  tft.fillRect(18, 35, 204, 12, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  snprintf(text, sizeof(text), "GEN %lu", (unsigned long)board.generation);
  tft.drawString(text, 18, 37);
  snprintf(text, sizeof(text), "ALIVE %u", board.population);
  tft.setTextDatum(TR_DATUM);
  tft.setTextColor(LIVE, UI_PANEL);
  tft.drawString(text, 222, 37);
  lastStats = millis();
}

static void drawHeader() {
  tft.fillRoundRect(8, 8, 224, 46, 9, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("CONWAY'S LIFE", 18, 13);
  drawState();
  drawStats();
}

static void drawFooter() {
  tft.fillRoundRect(8, 264, 224, 48, 8, UI_PANEL);
  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(LIVE, UI_PANEL);
  tft.drawString(mode == OPTIONS ? "OPTIONS" : lifePatterns::PRESETS[pattern].name, 16, 272);
  tft.setTextDatum(TR_DATUM);
  tft.drawString(String(RATES[speed]) + " GEN/S", 224, 272);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString(mode == OPTIONS ? "UP/DOWN CHOOSE  SHOOT SELECT" :
                 mode == RUNNING ? "SHOOT PAUSE  UP/DN SPEED" : "SHOOT RESUME  UP/DN SPEED", 120, 290);
  tft.setTextColor(UI_MUTED, UI_PANEL);
  char hint[40];
  snprintf(hint, sizeof(hint), "L/R PRESET HOLD MENU %dx%d", board.width, board.height);
  tft.drawString(mode == OPTIONS ? "HOLD SHOOT BACK" : hint, 120, 304);
}

static void drawCell(int index) {
  int x = LEFT + (index % board.width) * cellSize;
  int y = TOP + (index / board.width) * cellSize;
  uint16_t color = board.cells[index] ? LIVE : DEAD;
  if (cellSize == 8) tft.fillRoundRect(x + 1, y + 1, 6, 6, 1, color);
  else tft.fillRect(x, y, cellSize, cellSize, color);
  drawn[index] = board.cells[index];
}

static void drawBoard(bool force = false) {
  force |= drawnCellSize != cellSize;
  tft.startWrite();
  if (force) tft.fillRect(LEFT, TOP, FIELD_W, FIELD_H, FIELD);
  if (cellSize == 8) {
    for (int i = 0; i < board.count(); ++i)
      if (force || drawn[i] != board.cells[i]) drawCell(i);
  } else {
    for (int y = 0; y < board.height; ++y) {
      int x = 0;
      while (x < board.width) {
        int i = y * board.width + x;
        if (!force && drawn[i] == board.cells[i]) { ++x; continue; }
        uint8_t alive = board.cells[i];
        int start = x, end = x + 1, lastDirty = x + 1, gap = 0;
        // Merge one-color updates across at most one unchanged cell. Sending
        // that cell costs less than a second SPI window; trim unchanged tails.
        while (end < board.width && board.cells[y * board.width + end] == alive) {
          if (force || drawn[y * board.width + end] != alive) {
            lastDirty = end + 1;
            gap = 0;
          } else if (++gap > 1) break;
          ++end;
        }
        x = lastDirty;
        tft.fillRect(LEFT + start * cellSize, TOP + y * cellSize,
                      (x - start) * cellSize, cellSize, alive ? LIVE : DEAD);
        memset(drawn + y * board.width + start, alive, x - start);
      }
    }
  }
  drawnCellSize = cellSize;
  tft.endWrite();
}

static void seedRle(const char *rle, int left, int top) {
  int x = 0, y = 0, count = 0;
  for (const char *p = rle; *p && *p != '!'; ++p) {
    if (*p >= '0' && *p <= '9') { count = count * 10 + *p - '0'; continue; }
    int run = count ? count : 1;
    count = 0;
    if (*p == '$') { x = 0; y += run; }
    else if (*p == 'b') x += run;
    else if (*p == 'o') {
      for (int i = 0; i < run; ++i) board.set(left + x++, top + y, true);
    }
  }
}

static void loadPattern() {
  const auto &preset = lifePatterns::PRESETS[pattern];
  cellSize = preset.cellSize;
  board.resize(FIELD_W / cellSize, FIELD_H / cellSize);
  const int cx = board.width / 2, cy = board.height / 2;
  if (preset.rle) {
    seedRle(preset.rle, cx - preset.width / 2, cy - preset.height / 2);
  } else if (pattern == lifePatterns::BLINKERS) {
    for (int y : {6, 12, 18})
      for (int x : {7, 14, 21})
        for (int dx = -1; dx <= 1; ++dx) board.set(x + dx, y, true);
  } else if (pattern == lifePatterns::PULSAR) {
    const int bars[] = {2, 3, 4, 8, 9, 10};
    const int lines[] = {0, 5, 7, 12};
    for (int a : bars) for (int b : lines) {
      board.set(cx - 6 + a, cy - 6 + b, true);
      board.set(cx - 6 + b, cy - 6 + a, true);
    }
  } else if (pattern == lifePatterns::GLIDER_FLEET) {
    for (int y : {6, 18}) for (int x : {7, 21}) seedRle("bo$2bo$3o!", x - 1, y - 1);
  } else if (preset.density) {
    for (int i = 0; i < board.count(); ++i)
      if (random(100) < preset.density) board.set(i % board.width, i / board.width, true);
  }
  stable = false;
  lastStep = millis();
  resetRate();
}

static void changePattern(int delta) {
  pattern = (pattern + delta + PATTERN_COUNT) % PATTERN_COUNT;
  loadPattern();
  drawBoard();
  drawState();
  drawStats();
  drawFooter();
}

static void drawOption(int i) {
  const char *labels[] = {"RUN / RESUME", "RESTART PATTERN", "NEXT PATTERN", "SPEED", "NEW RANDOM", "MAIN MENU"};
  int y = 106 + i * 23;
  tft.fillRoundRect(28, y, 184, 21, 4, UI_ICON_BG);
  if (i == option) {
    tft.drawRoundRect(28, y, 184, 21, 4, TFT_MAGENTA);
    tft.drawRoundRect(29, y + 1, 182, 19, 3, TFT_MAGENTA);
  }
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(1);
  tft.setTextColor(i == option ? UI_TEXT : UI_MUTED, UI_ICON_BG);
  String label = i == 3 ? String("SPEED  ") + String(RATES[speed]) + " GEN/S" : String(labels[i]);
  tft.drawString(label, 120, y + 10);
}

static void drawOptions() {
  tft.fillRoundRect(18, 73, 204, 180, 10, UI_PANEL);
  tft.drawRoundRect(18, 73, 204, 180, 10, UI_SURFACE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_PANEL);
  tft.drawString("LIFE CONTROLS", 120, 89);
  for (int i = 0; i < 6; ++i) drawOption(i);
}

static void leaveOptions(Mode next) {
  mode = next;
  drawBoard(true); // Restore the cells covered by the one-time menu overlay.
  drawState();
  drawStats();
  drawFooter();
  lastStep = millis();
  resetRate();
}

} // namespace lifeApp

void lifeSetup() {
  tft.setRotation(2);
  lifeApp::mode = lifeApp::RUNNING;
  lifeApp::resetInput();
  // The menu launches on press: consume that press through its release.
  if (digitalRead(SHOOT)) lifeApp::shootHeld = lifeApp::holdSent = true;
  lifeApp::pattern = lifePatterns::RANDOM;
  lifeApp::speed = 5;
  lifeApp::drawnCellSize = 0;
  lifeInputBegin();
  lifeApp::loadPattern();
  tft.fillScreen(UI_BG);
  lifeApp::drawHeader(); lifeApp::drawBoard(true); lifeApp::drawFooter();
  lifeApp::lastStep = millis();
  lifeApp::resetRate();
}

void lifeLoop() {
  using namespace lifeApp;
  int cmd = input();
  if (mode == OPTIONS) {
    if (cmd == 0 || cmd == 2) {
      int previous = option;
      option = (option + (cmd == 2 ? 1 : 5)) % 6;
      drawOption(previous); drawOption(option); playNavClick();
    } else if (cmd == 5) leaveOptions(optionsReturn);
    else if (cmd == 4) {
      playSelectTone();
      if (option == 5) { switchGame(0); return; }
      if (option == 0) leaveOptions(RUNNING);
      else if (option == 1) { loadPattern(); leaveOptions(RUNNING); }
      else if (option == 2) { pattern = (pattern + 1) % PATTERN_COUNT; loadPattern(); leaveOptions(RUNNING); }
      else if (option == 3) { speed = (speed + 1) % SPEED_COUNT; drawOption(option); drawFooter(); }
      else if (option == 4) {
        pattern = lifePatterns::RANDOM; loadPattern(); leaveOptions(RUNNING);
      }
    }
    return;
  }
  if (cmd == 5) {
    optionsReturn = mode;
    mode = OPTIONS; option = 0; drawState(); drawOptions(); drawFooter();
    return;
  }
  if (cmd == 4) {
    mode = mode == RUNNING ? PAUSED : RUNNING;
    lastStep = millis();
    resetRate();
    drawState(); drawStats(); drawFooter();
    return;
  }
  if (cmd == 1 || cmd == 3) changePattern(cmd == 1 ? 1 : -1);
  if (cmd == 0 || cmd == 2) {
    speed = constrain(speed + (cmd == 0 ? 1 : -1), 0, SPEED_COUNT - 1);
    drawFooter();
    lastStep = millis();
    resetRate();
  }
  if (mode == RUNNING) {
    unsigned long now = millis();
    if (now - lastStep >= (unsigned long)PERIODS[speed]) {
      // The frame's work counts toward the period rather than adding to it.
      lastStep = now;
      bool wasStable = stable;
      uint16_t previousPopulation = board.population;
      stable = !board.step();
      drawBoard();
      if (wasStable != stable || (previousPopulation == 0) != (board.population == 0)) drawState();
      if (millis() - lastStats >= 200) drawStats();
      lastFrameMs = millis() - now;
      unsigned long elapsed = millis() - rateWindowAt;
      if (elapsed >= 1000) {
        measuredRate = (board.generation - rateWindowGeneration) * 1000.0f / elapsed;
        rateWindowAt = millis();
        rateWindowGeneration = board.generation;
      }
    }
  }
}
