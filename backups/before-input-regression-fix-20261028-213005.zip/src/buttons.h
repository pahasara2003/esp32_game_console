#pragma once
#include <stdint.h>
// Commands/bits: Up, Right, Down, Left, Shoot. The scanner owns the ADC.
bool buttonsBegin();
uint8_t buttonsHeld();
int buttonsNextPress();
void buttonsRequireRelease();
