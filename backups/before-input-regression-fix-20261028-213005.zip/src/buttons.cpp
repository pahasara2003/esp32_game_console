#include <Arduino.h>
#include <Adafruit_ADS1X15.h>
#include "config.h"
#include "buttons.h"
extern Adafruit_ADS1115 ads;
extern bool adsConnected;
namespace {
portMUX_TYPE lock = portMUX_INITIALIZER_UNLOCKED;
constexpr uint8_t CAPACITY = 32;
uint8_t events[CAPACITY], head = 0, count = 0, held = 0;
bool blocked = true;
TaskHandle_t scanner = nullptr;
constexpr uint16_t MUX[] = {ADS1X15_REG_CONFIG_MUX_SINGLE_0,
  ADS1X15_REG_CONFIG_MUX_SINGLE_1, ADS1X15_REG_CONFIG_MUX_SINGLE_2,
  ADS1X15_REG_CONFIG_MUX_SINGLE_3};
constexpr uint8_t DIRECTION[] = {1, 2, 3, 0};
void publish(uint8_t state, bool ready) {
  portENTER_CRITICAL(&lock);
  uint8_t pressed = state & ~held;
  held = state;
  if (blocked) {
    if (ready && !held) blocked = false;
  } else {
    for (uint8_t command = 0; command < 5; ++command) {
      if ((pressed & (1 << command)) && count < CAPACITY) {
        events[(head + count) % CAPACITY] = command;
        ++count;
      }
    }
  }
  portEXIT_CRITICAL(&lock);
}
void scan(void *) {
  uint8_t channel = 0, high[4] = {}, low[4] = {}, directions = 0;
  bool settling = true, shootRaw = false, shootStable = false;
  unsigned long shootChanged = millis();
  if (adsConnected) ads.startADCReading(MUX[channel], false);
  TickType_t next = xTaskGetTickCount();
  for (;;) {
    unsigned long now = millis();
    bool raw = digitalRead(SHOOT) != LOW;
    if (raw != shootRaw) { shootRaw = raw; shootChanged = now; }
    if (now - shootChanged >= 10) shootStable = raw;
    if (adsConnected && ads.conversionComplete()) {
      int16_t value = ads.getLastConversionResults();
      if (settling) settling = false;
      else {
        uint8_t bit = 1 << DIRECTION[channel];
        if (value > 18000) {
          low[channel] = 0;
          if (high[channel] < 2) ++high[channel];
          if (high[channel] == 2) directions |= bit;
        } else if (value < 15000) {
          high[channel] = 0;
          if (low[channel] < 2) ++low[channel];
          if (low[channel] == 2) directions &= ~bit;
        } else high[channel] = low[channel] = 0;
        channel = (channel + 1) % 4;
        settling = true;
      }
      ads.startADCReading(MUX[channel], false);
    }
    bool released = !shootRaw && !shootStable;
    if (adsConnected)
      for (int i = 0; i < 4; ++i) released &= low[i] == 2;
    publish(directions | (shootStable ? 16 : 0), released);
    vTaskDelayUntil(&next, pdMS_TO_TICKS(2));
  }
}
}
bool buttonsBegin() {
  if (scanner) return true;
  return xTaskCreate(scan, "buttons", 3072, nullptr, 2, &scanner) == pdPASS;
}
uint8_t buttonsHeld() {
  portENTER_CRITICAL(&lock);
  uint8_t state = blocked ? 0 : held;
  portEXIT_CRITICAL(&lock);
  return state;
}
int buttonsNextPress() {
  portENTER_CRITICAL(&lock);
  int command = -1;
  if (!blocked && count) {
    command = events[head];
    head = (head + 1) % CAPACITY;
    --count;
  }
  portEXIT_CRITICAL(&lock);
  return command;
}
void buttonsRequireRelease() {
  portENTER_CRITICAL(&lock);
  head = count = 0;
  blocked = true;
  portEXIT_CRITICAL(&lock);
}
